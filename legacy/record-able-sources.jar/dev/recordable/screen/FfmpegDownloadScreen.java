package dev.recordable.screen;

import dev.recordable.FfmpegBundleManager;
import dev.recordable.PlatformUtils;
import dev.recordable.RecordableConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * First-run / on-demand FFmpeg downloader UI.
 *
 * <p>This screen explains to the user what is about to happen (download size,
 * source, integrity check) and shows a live progress bar while the download is
 * running. On success the user is sent back to {@code parent}; on failure a
 * concrete error message and platform-specific manual install instructions
 * are shown.</p>
 *
 * <p>Compliance note: this screen is the consent moment for Modrinth's
 * "no bundled binaries" rule — nothing is downloaded until the user clicks the
 * "Download FFmpeg" button. On Android (where auto-download is not supported)
 * the screen only shows manual instructions.</p>
 */
public final class FfmpegDownloadScreen extends class_437 implements FfmpegBundleManager.ProgressListener {

    private static final int PANEL_COLOR = 0xD0101010;
    private static final int PANEL_BORDER_COLOR = 0xFF424242;
    private static final int HEADER_COLOR = 0xFFFFFFFF;
    private static final int TEXT_COLOR = 0xFFD0D0D0;
    private static final int HIGHLIGHT_COLOR = 0xFF88CC88;
    private static final int WARNING_COLOR = 0xFFFFCC44;
    private static final int ERROR_COLOR = 0xFFFF7777;
    private static final int PROGRESS_BG = 0xFF202020;
    private static final int PROGRESS_BORDER = 0xFF606060;

    private final class_437 parent;

    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelBottom;

    private class_4185 downloadButton;
    private class_4185 cancelButton;
    private class_4185 openFolderButton;

    private final List<Line> lines = new ArrayList<>();
    private FfmpegBundleManager.DownloadProgress currentProgress = FfmpegBundleManager.DownloadProgress.IDLE;
    private boolean failureShown = false;

    public FfmpegDownloadScreen(class_437 parent) {
        super(class_2561.method_43470("Record-able: FFmpeg Setup"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.method_37067();

        this.panelWidth = Math.max(420, Math.min((int) (this.field_22789 * 0.78D), 640));
        this.panelLeft = (this.field_22789 - this.panelWidth) / 2;
        this.panelTop = Math.max(8, (int) (this.field_22790 * 0.08D));
        this.panelBottom = Math.min(this.field_22790 - 8, this.panelTop + Math.max(280, (int) (this.field_22790 * 0.84D)));

        rebuildLines();

        int btnW = 160;
        int btnH = 20;
        int btnY = this.panelBottom - 30;
        int centerX = this.panelLeft + this.panelWidth / 2;

        boolean autoSupported = FfmpegBundleManager.isAutoDownloadSupported();
        boolean isDownloading = FfmpegBundleManager.isDownloading();
        boolean alreadyAvailable = FfmpegBundleManager.isBundledFfmpegAvailable();

        if (alreadyAvailable) {
            // Single "Close" button.
            this.cancelButton = class_4185.method_46430(class_2561.method_43470("Close"),
                    btn -> method_25419())
                    .method_46434(centerX - btnW / 2, btnY, btnW, btnH)
                    .method_46431();
            this.method_37063(this.cancelButton);
        } else if (autoSupported) {
            String dlLabel = isDownloading ? "Downloading…" : "Download FFmpeg (" + FfmpegBundleManager.getEstimatedDownloadSize() + ")";
            this.downloadButton = class_4185.method_46430(class_2561.method_43470(dlLabel),
                    btn -> startDownload())
                    .method_46434(centerX - btnW - 4, btnY, btnW, btnH)
                    .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(
                            "Downloads FFmpeg from " + FfmpegBundleManager.getDownloadSourceDescription()
                                    + ".\nThe binary will be stored at " + FfmpegBundleManager.getBundleDirectory() + "."
                                    + "\nThe download is HTTPS-authenticated and (where available) verified against the upstream hash.")))
                    .method_46431();
            this.downloadButton.field_22763 = !isDownloading;
            this.method_37063(this.downloadButton);

            this.cancelButton = class_4185.method_46430(class_2561.method_43470(isDownloading ? "Hide" : "Cancel"),
                    btn -> method_25419())
                    .method_46434(centerX + 4, btnY, btnW, btnH)
                    .method_46431();
            this.method_37063(this.cancelButton);
        } else {
            // Manual-only (Android or unknown).
            this.openFolderButton = class_4185.method_46430(class_2561.method_43470("Open FFmpeg Folder"),
                    btn -> openBundleFolder())
                    .method_46434(centerX - btnW - 4, btnY, btnW, btnH)
                    .method_46431();
            this.method_37063(this.openFolderButton);

            this.cancelButton = class_4185.method_46430(class_2561.method_43470("Close"),
                    btn -> method_25419())
                    .method_46434(centerX + 4, btnY, btnW, btnH)
                    .method_46431();
            this.method_37063(this.cancelButton);
        }

        FfmpegBundleManager.addProgressListener(this);
        this.currentProgress = FfmpegBundleManager.getLastProgress();
    }

    private void rebuildLines() {
        lines.clear();
        boolean alreadyAvailable = FfmpegBundleManager.isBundledFfmpegAvailable();
        boolean autoSupported = FfmpegBundleManager.isAutoDownloadSupported();
        PlatformUtils.Platform platform = PlatformUtils.detectPlatform();

        addHeader("FFmpeg Setup");
        addBlank();

        if (alreadyAvailable) {
            addHighlight("✓ FFmpeg is installed and ready.");
            addBlank();
            addText("Location:");
            String path = FfmpegBundleManager.getBundledFfmpegPath();
            addText("  " + truncate(path == null ? "(unknown)" : path, 70));
            addBlank();
            addText("You can close this screen and start recording.");
            return;
        }

        addText("Record-able needs FFmpeg to encode video. To keep this mod");
        addText("Modrinth-friendly we do not bundle the FFmpeg binary —");
        addText("you download it once, from an official upstream, and the");
        addText("mod stores it inside your Minecraft folder.");
        addBlank();

        addHighlight("Platform: " + platform.displayName());
        if (autoSupported) {
            addText("Source:    " + FfmpegBundleManager.getDownloadSourceDescription());
            addText("Size:      " + FfmpegBundleManager.getEstimatedDownloadSize());
            addText("Saved to:  " + truncate(FfmpegBundleManager.getBundleDirectory().toString(), 60));
            addBlank();
            addHighlight("Integrity:");
            switch (platform) {
                case WINDOWS -> {
                    addText("  • Downloaded over HTTPS from gyan.dev");
                    addText("  • SHA-256 verified against gyan.dev's published");
                    addText("    .sha256 sibling file (best-effort).");
                }
                case LINUX -> {
                    addText("  • Downloaded over HTTPS from johnvansickle.com");
                    addText("  • MD5 verified against the .md5 sibling file");
                    addText("    (best-effort).");
                }
                case MACOS -> {
                    addText("  • Downloaded over HTTPS from evermeet.cx");
                    addText("  • HTTPS host authentication; no sibling hash file");
                    addText("    is published. The archive is signed upstream.");
                }
                default -> {}
            }
            addBlank();
            addText("Click 'Download FFmpeg' to start. The mod will not");
            addText("contact the internet until you do.");
        } else if (platform == PlatformUtils.Platform.ANDROID) {
            addWarning("Auto-download is not supported on Android.");
            addText("Exec-mounted, writable storage is rare on Pojav/Zalith/FCL,");
            addText("so a downloaded binary often cannot be run.");
            addBlank();
            addHighlight("Recommended (easiest):");
            addText("  1. Install Termux from F-Droid");
            addText("     ( https://f-droid.org/packages/com.termux/ )");
            addText("  2. In Termux, run:  pkg install ffmpeg");
            addText("  3. In Record-able's settings, set");
            addText("     ffmpegPath to:");
            addText("     /data/data/com.termux/files/usr/bin/ffmpeg");
            addBlank();
            addHighlight("Manual alternative:");
            addText("  Place a static arm64 ffmpeg binary at:");
            addText("    " + truncate(FfmpegBundleManager.getBundleDirectory().resolve("ffmpeg").toString(), 64));
            addText("  Then chmod +x it. Use 'Open FFmpeg Folder' below.");
        } else {
            addWarning("Auto-download not available for this platform.");
            addText(FfmpegBundleManager.getManualInstallInstructions());
        }

        // Show any prior error
        FfmpegBundleManager.Status st = FfmpegBundleManager.getStatus();
        if (st == FfmpegBundleManager.Status.ERROR) {
            addBlank();
            addError("Last error: " + (FfmpegBundleManager.getLastError() == null
                    ? "unknown" : FfmpegBundleManager.getLastError()));
            addText("If the problem persists, see manual install above.");
        }
    }

    private void startDownload() {
        if (FfmpegBundleManager.isDownloading()) return;
        if (this.downloadButton != null) {
            this.downloadButton.method_25355(class_2561.method_43470("Downloading…"));
            this.downloadButton.field_22763 = false;
        }
        FfmpegBundleManager.downloadAsync(success -> {
            class_310 mc = class_310.method_1551();
            if (mc == null) return;
            mc.execute(() -> {
                this.failureShown = !success;
                // Rebuild the screen so labels/buttons reflect the new state.
                this.method_37067();
                this.method_25426();
            });
        });
    }

    private void openBundleFolder() {
        try {
            java.nio.file.Files.createDirectories(FfmpegBundleManager.getBundleDirectory());
            class_156.method_668().method_672(FfmpegBundleManager.getBundleDirectory().toFile());
        } catch (Exception e) {
            dev.recordable.RecordableMod.LOGGER.warn("[FfmpegDownloadScreen] Could not open folder: {}", e.getMessage());
        }
    }

    @Override
    public void onProgress(FfmpegBundleManager.DownloadProgress progress) {
        this.currentProgress = progress;
        // No need to call init() — render() reads currentProgress every frame.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);

        int accent = 0xFF000000 | RecordableConfig.get().getMenuAccentColorRgb();
        int left = this.panelLeft - 6;
        int right = this.panelLeft + this.panelWidth + 6;
        context.method_25294(left, this.panelTop - 6, right, this.panelBottom, PANEL_COLOR);
        context.method_25294(left, this.panelTop - 6, right, this.panelTop - 5, accent);
        context.method_25294(left, this.panelBottom - 1, right, this.panelBottom, PANEL_BORDER_COLOR);
        context.method_25294(left, this.panelTop - 6, left + 1, this.panelBottom, PANEL_BORDER_COLOR);
        context.method_25294(right - 1, this.panelTop - 6, right, this.panelBottom, PANEL_BORDER_COLOR);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.panelTop, 0xFFFFFFFF);

        int textLeft = this.panelLeft + 14;
        int textTop = this.panelTop + 22;
        for (int i = 0; i < lines.size(); i++) {
            int y = textTop + i * 12;
            if (y > this.panelBottom - 60) break;
            Line line = lines.get(i);
            if (line.text.isEmpty()) continue;
            String prefix = line.bold ? "§l" : "";
            context.method_27535(this.field_22793, class_2561.method_43470(prefix + line.text), textLeft, y, line.color);
        }

        // Progress bar shown while DOWNLOADING.
        if (FfmpegBundleManager.isDownloading()) {
            int barWidth = this.panelWidth - 36;
            int barHeight = 14;
            int barLeft = this.panelLeft + 18;
            int barTop = this.panelBottom - 60;

            context.method_25294(barLeft, barTop, barLeft + barWidth, barTop + barHeight, PROGRESS_BG);
            context.method_25294(barLeft, barTop, barLeft + barWidth, barTop + 1, PROGRESS_BORDER);
            context.method_25294(barLeft, barTop + barHeight - 1, barLeft + barWidth, barTop + barHeight, PROGRESS_BORDER);
            context.method_25294(barLeft, barTop, barLeft + 1, barTop + barHeight, PROGRESS_BORDER);
            context.method_25294(barLeft + barWidth - 1, barTop, barLeft + barWidth, barTop + barHeight, PROGRESS_BORDER);

            double frac = currentProgress.fraction();
            if (frac > 0.0) {
                int fillWidth = (int) Math.round((barWidth - 2) * Math.min(1.0, Math.max(0.0, frac)));
                context.method_25294(barLeft + 1, barTop + 1, barLeft + 1 + fillWidth, barTop + barHeight - 1, accent);
            }

            String label = (currentProgress.phase() == null ? "" : capitalize(currentProgress.phase()) + " · ")
                    + currentProgress.displayBytes()
                    + (currentProgress.totalBytes() > 0 ? " (" + currentProgress.displayPercent() + ")" : "");
            context.method_27535(this.field_22793, class_2561.method_43470(label),
                    barLeft, barTop - 11, TEXT_COLOR);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25432() {
        FfmpegBundleManager.removeProgressListener(this);
        super.method_25432();
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void addHeader(String text)    { lines.add(new Line(text, HEADER_COLOR, true)); }
    private void addText(String text)      { lines.add(new Line(text, TEXT_COLOR, false)); }
    private void addHighlight(String text) { lines.add(new Line(text, HIGHLIGHT_COLOR, false)); }
    private void addWarning(String text)   { lines.add(new Line(text, WARNING_COLOR, false)); }
    private void addError(String text)     { lines.add(new Line(text, ERROR_COLOR, false)); }
    private void addBlank()                { lines.add(new Line("", TEXT_COLOR, false)); }

    private static String truncate(String s, int maxLen) {
        if (s == null) return "";
        return s.length() <= maxLen ? s : "…" + s.substring(s.length() - maxLen + 1);
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return "";
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private record Line(String text, int color, boolean bold) {}
}
