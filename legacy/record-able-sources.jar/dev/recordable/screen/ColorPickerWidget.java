package dev.recordable.screen;

import java.util.Locale;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_6382;

/** Lightweight hex color picker with a live preview swatch and inline label. */
public final class ColorPickerWidget extends class_339 {
    public static final int WIDGET_HEIGHT = 20;

    private static final Pattern HEX_COLOR = Pattern.compile("^#[0-9a-fA-F]{6}$");
    private static final int INPUT_WIDTH = 80;
    private static final int INNER_GAP = 5;

    private final class_327 textRenderer;
    private final class_342 textField;
    private final Consumer<String> onColorChanged;
    private final class_2561 label;

    public ColorPickerWidget(class_327 textRenderer,
                             int x,
                             int y,
                             int width,
                             int height,
                             class_2561 label,
                             String currentValue,
                             Consumer<String> onColorChanged) {
        super(x, y, width, height, class_2561.method_43473());
        this.textRenderer = textRenderer;
        this.onColorChanged = onColorChanged;
        this.label = label == null ? class_2561.method_43473() : label;

        this.textField = new class_342(textRenderer, x, y, INPUT_WIDTH, Math.max(16, height - 2), class_2561.method_43470("#RRGGBB"));
        this.textField.method_1880(7);
        this.textField.method_1852(sanitizeColor(currentValue));
        this.textField.method_1863(value -> {
            String candidate = normalize(value);
            if (isValidHex(candidate) && this.onColorChanged != null) {
                this.onColorChanged.accept(candidate.toUpperCase(Locale.ROOT));
            }
        });

        updateTextFieldLayout(x, y);
    }

    public String getColor() {
        String candidate = normalize(this.textField.method_1882());
        return isValidHex(candidate) ? candidate.toUpperCase(Locale.ROOT) : "#FF0000";
    }

    public void method_48229(int x, int y) {
        this.method_46421(x);
        this.method_46419(y);
        updateTextFieldLayout(x, y);
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        int x = this.method_46426();
        int y = this.method_46427();
        int previewColor = parseColor(getColor());

        context.method_25294(x, y, x + this.field_22758, y + this.field_22759, 0xAA151515);
        context.method_25294(x, y, x + this.field_22758, y + 1, 0xFF424242);
        context.method_25294(x, y + this.field_22759 - 1, x + this.field_22758, y + this.field_22759, 0xFF424242);
        context.method_25294(x, y, x + 1, y + this.field_22759, 0xFF424242);
        context.method_25294(x + this.field_22758 - 1, y, x + this.field_22758, y + this.field_22759, 0xFF424242);

        int labelAreaWidth = getLabelAreaWidth();
        class_2561 renderLabel = getRenderLabel(labelAreaWidth);
        context.method_27535(this.textRenderer, renderLabel, x + 2, y + Math.max(0, (this.field_22759 - 8) / 2), 0xFFFFFFFF);

        int previewSize = Math.max(12, this.field_22759 - 4);
        int previewX = x + labelAreaWidth + INNER_GAP;
        int previewY = y + 2;
        context.method_25294(previewX, previewY, previewX + previewSize, previewY + previewSize, 0xFF000000 | previewColor);
        context.method_25294(previewX, previewY, previewX + previewSize, previewY + 1, 0xFFFFFFFF);
        context.method_25294(previewX, previewY + previewSize - 1, previewX + previewSize, previewY + previewSize, 0xFFFFFFFF);

        this.textField.method_25394(context, mouseX, mouseY, delta);

        if (!isValidHex(normalize(this.textField.method_1882()))) {
            context.method_27535(this.textRenderer, class_2561.method_43470("!"), x + this.field_22758 - 10, y + (this.field_22759 / 2) - 4, 0xFFFF6666);
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        boolean handled = this.textField.method_25402(click, doubleClick);
        this.method_25365(this.textField.method_25370());
        return handled || super.method_25402(click, doubleClick);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        return this.textField.method_25406(click) || super.method_25406(click);
    }

    @Override
    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        return this.textField.method_25403(click, deltaX, deltaY) || super.method_25403(click, deltaX, deltaY);
    }

    @Override
    public boolean method_25404(class_11908 keyInput) {
        return this.textField.method_25404(keyInput) || super.method_25404(keyInput);
    }

    @Override
    public boolean method_25400(class_11905 charInput) {
        return this.textField.method_25400(charInput) || super.method_25400(charInput);
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        this.textField.method_25365(focused);
    }

    @Override
    protected void method_47399(class_6382 builder) {
        this.method_37021(builder);
    }

    private void updateTextFieldLayout(int x, int y) {
        int previewSize = Math.max(12, this.field_22759 - 4);
        int labelAreaWidth = getLabelAreaWidth();
        int inputX = x + labelAreaWidth + INNER_GAP + previewSize + INNER_GAP;
        int maxInputWidth = Math.max(56, this.field_22758 - (inputX - x) - INNER_GAP);

        this.textField.method_46421(inputX);
        this.textField.method_46419(y + Math.max(0, (this.field_22759 - 18) / 2));
        this.textField.method_25358(Math.min(INPUT_WIDTH, maxInputWidth));
    }

    private int getLabelAreaWidth() {
        int previewSize = Math.max(12, this.field_22759 - 4);
        int available = Math.max(30, this.field_22758 - (INPUT_WIDTH + previewSize + INNER_GAP * 3));
        return available;
    }

    private class_2561 getRenderLabel(int labelAreaWidth) {
        String raw = this.label.getString();
        if (raw == null || raw.isBlank()) {
            return class_2561.method_43473();
        }

        String text = raw;
        if (this.textRenderer.method_1727(text) > labelAreaWidth) {
            int trimmedWidth = Math.max(10, labelAreaWidth - this.textRenderer.method_1727("…"));
            text = this.textRenderer.method_27523(text, trimmedWidth) + "…";
        }
        return class_2561.method_43470(text);
    }

    private static boolean isValidHex(String value) {
        return HEX_COLOR.matcher(value).matches();
    }

    private static String normalize(String value) {
        String normalized = value == null ? "" : value.trim();
        if (!normalized.startsWith("#")) {
            normalized = "#" + normalized;
        }
        return normalized;
    }

    private static String sanitizeColor(String value) {
        String normalized = normalize(value);
        if (!isValidHex(normalized)) {
            return "#FF0000";
        }
        return normalized.toUpperCase(Locale.ROOT);
    }

    private static int parseColor(String hex) {
        try {
            return Integer.parseInt(hex.substring(1), 16);
        } catch (Throwable ignored) {
            return 0xFF0000;
        }
    }
}
