package dev.recordable.screen;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

/**
 * Small title-screen icon button that opens the Video Collection.
 * Positioned to the right of the main menu buttons, matching the size
 * and style of other vanilla icon buttons (accessibility, language).
 */
public final class HomeButtonWidget {
    /** Match vanilla icon button size (20x20). */
    private static final int SIZE = 20;

    private HomeButtonWidget() {
    }

    /**
     * Creates a small "🎬" icon button placed to the right of the main menu buttons.
     * The button position mirrors the vanilla accessibility/language icon buttons
     * on the title screen.
     */
    public static class_4185 create(class_437 hostScreen) {
        int hostWidth = hostScreen == null ? 0 : hostScreen.field_22789;
        int hostHeight = hostScreen == null ? 0 : hostScreen.field_22790;

        // Position: right of center buttons area, vertically aligned with Multiplayer button.
        // Vanilla title screen has buttons centered at width/2, 200px wide.
        // Place our button just to the right of that area, aligned with the row of Multiplayer.
        int centerX = hostWidth / 2;
        int buttonAreaRight = centerX + 100; // right edge of 200px-wide centered buttons
        int x = buttonAreaRight + 4;         // 4px gap from right edge of main buttons

        // Multiplayer is the 2nd button, at roughly height/4 + 48 + 24 in vanilla.
        // We align vertically with the Multiplayer row (y ≈ height/4 + 72).
        int y = hostHeight / 4 + 48 + 24;

        return class_4185.method_46430(class_2561.method_43470("🎬"), button -> {
                    class_310 client = class_310.method_1551();
                    if (client != null) {
                        client.method_1507(new VideoCollectionScreen(hostScreen));
                    }
                })
                .method_46434(x, y, SIZE, SIZE)
                .method_46436(class_7919.method_47407(class_2561.method_43470("Video Collection (Record-able)")))
                .method_46431();
    }
}
