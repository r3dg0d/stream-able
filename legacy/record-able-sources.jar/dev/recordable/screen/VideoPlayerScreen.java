package dev.recordable.screen;

import dev.recordable.FFmpegEncoder;
import dev.recordable.RecordableConfig;
import dev.recordable.RecordableMod;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Simplified video player screen that opens recordings in the OS's default video player.
 * No in-game decoding - just shows video info and launches the system player.
 */
public final class VideoPlayerScreen extends class_437 {

    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;

    private final File videoFile;
    private final class_437 parent;

    private String videoInfo = "Loading...";
    private String errorMessage = null;

    public VideoPlayerScreen(Path videoPath, class_437 parent) {
        super(class_2561.method_43470("Video Player"));
        this.videoFile = videoPath.toFile();
        this.parent = parent;

        RecordableMod.LOGGER.info("VideoPlayerScreen opened for: {}", videoFile.getName());
        loadVideoInfo();
    }

    private void loadVideoInfo() {
        FFmpegEncoder.FfmpegStatus status = FFmpegEncoder.detectFfmpeg();
        if (!status.found()) {
            videoInfo = "FFmpeg not found - video info unavailable";
            return;
        }

        // Try ffprobe first (detailed info: resolution, fps, duration)
        String infoFromProbe = tryFfprobeInfo(status);
        if (infoFromProbe != null) {
            videoInfo = infoFromProbe;
            return;
        }

        // Fallback: parse "ffmpeg -i" output for video info
        String infoFromFfmpeg = tryFfmpegInfo(status);
        if (infoFromFfmpeg != null) {
            videoInfo = infoFromFfmpeg;
            return;
        }

        // Last resort: just show file size
        long sizeBytes = videoFile.length();
        String sizeStr = String.format(Locale.ROOT, "%.2f MB", sizeBytes / (1024.0 * 1024.0));
        videoInfo = "Size: " + sizeStr + " (video details unavailable)";
    }

    private String tryFfprobeInfo(FFmpegEncoder.FfmpegStatus ffmpegStatus) {
        String ffprobeExecutable = resolveSiblingExecutable(ffmpegStatus.executable(), "ffprobe");

        List<String> command = new ArrayList<>();
        command.add(ffprobeExecutable);
        command.add("-v");
        command.add("error");
        command.add("-select_streams");
        command.add("v:0");
        command.add("-show_entries");
        command.add("stream=width,height,r_frame_rate:format=duration");
        command.add("-of");
        command.add("csv=p=0");
        command.add(videoFile.getAbsolutePath());

        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            Process process = pb.start();

            String line;
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                line = reader.readLine();
            }

            boolean exited = process.waitFor(10, TimeUnit.SECONDS);
            if (!exited) { process.destroyForcibly(); return null; }
            if (process.exitValue() != 0 || line == null || line.isBlank()) return null;

            String[] parts = line.split(",");
            if (parts.length < 2) return null;

            String resolution = parts[0] + "x" + parts[1];
            String fps = "?";
            String duration = "Unknown";

            if (parts.length >= 3 && !parts[2].isBlank()) {
                String[] fpsParts = parts[2].split("/");
                if (fpsParts.length == 2) {
                    double numerator = Double.parseDouble(fpsParts[0]);
                    double denominator = Double.parseDouble(fpsParts[1]);
                    if (denominator > 0) {
                        fps = String.format(Locale.ROOT, "%.0f", numerator / denominator);
                    }
                } else {
                    fps = String.format(Locale.ROOT, "%.0f", Double.parseDouble(parts[2]));
                }
            }

            if (parts.length >= 4 && !parts[3].isBlank()) {
                double dur = Double.parseDouble(parts[3]);
                int hours = (int) (dur / 3600);
                int mins = (int) ((dur % 3600) / 60);
                int secs = (int) (dur % 60);

                if (hours > 0) {
                    duration = String.format(Locale.ROOT, "%d:%02d:%02d", hours, mins, secs);
                } else {
                    duration = String.format(Locale.ROOT, "%d:%02d", mins, secs);
                }
            }

            return resolution + " @ " + fps + " fps  |  Duration: " + duration;
        } catch (Exception e) {
            RecordableMod.LOGGER.debug("ffprobe info failed for {}: {}", videoFile.getName(), e.getMessage());
            return null;
        }
    }

    /**
     * Fallback: parse "ffmpeg -i" stderr for video stream info and duration.
     * Extracts resolution, fps, and duration from lines like:
     *   Stream #0:0: Video: h264 ..., 1920x1080, 60 fps
     *   Duration: 00:01:23.45, start: ...
     */
    private String tryFfmpegInfo(FFmpegEncoder.FfmpegStatus ffmpegStatus) {
        try {
            Process process = new ProcessBuilder(
                    ffmpegStatus.executable(),
                    "-nostdin",
                    "-hide_banner",
                    "-i", videoFile.getAbsolutePath()
            ).redirectErrorStream(true).start();

            String output;
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String l;
                while ((l = reader.readLine()) != null) {
                    if (sb.length() > 0) sb.append('\n');
                    sb.append(l);
                }
                output = sb.toString();
            }

            process.waitFor(10, TimeUnit.SECONDS);
            if (!process.isAlive()) { /* fine */ } else { process.destroyForcibly(); }

            String resolution = "?";
            String fps = "?";
            String duration = "Unknown";

            // Parse duration: "Duration: HH:MM:SS.xx"
            java.util.regex.Pattern durPat = java.util.regex.Pattern.compile(
                    "Duration:\\s*(\\d+):(\\d+):(\\d+\\.\\d+)");
            java.util.regex.Matcher durMatch = durPat.matcher(output);
            if (durMatch.find()) {
                int hours = Integer.parseInt(durMatch.group(1));
                int mins = Integer.parseInt(durMatch.group(2));
                double secs = Double.parseDouble(durMatch.group(3));
                if (hours > 0) {
                    duration = String.format(Locale.ROOT, "%d:%02d:%02d", hours, mins, (int)secs);
                } else {
                    duration = String.format(Locale.ROOT, "%d:%02d", mins, (int)secs);
                }
            }

            // Parse video stream: "Video: ... WIDTHxHEIGHT ... XX fps"
            java.util.regex.Pattern vidPat = java.util.regex.Pattern.compile(
                    "Stream.*Video:.*?(\\d{2,5})x(\\d{2,5})");
            java.util.regex.Matcher vidMatch = vidPat.matcher(output);
            if (vidMatch.find()) {
                resolution = vidMatch.group(1) + "x" + vidMatch.group(2);
            }

            java.util.regex.Pattern fpsPat = java.util.regex.Pattern.compile(
                    "(\\d+(?:\\.\\d+)?)\\s+fps");
            java.util.regex.Matcher fpsMatch = fpsPat.matcher(output);
            if (fpsMatch.find()) {
                fps = String.format(Locale.ROOT, "%.0f", Double.parseDouble(fpsMatch.group(1)));
            }

            return resolution + " @ " + fps + " fps  |  Duration: " + duration;
        } catch (Exception e) {
            RecordableMod.LOGGER.debug("ffmpeg -i info failed for {}: {}", videoFile.getName(), e.getMessage());
            return null;
        }
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = field_22789 / 2;
        int y = field_22790 / 2 + 20;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("▶ Open Video"),
                button -> openInDefaultPlayer()
        ).method_46434(centerX - BUTTON_WIDTH / 2, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43470("\uD83D\uDCC1 Open Recordings Folder"),
                button -> openRecordingsFolder()
        ).method_46434(centerX - BUTTON_WIDTH / 2, y + 30, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43470("Back"),
                button -> {
                    if (field_22787 != null) field_22787.method_1507(parent);
                }
        ).method_46434(centerX - BUTTON_WIDTH / 2, y + 60, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }

    private void openInDefaultPlayer() {
        try {
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            List<String> command = new ArrayList<>();

            RecordableMod.LOGGER.info("Opening video in default player (OS: {})", os);

            if (os.contains("win")) {
                command.add("cmd");
                command.add("/c");
                command.add("start");
                command.add("");
                command.add(videoFile.getAbsolutePath());
            } else if (os.contains("mac")) {
                command.add("open");
                command.add(videoFile.getAbsolutePath());
            } else {
                command.add("xdg-open");
                command.add(videoFile.getAbsolutePath());
            }

            new ProcessBuilder(command).start();
            RecordableMod.LOGGER.info("Video opened successfully in system player");
            errorMessage = null;

        } catch (IOException e) {
            RecordableMod.LOGGER.error("Failed to open video in default player", e);
            errorMessage = "Failed to open video: " + e.getMessage();
        }
    }

    private void openRecordingsFolder() {
        try {
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            File folder = videoFile.getParentFile();

            RecordableMod.LOGGER.info("Opening recordings folder: {}", folder.getAbsolutePath());

            if (os.contains("win")) {
                new ProcessBuilder("explorer", folder.getAbsolutePath()).start();
            } else if (os.contains("mac")) {
                new ProcessBuilder("open", folder.getAbsolutePath()).start();
            } else {
                new ProcessBuilder("xdg-open", folder.getAbsolutePath()).start();
            }

        } catch (IOException e) {
            RecordableMod.LOGGER.error("Failed to open recordings folder", e);
            errorMessage = "Failed to open folder: " + e.getMessage();
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);

        int accent = 0xFF000000 | RecordableConfig.get().getMenuAccentColorRgb();

        context.method_27534(field_22793, class_2561.method_43470("▶ Video Player"), field_22789 / 2, 40, 0xFFFFFF);

        int infoY = field_22790 / 2 - 80;
        context.method_27534(
                field_22793, class_2561.method_43470(videoFile.getName()),
                field_22789 / 2, infoY, 0xFFFFFF);

        context.method_27534(
                field_22793, class_2561.method_43470(videoInfo),
                field_22789 / 2, infoY + 20, 0xAAAAAA);

        long fileSize = videoFile.length();
        String sizeStr = formatFileSize(fileSize);
        context.method_27534(
                field_22793, class_2561.method_43470("File size: " + sizeStr),
                field_22789 / 2, infoY + 40, 0xAAAAAA);

        context.method_27534(
                field_22793, class_2561.method_43470("Opens in your system's default video player"),
                field_22789 / 2, infoY + 70, 0x888888);

        if (errorMessage != null) {
            context.method_27534(
                    field_22793, class_2561.method_43470(errorMessage),
                    field_22789 / 2, field_22790 - 60, 0xFF5555);
        }

        context.method_25294(0, field_22790 / 2 + 10, field_22789, field_22790 / 2 + 11, accent);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static String formatFileSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        } else if (bytes < 1024 * 1024) {
            return String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0);
        } else if (bytes < 1024L * 1024 * 1024) {
            return String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0));
        } else {
            return String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
        }
    }

    private static String resolveSiblingExecutable(String ffmpegPath, String targetBaseName) {
        if (ffmpegPath == null || ffmpegPath.isBlank()) {
            return targetBaseName;
        }
        String lower = ffmpegPath.toLowerCase(Locale.ROOT);
        if (lower.endsWith("ffmpeg.exe")) {
            return ffmpegPath.substring(0, ffmpegPath.length() - "ffmpeg.exe".length()) + targetBaseName + ".exe";
        }
        if (lower.endsWith("ffmpeg")) {
            return ffmpegPath.substring(0, ffmpegPath.length() - "ffmpeg".length()) + targetBaseName;
        }
        return targetBaseName;
    }
}
