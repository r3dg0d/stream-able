package dev.recordable.screen;

import dev.recordable.RecordableConfig;
import dev.recordable.RecordableMod;
import dev.recordable.VideoMetadata;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** In-game video browser and management UI for recorded files. */
public final class VideoCollectionScreen extends class_437 {
    private static final int PANEL_COLOR = 0xD0101010;
    private static final int PANEL_BORDER_COLOR = 0xFF424242;
    private static final int TEXT_COLOR = 0xFFE5E5E5;
    private static final int MUTED_TEXT_COLOR = 0xFFB8B8B8;
    private static final int ERROR_TEXT_COLOR = 0xFFFF7777;

    private static final int ENTRY_HEIGHT = 50;
    private static final int BUTTON_WIDTH = 54;
    private static final int BUTTON_HEIGHT = 14;
    private static final int DELETE_CONFIRM_MS = 6_000;

    private final class_437 parent;
    private final List<VideoMetadata> allVideos = new ArrayList<>();
    private final List<VideoMetadata> filteredVideos = new ArrayList<>();
    private final List<ActionZone> actionZones = new ArrayList<>();
    private final Map<Path, ThumbnailTexture> thumbnailCache = new HashMap<>();

    private class_342 searchField;
    private class_2561 statusMessage;
    private boolean statusIsError;
    private int scrollOffset;

    private int contentLeft;
    private int contentWidth;
    private int listLeft;
    private int listRight;
    private int listTop;
    private int listBottom;

    private long totalSizeBytes;
    private Path deleteConfirmPath;
    private long deleteConfirmUntil;

    /** Background thread for probing durations without blocking the render thread. */
    private volatile ExecutorService durationProber;
    private final AtomicBoolean durationProbeRunning = new AtomicBoolean(false);

    public VideoCollectionScreen(class_437 parent) {
        super(class_2561.method_43471("screen.recordable.video_collection.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.method_37067();
        this.actionZones.clear();

        this.contentWidth = Math.max(320, Math.min((int) (this.field_22789 * 0.92D), 980));
        this.contentLeft = (this.field_22789 - this.contentWidth) / 2;

        int topBarY = Math.max(24, (int) (this.field_22790 * 0.05D));
        int searchWidth = Math.max(170, Math.min(280, (int) (this.contentWidth * 0.34D)));

        this.searchField = new class_342(this.field_22793, this.contentLeft + 8, topBarY, searchWidth, 18,
                class_2561.method_43471("screen.recordable.video_collection.search_hint"));
        this.searchField.method_1880(120);
        this.searchField.method_1887(class_2561.method_43471("screen.recordable.video_collection.search_hint").getString());
        this.searchField.method_1863(value -> applyFilter());
        this.method_37063(this.searchField);

        int rightX = this.contentLeft + this.contentWidth - 8;
        rightX = addTopButton(rightX, topBarY, 74, class_2561.method_43471("screen.recordable.video_collection.back"), button -> method_25419());
        rightX = addTopButton(rightX, topBarY, 84, class_2561.method_43471("screen.recordable.video_collection.settings"),
                button -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new RecordableSettingsScreen(this));
                    }
                });
        rightX = addTopButton(rightX, topBarY, 130, class_2561.method_43471("screen.recordable.video_collection.open_recordings_folder"),
                button -> openRecordingsFolder());
        addTopButton(rightX, topBarY, 78, class_2561.method_43471("screen.recordable.video_collection.refresh"), button -> refreshVideos());

        this.listLeft = this.contentLeft + 8;
        this.listRight = this.contentLeft + this.contentWidth - 8;
        this.listTop = topBarY + 28;
        this.listBottom = this.field_22790 - Math.max(24, (int) (this.field_22790 * 0.04D));

        refreshVideos();
    }

    private int addTopButton(int rightEdge, int y, int width, class_2561 text, class_4185.class_4241 action) {
        int x = rightEdge - width;
        this.method_37063(class_4185.method_46430(text, action).method_46434(x, y, width, 18).method_46431());
        return x - 4;
    }

    @Override
    public void method_25419() {
        cancelDurationProbe();
        clearThumbnails();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    private void cancelDurationProbe() {
        durationProbeRunning.set(false);
        ExecutorService exec = durationProber;
        if (exec != null) {
            exec.shutdownNow();
            durationProber = null;
        }
    }

    private void refreshVideos() {
        cancelDurationProbe();
        this.allVideos.clear();
        this.totalSizeBytes = 0L;
        this.statusMessage = null;
        this.statusIsError = false;
        // Don't clear the metadata cache -- it handles staleness via size/modified checks.
        // This lets cached durations survive a refresh without re-probing every file.
        clearThumbnails();

        try {
            RecordableConfig config = RecordableConfig.get();
            Path outputDir = config == null ? null : config.getOutputDirectory();
            if (outputDir == null || !Files.exists(outputDir) || !Files.isDirectory(outputDir)) {
                this.statusMessage = class_2561.method_43471("screen.recordable.video_collection.no_recordings");
                applyFilter();
                return;
            }

            try (Stream<Path> stream = Files.list(outputDir)) {
                stream.filter(Files::isRegularFile)
                        .filter(VideoCollectionScreen::isSupportedVideo)
                        .forEach(path -> {
                            try {
                                // Quick read: gets size, timestamp, thumbnail (cached) but
                                // skips ffprobe so the UI populates instantly.
                                // If a prior duration is cached, readQuick returns it.
                                VideoMetadata metadata = VideoMetadata.readQuick(path);
                                allVideos.add(metadata);
                                totalSizeBytes += Math.max(0L, metadata.sizeBytes);
                            } catch (Throwable throwable) {
                                RecordableMod.LOGGER.warn("Skipping unreadable recording entry {}", path, throwable);
                            }
                        });
            }

            this.allVideos.sort(Comparator.comparingLong((VideoMetadata metadata) -> metadata.modifiedMillis).reversed());
            if (this.allVideos.isEmpty()) {
                this.statusMessage = class_2561.method_43471("screen.recordable.video_collection.no_recordings");
            }
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to refresh video collection.", throwable);
            this.statusMessage = class_2561.method_43471("screen.recordable.video_collection.refresh_failed");
            this.statusIsError = true;
        }

        applyFilter();

        // Kick off background duration probing for entries that still need it
        startDurationProbe();
    }

    /**
     * Probes video durations in a single background thread, updating entries
     * as results come in. The UI will show "..." until each duration resolves.
     */
    private void startDurationProbe() {
        // Snapshot file paths that need probing
        List<Path> needsProbe = new ArrayList<>();
        for (VideoMetadata m : allVideos) {
            if (m.durationSeconds <= 0D && m.file != null) {
                needsProbe.add(m.file);
            }
        }
        if (needsProbe.isEmpty()) return;

        durationProbeRunning.set(true);
        ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "recordable-duration-prober");
            t.setDaemon(true);
            return t;
        });
        durationProber = exec;

        exec.submit(() -> {
            for (Path path : needsProbe) {
                if (!durationProbeRunning.get()) break;
                try {
                    VideoMetadata probed = VideoMetadata.probeDurationFor(path);
                    if (probed != null && durationProbeRunning.get()) {
                        // Schedule replacement on render thread
                        class_310 mc = class_310.method_1551();
                        if (mc != null) {
                            mc.execute(() -> replaceProbedEntry(path, probed));
                        }
                    }
                } catch (Throwable t) {
                    RecordableMod.LOGGER.debug("Background duration probe error for {}", path, t);
                }
            }
            durationProbeRunning.set(false);
        });
    }

    /** Replace an entry in the video lists after its duration was probed. */
    private void replaceProbedEntry(Path file, VideoMetadata probed) {
        replaceInList(allVideos, file, probed);
        replaceInList(filteredVideos, file, probed);
    }

    private static void replaceInList(List<VideoMetadata> list, Path file, VideoMetadata replacement) {
        for (int i = 0; i < list.size(); i++) {
            VideoMetadata existing = list.get(i);
            if (existing != null && existing.file != null && existing.file.equals(replacement.file)) {
                list.set(i, replacement);
                break;
            }
        }
    }

    private void applyFilter() {
        String query = this.searchField == null ? "" : this.searchField.method_1882();
        String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);

        this.filteredVideos.clear();
        if (normalized.isBlank()) {
            this.filteredVideos.addAll(this.allVideos);
        } else {
            for (VideoMetadata metadata : this.allVideos) {
                if (metadata == null) {
                    continue;
                }
                String haystack = (metadata.filename + " " + metadata.recordedAtDisplay).toLowerCase(Locale.ROOT);
                if (haystack.contains(normalized)) {
                    this.filteredVideos.add(metadata);
                }
            }
        }

        clampScroll();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int viewHeight = Math.max(0, this.listBottom - this.listTop);
        int maxScroll = Math.max(0, this.filteredVideos.size() * ENTRY_HEIGHT - viewHeight);
        if (maxScroll <= 0) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        int delta = (int) Math.round(verticalAmount * -20.0D);
        if (delta == 0) {
            delta = verticalAmount > 0 ? -20 : 20;
        }
        this.scrollOffset = Math.max(0, Math.min(maxScroll, this.scrollOffset + delta));
        return true;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        if (super.method_25402(click, doubleClick)) {
            return true;
        }

        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        for (ActionZone zone : this.actionZones) {
            if (zone.contains(mouseX, mouseY)) {
                zone.action.run();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_25404(class_11908 keyInput) {
        if (this.searchField != null && this.searchField.method_25370()) {
            return super.method_25404(keyInput);
        }

        int keyCode = keyInput.comp_4795();
        if (keyCode == 264) { // down
            this.scrollOffset += ENTRY_HEIGHT;
            clampScroll();
            return true;
        }
        if (keyCode == 265) { // up
            this.scrollOffset -= ENTRY_HEIGHT;
            clampScroll();
            return true;
        }
        return super.method_25404(keyInput);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);

        int panelLeft = this.listLeft - 8;
        int panelRight = this.listRight + 8;
        int panelTop = this.listTop - 52;
        int panelBottom = this.field_22790 - 8;
        int accent = 0xFF000000 | RecordableConfig.get().getMenuAccentColorRgb();

        context.method_25294(panelLeft, panelTop, panelRight, panelBottom, PANEL_COLOR);
        context.method_25294(panelLeft, panelTop, panelRight, panelTop + 1, PANEL_BORDER_COLOR);
        context.method_25294(panelLeft, panelBottom - 1, panelRight, panelBottom, PANEL_BORDER_COLOR);
        context.method_25294(panelLeft, panelTop, panelLeft + 1, panelBottom, PANEL_BORDER_COLOR);
        context.method_25294(panelRight - 1, panelTop, panelRight, panelBottom, PANEL_BORDER_COLOR);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, panelTop + 6, 0xFFFFFFFF);

        String summary = class_2561.method_43469(
                "screen.recordable.video_collection.summary",
                Integer.toString(this.allVideos.size()),
                formatSizeMb(this.totalSizeBytes)
        ).getString();
        context.method_27535(this.field_22793, class_2561.method_43470(summary), this.listLeft, panelTop + 6, MUTED_TEXT_COLOR);

        super.method_25394(context, mouseX, mouseY, delta);

        context.method_25294(this.listLeft, this.listTop, this.listRight, this.listBottom, 0x80151515);
        context.method_25294(this.listLeft, this.listTop, this.listRight, this.listTop + 1, accent);
        context.method_25294(this.listLeft, this.listBottom - 1, this.listRight, this.listBottom, PANEL_BORDER_COLOR);

        this.actionZones.clear();

        if (this.filteredVideos.isEmpty()) {
            class_2561 noItemsText = class_2561.method_43471("screen.recordable.video_collection.no_recordings");
            context.method_27534(this.field_22793, noItemsText, this.field_22789 / 2,
                    this.listTop + Math.max(8, (this.listBottom - this.listTop) / 2 - 6), MUTED_TEXT_COLOR);
        } else {
            renderVideoEntries(context, mouseX, mouseY);
        }

        if (this.statusMessage != null) {
            context.method_27535(
                    this.field_22793,
                    this.statusMessage,
                    this.listLeft,
                    this.field_22790 - 18,
                    this.statusIsError ? ERROR_TEXT_COLOR : MUTED_TEXT_COLOR
            );
        }
    }

    private void renderVideoEntries(class_332 context, int mouseX, int mouseY) {
        int viewHeight = Math.max(1, this.listBottom - this.listTop);
        int firstIndex = Math.max(0, this.scrollOffset / ENTRY_HEIGHT);
        int lastIndexExclusive = Math.min(this.filteredVideos.size(), firstIndex + (viewHeight / ENTRY_HEIGHT) + 3);
        int y = this.listTop - (this.scrollOffset % ENTRY_HEIGHT);

        for (int index = firstIndex; index < lastIndexExclusive; index++) {
            VideoMetadata metadata = this.filteredVideos.get(index);
            int entryTop = y + (index - firstIndex) * ENTRY_HEIGHT;
            int entryBottom = entryTop + ENTRY_HEIGHT - 2;
            if (entryBottom < this.listTop || entryTop > this.listBottom) {
                continue;
            }

            renderEntry(context, metadata, entryTop, entryBottom, mouseX, mouseY);
        }

        renderScrollBar(context, viewHeight);
    }

    private void renderEntry(class_332 context, VideoMetadata metadata, int top, int bottom, int mouseX, int mouseY) {
        if (metadata == null) {
            return;
        }

        int accent = 0xFF000000 | RecordableConfig.get().getMenuAccentColorRgb();
        int background = mouseY >= top && mouseY <= bottom ? 0xA0333333 : 0xA0202020;
        context.method_25294(this.listLeft + 2, top, this.listRight - 2, bottom, background);

        int thumbLeft = this.listLeft + 6;
        int thumbTop = top + 5;
        int thumbWidth = 74;
        int thumbHeight = 40;

        context.method_25294(thumbLeft, thumbTop, thumbLeft + thumbWidth, thumbTop + thumbHeight, 0xFF1F1F1F);
        context.method_25294(thumbLeft, thumbTop, thumbLeft + thumbWidth, thumbTop + 1, PANEL_BORDER_COLOR);
        context.method_25294(thumbLeft, thumbTop + thumbHeight - 1, thumbLeft + thumbWidth, thumbTop + thumbHeight, PANEL_BORDER_COLOR);

        boolean renderedThumb = drawThumbnail(context, metadata, thumbLeft + 1, thumbTop + 1, thumbWidth - 2, thumbHeight - 2);
        if (!renderedThumb) {
            context.method_25294(thumbLeft + 8, thumbTop + 7, thumbLeft + 66, thumbTop + 33, 0xFF2C2C2C);
            context.method_27534(this.field_22793, class_2561.method_43470("VIDEO"), thumbLeft + thumbWidth / 2, thumbTop + 15, accent);
        }

        int textX = thumbLeft + thumbWidth + 8;
        context.method_27535(this.field_22793, class_2561.method_43470(metadata.filename), textX, top + 4, TEXT_COLOR);
        context.method_27535(
                this.field_22793,
                class_2561.method_43469("screen.recordable.video_collection.meta.size_duration", metadata.sizeDisplay, metadata.durationDisplay),
                textX,
                top + 17,
                MUTED_TEXT_COLOR
        );
        context.method_27535(
                this.field_22793,
                class_2561.method_43469("screen.recordable.video_collection.meta.recorded_at", metadata.recordedAtDisplay),
                textX,
                top + 29,
                MUTED_TEXT_COLOR
        );

        int buttonsRight = this.listRight - 6;
        int col2 = buttonsRight - BUTTON_WIDTH;
        int col1 = col2 - 5 - BUTTON_WIDTH;
        int row1 = top + 5;
        int row2 = top + 24;

        drawActionButton(context, mouseX, mouseY, col1, row1, BUTTON_WIDTH, BUTTON_HEIGHT,
                class_2561.method_43471("screen.recordable.video_collection.play"), () -> playInGame(metadata.file));
        drawActionButton(context, mouseX, mouseY, col2, row1, BUTTON_WIDTH, BUTTON_HEIGHT,
                class_2561.method_43471("screen.recordable.video_collection.open_folder"), () -> openContainingFolder(metadata.file));
        drawActionButton(context, mouseX, mouseY, col1, row2, BUTTON_WIDTH, BUTTON_HEIGHT,
                class_2561.method_43471("screen.recordable.video_collection.copy_path"), () -> copyPath(metadata.file));
        drawActionButton(context, mouseX, mouseY, col2, row2, BUTTON_WIDTH, BUTTON_HEIGHT,
                class_2561.method_43471("screen.recordable.video_collection.delete"), () -> confirmDelete(metadata.file));
    }

    private boolean drawThumbnail(class_332 context, VideoMetadata metadata, int x, int y, int width, int height) {
        if (metadata.thumbnailPath == null || !Files.exists(metadata.thumbnailPath)) {
            return false;
        }

        ThumbnailTexture texture = thumbnailCache.get(metadata.thumbnailPath);
        if (texture == null) {
            texture = loadThumbnailTexture(metadata.thumbnailPath);
            if (texture != null) {
                thumbnailCache.put(metadata.thumbnailPath, texture);
            }
        }

        if (texture == null || texture.identifier == null) {
            return false;
        }

        try {
            context.method_25290(class_10799.field_56883, texture.identifier, x, y, 0.0F, 0.0F, width, height, width, height);
            return true;
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.debug("Failed to draw thumbnail texture for {}", metadata.thumbnailPath, throwable);
            return false;
        }
    }

    private ThumbnailTexture loadThumbnailTexture(Path thumbnailPath) {
        class_310 client = this.field_22787 == null ? class_310.method_1551() : this.field_22787;
        if (client == null || client.method_1531() == null) {
            return null;
        }

        try {
            if (!Files.exists(thumbnailPath) || !Files.isReadable(thumbnailPath)) {
                RecordableMod.LOGGER.debug("Thumbnail path is missing/unreadable: {}", thumbnailPath);
                return null;
            }
            class_1011 image;
            try (java.io.InputStream stream = Files.newInputStream(thumbnailPath)) {
                image = class_1011.method_4309(stream);
            }
            class_1043 nativeTexture = new class_1043(() -> "recordable-thumb", image);
            String idSuffix = Integer.toHexString(thumbnailPath.toAbsolutePath().toString().hashCode());
            class_2960 id = class_2960.method_60655(RecordableMod.MOD_ID, "thumb/" + idSuffix);
            client.method_1531().method_4616(id, nativeTexture);
            return new ThumbnailTexture(id, nativeTexture);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.debug("Failed to load thumbnail texture from {}", thumbnailPath, throwable);
            return null;
        }
    }

    private void clearThumbnails() {
        class_310 client = this.field_22787 == null ? class_310.method_1551() : this.field_22787;
        for (ThumbnailTexture texture : this.thumbnailCache.values()) {
            if (texture == null) {
                continue;
            }
            try {
                if (client != null && client.method_1531() != null && texture.identifier != null) {
                    client.method_1531().method_4615(texture.identifier);
                }
                if (texture.texture != null) {
                    texture.texture.close();
                }
            } catch (Throwable ignored) {
            }
        }
        this.thumbnailCache.clear();
    }

    private void drawActionButton(class_332 context,
                                  int mouseX,
                                  int mouseY,
                                  int x,
                                  int y,
                                  int width,
                                  int height,
                                  class_2561 label,
                                  Runnable action) {
        int accent = 0xFF000000 | RecordableConfig.get().getMenuAccentColorRgb();
        boolean hovered = mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
        int fill = hovered ? 0xFF505050 : 0xFF353535;
        context.method_25294(x, y, x + width, y + height, fill);
        context.method_25294(x, y, x + width, y + 1, hovered ? accent : PANEL_BORDER_COLOR);
        context.method_25294(x, y + height - 1, x + width, y + height, PANEL_BORDER_COLOR);
        context.method_25294(x, y, x + 1, y + height, PANEL_BORDER_COLOR);
        context.method_25294(x + width - 1, y, x + width, y + height, PANEL_BORDER_COLOR);
        context.method_27534(this.field_22793, label, x + width / 2, y + 3, hovered ? 0xFFFFFFFF : 0xFFE0E0E0);
        this.actionZones.add(new ActionZone(x, y, x + width, y + height, action));
    }

    private void renderScrollBar(class_332 context, int viewHeight) {
        int contentHeight = this.filteredVideos.size() * ENTRY_HEIGHT;
        if (contentHeight <= viewHeight) {
            return;
        }

        int scrollbarLeft = this.listRight - 4;
        int scrollbarRight = this.listRight - 2;
        context.method_25294(scrollbarLeft, this.listTop, scrollbarRight, this.listBottom, 0xFF2A2A2A);

        int thumbHeight = Math.max(24, (int) (viewHeight * (viewHeight / (double) contentHeight)));
        int maxScroll = contentHeight - viewHeight;
        int available = viewHeight - thumbHeight;
        int thumbTop = this.listTop + (int) ((this.scrollOffset / (double) maxScroll) * available);
        context.method_25294(scrollbarLeft, thumbTop, scrollbarRight, thumbTop + thumbHeight, 0xFF666666);
    }

    private void openRecordingsFolder() {
        try {
            Path dir = RecordableConfig.get().getOutputDirectory();
            Files.createDirectories(dir);
            class_156.method_668().method_60932(dir);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.opened_folder"), false);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to open recordings folder from collection screen.", throwable);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.open_folder_failed"), true);
        }
    }

    private void openContainingFolder(Path file) {
        if (file == null) {
            return;
        }

        try {
            Path parent = file.getParent();
            if (parent == null) {
                throw new IOException("Missing parent directory");
            }
            Files.createDirectories(parent);
            class_156.method_668().method_60932(parent);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.opened_folder"), false);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to open folder for {}", file, throwable);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.open_folder_failed"), true);
        }
    }

    private void playInGame(Path file) {
        if (file == null || this.field_22787 == null) {
            return;
        }
        try {
            clearThumbnails();
            this.field_22787.method_1507(new VideoPlayerScreen(file, this));
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to open in-game video player for {}", file, throwable);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.play_failed"), true);
        }
    }

    private void openFile(Path file) {
        if (file == null) {
            return;
        }
        try {
            class_156.method_668().method_60932(file);
            setStatus(class_2561.method_43469("screen.recordable.video_collection.playing", file.getFileName()), false);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to open video file {}", file, throwable);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.play_failed"), true);
        }
    }

    private void copyPath(Path file) {
        if (file == null || this.field_22787 == null || this.field_22787.field_1774 == null) {
            return;
        }
        try {
            this.field_22787.field_1774.method_1455(file.toAbsolutePath().toString());
            setStatus(class_2561.method_43471("screen.recordable.video_collection.copied_path"), false);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to copy file path for {}", file, throwable);
            setStatus(class_2561.method_43471("screen.recordable.video_collection.copy_failed"), true);
        }
    }

    private void confirmDelete(Path file) {
        if (file == null) {
            return;
        }

        long now = System.currentTimeMillis();
        if (!file.equals(this.deleteConfirmPath) || now > this.deleteConfirmUntil) {
            this.deleteConfirmPath = file;
            this.deleteConfirmUntil = now + DELETE_CONFIRM_MS;
            setStatus(class_2561.method_43469("screen.recordable.video_collection.delete_confirm", file.getFileName()), true);
            return;
        }

        this.deleteConfirmPath = null;
        this.deleteConfirmUntil = 0L;

        try {
            Files.deleteIfExists(file);
            setStatus(class_2561.method_43469("screen.recordable.video_collection.deleted", file.getFileName()), false);
            refreshVideos();
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to delete recording {}", file, throwable);
            setStatus(class_2561.method_43469("screen.recordable.video_collection.delete_failed", file.getFileName()), true);
        }
    }

    private void clampScroll() {
        int viewHeight = Math.max(0, this.listBottom - this.listTop);
        int maxScroll = Math.max(0, this.filteredVideos.size() * ENTRY_HEIGHT - viewHeight);
        this.scrollOffset = Math.max(0, Math.min(maxScroll, this.scrollOffset));
    }

    private void setStatus(class_2561 text, boolean isError) {
        this.statusMessage = text;
        this.statusIsError = isError;
    }

    private static String formatSizeMb(long bytes) {
        return String.format(Locale.ROOT, "%.2f MB", Math.max(0L, bytes) / (1024.0D * 1024.0D));
    }

    private static boolean isSupportedVideo(Path path) {
        if (path == null || path.getFileName() == null) {
            return false;
        }
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return name.endsWith(".mp4") || name.endsWith(".mkv");
    }

    private record ActionZone(int x1, int y1, int x2, int y2, Runnable action) {
        private boolean contains(double x, double y) {
            return x >= x1 && x < x2 && y >= y1 && y < y2;
        }
    }

    private record ThumbnailTexture(class_2960 identifier, class_1043 texture) {
    }
}
