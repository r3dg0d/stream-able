package dev.recordable.screen;

import dev.recordable.AudioCapture;
import dev.recordable.DiskSpaceGuardian;
import dev.recordable.FFmpegEncoder;
import dev.recordable.FfmpegBundleManager;
import dev.recordable.PlatformUtils;
import dev.recordable.RecordableConfig;
import dev.recordable.RecordableMod;
import dev.recordable.RecordingManager;
import dev.recordable.ReplayBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;
import net.minecraft.class_11908;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;

/** Responsive in-game settings screen with scrolling support. */
public final class RecordableSettingsScreen extends class_437 {
    private static final int PANEL_COLOR = 0xD0101010;
    private static final int PANEL_BORDER_COLOR = 0xFF424242;
    private static final int HEADER_COLOR = 0xFFFFFFFF;
    private static final int MUTED_TEXT_COLOR = 0xFFB8B8B8;
    private static final int ERROR_TEXT_COLOR = 0xFFFF7777;
    private static final int WIDGET_HEIGHT = 20;
    private static final int ROW_SPACING = 22;
    private static final class_2561 WINDOWS_AUDIO_WARNING_TEXT = class_2561.method_43470("\u2139 Audio capture uses DirectShow (Stereo Mix) to record game audio - same approach as OBS Studio. Enable Stereo Mix in Sound settings if not detected.");
    private static final class_2561 LINUX_AUDIO_INFO_TEXT = class_2561.method_43470("\u2139 Audio capture uses PulseAudio monitor source to record system audio directly.");
    private static final class_2561 MACOS_AUDIO_INFO_TEXT = class_2561.method_43470("\u2139 Audio capture uses AVFoundation. Install BlackHole for system audio capture.");
    private static final class_2561 ANDROID_AUDIO_INFO_TEXT = class_2561.method_43470("\u2139 Audio is captured directly from Minecraft's sound engine via OpenAL loopback. Full-volume game audio with zero noise.");
    private static final class_2561 STEREO_MIX_HELP_TEXT = class_2561.method_43470("Audio is captured via system loopback (Stereo Mix/PulseAudio). If no audio, enable Stereo Mix in Windows Sound settings.");

    private final class_437 parent;
    private final List<LayoutWidget> layoutWidgets = new ArrayList<>();

    private class_2561 statusMessage;
    private class_2561 ffmpegStatus;
    private boolean ffmpegStatusIsError;
    private boolean statusIsError;

    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelBottom;
    private int panelBodyTop;
    private int panelBodyBottom;
    private int footerY;

    private int contentHeight;
    private int scrollOffset;

    private int videoHeaderY;
    private int audioHeaderY;
    private int generalHeaderY;
    private int autoRecordHeaderY;
    private int appearanceHeaderY;
    private int advancedHeaderY;
    private int bitrateLabelY;
    private int performanceHintY;
    private int outputLabelY;
    private int outputPathY;
    private int ffmpegStatusY;
    private int diskSpaceInfoY;
    private int replayMemoryWarningY;
    private int windowsAudioWarningY;
    private int windowsAudioWarningHeight;

    public RecordableSettingsScreen(class_437 parent) {
        super(class_2561.method_43471("screen.recordable.settings.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.method_37067();
        this.layoutWidgets.clear();
        this.statusMessage = null;
        this.statusIsError = false;

        try {
            RecordableConfig config = RecordableConfig.get();
            if (config == null) {
                this.statusMessage = class_2561.method_43470("Record-able config is unavailable.");
                this.statusIsError = true;
                addFallbackCloseButton();
                return;
            }
            config.sanitize();

            FFmpegEncoder.FfmpegStatus status = FFmpegEncoder.detectFfmpeg();
            String platformLabel = PlatformUtils.detectPlatform().displayName();
            this.ffmpegStatus = class_2561.method_43470("Platform: " + platformLabel + " | FFmpeg: " + status.displayText());
            this.ffmpegStatusIsError = !status.found();

            this.panelWidth = Math.max(340, Math.min((int) (this.field_22789 * 0.78D), 760));
            this.panelLeft = (this.field_22789 - this.panelWidth) / 2;
            this.panelTop = Math.max(8, (int) (this.field_22790 * 0.04D));
            this.panelBottom = Math.min(this.field_22790 - 8, this.panelTop + Math.max(300, (int) (this.field_22790 * 0.90D)));
            this.panelBodyTop = this.panelTop + 24;
            this.footerY = this.panelBottom - 28;
            this.panelBodyBottom = this.footerY - 8;

            int widgetWidth = Math.max(180, this.panelWidth - 28);
            int widgetLeft = this.panelLeft + 14;
            int halfWidgetWidth = Math.max(88, (widgetWidth - 6) / 2);
            int rightWidgetLeft = widgetLeft + halfWidgetWidth + 6;
            int y = 0;

            addLayoutWidget(class_4185.method_46430(
                            class_2561.method_43471("screen.recordable.settings.open_video_collection"),
                            button -> {
                                if (this.field_22787 != null) {
                                    this.field_22787.method_1507(new VideoCollectionScreen(this));
                                }
                            }
                    ).method_46434(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT).method_46431(),
                    y);
            y += ROW_SPACING;

            // === Feature 3: Recording Profile Selector ===
            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43470("Profile: " + RecordableConfig.getProfileDisplayName(config.activeProfile)),
                    button -> {
                        String next = nextValue(RecordableConfig.PROFILES, config.activeProfile);
                        config.applyProfile(next);
                        saveConfigSafely(config);
                        button.method_25355(class_2561.method_43470("Profile: " + RecordableConfig.getProfileDisplayName(next)));
                        if (this.field_22787 != null) {
                            this.field_22787.method_1507(new RecordableSettingsScreen(this.parent));
                        }
                    }
            ).method_46434(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT)
                    .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(
                            "Quick recording profiles:\n"
                                    + "• Custom: Your manual settings\n"
                                    + "• High Quality: 1080p60, high bitrate\n"
                                    + "• Performance: 720p30, low CPU\n"
                                    + "• Streaming: 1080p60, 6M bitrate\n"
                                    + "• Quick Clip: 720p60, 100MB max")))
                    .method_46431(), y);
            y += ROW_SPACING;

            this.videoHeaderY = y;
            y += 12;
            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43470("Output: ." + config.getFormat()),
                    button -> {
                        String current = config.getFormat();
                        String next = nextValue(RecordableConfig.FORMATS, current);
                        config.format = next;
                        saveConfigSafely(config);
                        button.method_25355(class_2561.method_43470("Output: ." + config.getFormat()));
                    }
            ).method_46434(widgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT).method_46431(), y);
            addLayoutWidget(addCycleButton(rightWidgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.resolution", RecordableConfig.RESOLUTIONS,
                    () -> config.resolution, value -> {
                        config.resolution = value;
                        saveConfigSafely(config);
                    }), y);
            y += ROW_SPACING;

            addLayoutWidget(addCycleButton(widgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.quality", RecordableConfig.QUALITIES,
                    () -> config.quality, value -> {
                        config.quality = value;
                        saveConfigSafely(config);
                    }), y);
            addLayoutWidget(new FpsSlider(rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT, config.getFps(), value -> {
                config.fps = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            List<RecordableConfig.VideoEncoder> availableEncoders = FFmpegEncoder.detectAvailableEncoders();
            if (!availableEncoders.contains(config.encoder)) {
                config.encoder = RecordableConfig.VideoEncoder.SOFTWARE;
                saveConfigSafely(config);
            }
            addLayoutWidget(class_4185.method_46430(
                    cycleEncoderMessage(config.encoder),
                    button -> {
                        RecordableConfig.VideoEncoder next = nextEncoder(availableEncoders, config.encoder);
                        config.encoder = next;
                        saveConfigSafely(config);
                        button.method_25355(cycleEncoderMessage(next));
                    }
            ).method_46434(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT)
                    .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470("Select video encoder backend")))
                    .method_46431(), y);
            y += ROW_SPACING;

            {
                String encoderLabel = "Encoder: FFmpeg";
                if (!status.found()) {
                    encoderLabel += " (NOT FOUND)";
                }

                // If FFmpeg is not found, render the re-detect button half-width and
                // expose a "Download FFmpeg" button next to it. When it IS found, the
                // re-detect button gets the full width like before.
                if (!status.found()) {
                    addLayoutWidget(class_4185.method_46430(
                            class_2561.method_43470(encoderLabel),
                            button -> {
                                FFmpegEncoder.FfmpegStatus refreshed = FFmpegEncoder.detectFfmpeg();
                                String label = "Encoder: FFmpeg" + (refreshed.found() ? " ✓" : " (NOT FOUND)");
                                button.method_25355(class_2561.method_43470(label));
                                if (!refreshed.found()) {
                                    this.statusMessage = class_2561.method_43470("§cFFmpeg is required. " + PlatformUtils.getFfmpegInstallHint());
                                    this.statusIsError = true;
                                } else {
                                    this.statusMessage = class_2561.method_43470("✓ FFmpeg detected: " + refreshed.version());
                                    this.statusIsError = false;
                                }
                            }
                    ).method_46434(widgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT)
                            .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(
                                    "FFmpeg is the sole encoder. Click to re-detect after installing/downloading.\n\n"
                                            + "FFmpeg status: " + status.displayText() + "\n"
                                            + "Install: " + PlatformUtils.getFfmpegInstallHint())))
                            .method_46431(), y);

                    String dlLabel;
                    boolean autoOk = FfmpegBundleManager.isAutoDownloadSupported();
                    if (FfmpegBundleManager.isDownloading()) {
                        FfmpegBundleManager.DownloadProgress dp = FfmpegBundleManager.getLastProgress();
                        dlLabel = "Downloading… " + dp.displayPercent();
                    } else if (autoOk) {
                        dlLabel = "Download FFmpeg (" + FfmpegBundleManager.getEstimatedDownloadSize() + ")";
                    } else {
                        dlLabel = "FFmpeg Setup…";
                    }
                    String dlTip = autoOk
                            ? "Open the FFmpeg setup screen to download from "
                                    + FfmpegBundleManager.getDownloadSourceDescription()
                                    + ".\nFFmpeg is NOT bundled in this mod — first run downloads ~"
                                    + FfmpegBundleManager.getEstimatedDownloadSize()
                                    + " from a trusted upstream and verifies the hash."
                            : FfmpegBundleManager.getManualInstallInstructions();
                    addLayoutWidget(class_4185.method_46430(
                            class_2561.method_43470(dlLabel),
                            button -> {
                                if (this.field_22787 != null) {
                                    this.field_22787.method_1507(new FfmpegDownloadScreen(this));
                                }
                            }
                    ).method_46434(rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT)
                            .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(dlTip)))
                            .method_46431(), y);
                    y += ROW_SPACING;
                } else {
                    addLayoutWidget(class_4185.method_46430(
                            class_2561.method_43470(encoderLabel + " ✓"),
                            button -> {
                                FFmpegEncoder.FfmpegStatus refreshed = FFmpegEncoder.detectFfmpeg();
                                String label = "Encoder: FFmpeg" + (refreshed.found() ? " ✓" : " (NOT FOUND)");
                                button.method_25355(class_2561.method_43470(label));
                                if (!refreshed.found()) {
                                    this.statusMessage = class_2561.method_43470("§cFFmpeg is required. " + PlatformUtils.getFfmpegInstallHint());
                                    this.statusIsError = true;
                                } else {
                                    this.statusMessage = class_2561.method_43470("✓ FFmpeg detected: " + refreshed.version());
                                    this.statusIsError = false;
                                }
                            }
                    ).method_46434(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT)
                            .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(
                                    "FFmpeg is the sole encoder. Click to re-detect.\n\n"
                                            + "FFmpeg status: " + status.displayText() + "\n"
                                            + "Audio: System loopback (DirectShow/PulseAudio/AVFoundation)\n\n"
                                            + "Install FFmpeg: " + PlatformUtils.getFfmpegInstallHint())))
                            .method_46431(), y);
                    y += ROW_SPACING;
                }
            }

            this.bitrateLabelY = y;
            y += 10;
            class_342 bitrateField = new class_342(this.field_22793, widgetLeft, 0, widgetWidth, WIDGET_HEIGHT,
                    class_2561.method_43471("screen.recordable.settings.bitrate"));
            bitrateField.method_1880(16);
            bitrateField.method_1852(config.bitrate == null ? "auto" : config.bitrate);
            bitrateField.method_1863(value -> {
                config.bitrate = value == null || value.isBlank() ? "auto" : value.trim();
                saveConfigSafely(config);
            });
            addLayoutWidget(bitrateField, y);
            y += ROW_SPACING + 2;

            this.performanceHintY = y;
            y += 22;

            this.audioHeaderY = y;
            y += 12;
            addLayoutWidget(addBooleanToggle(widgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.capture_audio", config.captureAudio, value -> {
                config.captureAudio = value;
                saveConfigSafely(config);
            }), y);

            class_342 audioDeviceField = new class_342(this.field_22793, widgetLeft, 0, widgetWidth, WIDGET_HEIGHT,
                    class_2561.method_43470("Audio Device"));
            audioDeviceField.method_1880(128);
            audioDeviceField.method_1852(config.audioDevice == null ? "auto" : config.audioDevice);
            audioDeviceField.method_47404(class_2561.method_43470("auto"));
            audioDeviceField.method_1863(value -> {
                config.audioDevice = value == null || value.isBlank() ? "auto" : value.trim();
                saveConfigSafely(config);
                AudioCapture.clearCache();
            });

            FFmpegEncoder.FfmpegStatus ffStatus = FFmpegEncoder.detectFfmpeg();
            String ffExe = ffStatus.found() ? ffStatus.executable() : "ffmpeg";
            AudioCapture.AudioDeviceStatus initialAudioStatus = AudioCapture.detectAudioDevice(ffExe, config.audioDevice);
            boolean stereoMixDetected = initialAudioStatus.available();
            class_2561 audioLabelText = audioStatusText(stereoMixDetected);
            String audioTooltip = stereoMixDetected
                    ? initialAudioStatus.message() + "\nClick to re-scan audio devices."
                    : initialAudioStatus.message() + "\n" + STEREO_MIX_HELP_TEXT.getString();

            addLayoutWidget(class_4185.method_46430(
                            audioLabelText,
                            button -> {
                                AudioCapture.clearCache();
                                AudioCapture.AudioDeviceStatus refreshed = AudioCapture.detectAudioDevice(ffExe, "auto");
                                if (refreshed.available()) {
                                    config.audioDevice = refreshed.deviceName();
                                    saveConfigSafely(config);
                                    audioDeviceField.method_1852(refreshed.deviceName());
                                    button.method_25355(audioStatusText(true));
                                    button.method_47400(net.minecraft.class_7919.method_47407(
                                            class_2561.method_43470(refreshed.message() + "\nClick to re-scan audio devices.")));
                                    this.statusMessage = class_2561.method_43470("\u2705 Stereo Mix detected. Audio recording is enabled.");
                                    this.statusIsError = false;
                                } else {
                                    button.method_25355(audioStatusText(false));
                                    button.method_47400(net.minecraft.class_7919.method_47407(
                                            class_2561.method_43470(refreshed.message() + "\n" + STEREO_MIX_HELP_TEXT.getString())));
                                    this.statusMessage = class_2561.method_43470("\u26A0 Stereo Mix not detected. Video-only recording still works perfectly.");
                                    this.statusIsError = false;
                                    if (this.field_22787 != null && this.field_22787.field_1724 != null) {
                                        this.field_22787.field_1724.method_7353(
                                                class_2561.method_43470("⚠ Stereo Mix not found. Recording will continue in video-only mode."),
                                                false
                                        );
                                    }
                                }
                            }
                    ).method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(audioTooltip)))
                    .method_46434(rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT).method_46431(),
                    y);
            y += ROW_SPACING;

            addLayoutWidget(audioDeviceField, y);
            y += ROW_SPACING;

            String audioContainer = config.getContainerFromFormat();
            List<RecordableConfig.AudioEncoder> detectedAudioEncoders = FFmpegEncoder.detectAvailableAudioEncoders();
            List<RecordableConfig.AudioEncoder> compatibleAudioEncoders = detectedAudioEncoders.stream()
                    .filter(encoder -> encoder.supportsContainer(audioContainer))
                    .toList();
            if (compatibleAudioEncoders.isEmpty()) {
                RecordableMod.LOGGER.warn("No detected audio encoders support container {}. Falling back to config enum values.", audioContainer);
                compatibleAudioEncoders = java.util.Arrays.stream(RecordableConfig.AudioEncoder.values())
                        .filter(encoder -> encoder.supportsContainer(audioContainer))
                        .toList();
            }
            if (compatibleAudioEncoders.isEmpty()) {
                compatibleAudioEncoders = List.of(RecordableConfig.AudioEncoder.AAC);
            }
            final List<RecordableConfig.AudioEncoder> availableAudioEncoders = compatibleAudioEncoders;
            RecordableMod.LOGGER.info("Audio encoder options for container {}: {}", audioContainer,
                    availableAudioEncoders.stream().map(encoder -> encoder.displayName).toList());
            if (!availableAudioEncoders.contains(config.audioEncoder)) {
                config.audioEncoder = availableAudioEncoders.get(0);
                saveConfigSafely(config);
            }
            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43470("Audio Encoder: " + config.audioEncoder.displayName),
                    button -> {
                        RecordableConfig.AudioEncoder next = nextAudioEncoder(availableAudioEncoders, config.audioEncoder);
                        config.audioEncoder = next;
                        saveConfigSafely(config);
                        if (this.field_22787 != null) {
                            this.field_22787.method_1507(new RecordableSettingsScreen(this.parent));
                        }
                    }
            ).method_46434(widgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT)
                    .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470("Choose audio codec (container-compatible options only)")))
                    .method_46431(), y);

            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43470("Sample Rate: " + config.audioSampleRate + " Hz"),
                    button -> {
                        config.audioSampleRate = (config.audioSampleRate == 44100) ? 48000 : 44100;
                        saveConfigSafely(config);
                        button.method_25355(class_2561.method_43470("Sample Rate: " + config.audioSampleRate + " Hz"));
                    }
            ).method_46434(rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT).method_46431(), y);
            y += ROW_SPACING;

            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43470("Channels: " + (config.audioChannelCount == 1 ? "Mono" : "Stereo")),
                    button -> {
                        config.audioChannelCount = config.audioChannelCount == 1 ? 2 : 1;
                        config.audioChannels = config.audioChannelCount == 1 ? "mono" : "stereo";
                        saveConfigSafely(config);
                        button.method_25355(class_2561.method_43470("Channels: " + (config.audioChannelCount == 1 ? "Mono" : "Stereo")));
                    }
            ).method_46434(widgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT).method_46431(), y);

            class_342 audioBitrateField = new class_342(this.field_22793, rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT,
                    class_2561.method_43471("screen.recordable.settings.audio_bitrate"));
            audioBitrateField.method_1880(4);
            audioBitrateField.method_1852(Integer.toString(config.audioBitrateKbps));
            audioBitrateField.method_47404(class_2561.method_43470("192 kbps"));
            audioBitrateField.method_1863(value -> {
                if (value == null || value.isBlank()) {
                    config.audioBitrateKbps = config.audioEncoder.defaultBitrateKbps > 0 ? config.audioEncoder.defaultBitrateKbps : 192;
                } else {
                    try {
                        config.audioBitrateKbps = Math.max(32, Math.min(512, Integer.parseInt(value.trim())));
                    } catch (NumberFormatException ignored) {
                        return;
                    }
                }
                saveConfigSafely(config);
            });
            audioBitrateField.field_22763 = !config.audioEncoder.isLossless();
            addLayoutWidget(audioBitrateField, y);
            y += ROW_SPACING;

            addLayoutWidget(new AudioVolumeSlider(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT, config.audioVolume, value -> {
                config.audioVolume = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            addLayoutWidget(new AudioBoostSlider(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT, config.audioVolumeBoostDb, value -> {
                config.audioVolumeBoostDb = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            // === Audio Delay Preset ===
            addLayoutWidget(class_4185.method_46430(
                    audioDelayPresetMessage(config.audioDelayPreset, config.getEffectiveAudioDelay()),
                    button -> {
                        config.audioDelayPreset = config.audioDelayPreset.next();
                        saveConfigSafely(config);
                        if (this.field_22787 != null) {
                            this.field_22787.method_1507(new RecordableSettingsScreen(this.parent));
                        }
                    }
            ).method_46434(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT)
                    .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(
                            "Fine-tune audio sync if needed. Usually not required.\n\n"
                                    + "• Auto: 0ms (recommended, sync is handled automatically)\n"
                                    + "• None: 0ms (same as Auto, explicit zero)\n"
                                    + "• Desktop: 46ms (legacy, for unusual audio drivers)\n"
                                    + "• Android: 60ms (legacy, for mobile latency)\n"
                                    + "• Custom: Set your own value with the slider below\n\n"
                                    + "If audio is ahead of video, increase the delay.\n"
                                    + "If audio is behind video, decrease the delay.")))
                    .method_46431(), y);
            y += ROW_SPACING;

            // Custom delay slider (only active when CUSTOM preset is selected)
            AudioDelaySlider audioDelaySlider = new AudioDelaySlider(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT,
                    config.audioSyncOffsetMs, value -> {
                config.audioSyncOffsetMs = value;
                saveConfigSafely(config);
            });
            audioDelaySlider.field_22763 = config.audioDelayPreset == RecordableConfig.AudioDelayPreset.CUSTOM;
            addLayoutWidget(audioDelaySlider, y);
            y += ROW_SPACING;

            int halfAudioButtonWidth = Math.max(88, (widgetWidth - 6) / 2);
            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43471("screen.recordable.settings.how_to_fix_audio"),
                    button -> {
                        if (this.field_22787 != null) {
                            this.field_22787.method_1507(new AudioHelpScreen(this));
                        }
                    }
            ).method_46436(net.minecraft.class_7919.method_47407(
                    class_2561.method_43470(STEREO_MIX_HELP_TEXT.getString() + "\nVideo-only recording always works.")))
                    .method_46434(widgetLeft, 0, halfAudioButtonWidth, WIDGET_HEIGHT).method_46431(), y);

            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43471("screen.recordable.settings.test_audio"),
                    button -> testAudioCapture(button)
            ).method_46434(widgetLeft + halfAudioButtonWidth + 6, 0, halfAudioButtonWidth, WIDGET_HEIGHT).method_46431(), y);
            y += ROW_SPACING + 4;

            this.windowsAudioWarningY = y;
            int warningWrapWidth = Math.max(160, this.panelWidth - 28);
            class_2561 platformWarningText = getPlatformAudioWarningText();
            if (platformWarningText != null) {
                int warningLineCount = Math.max(1, this.field_22793.method_1728(platformWarningText, warningWrapWidth).size());
                int lineHeight = this.field_22793.field_2000 + 1;
                this.windowsAudioWarningHeight = warningLineCount * lineHeight + 4;
            } else {
                this.windowsAudioWarningHeight = 0;
            }
            y += this.windowsAudioWarningHeight + 6;

            this.generalHeaderY = y;
            y += 12;
            addLayoutWidget(addBooleanToggle(widgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.enabled", config.enabled, value -> {
                config.enabled = value;
                saveConfigSafely(config);
            }), y);
            addLayoutWidget(addBooleanToggle(rightWidgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.overlay", config.showOverlay, value -> {
                config.showOverlay = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            class_339 stopOnDisconnectToggle = addBooleanToggle(widgetLeft, 0, halfWidgetWidth,
                    "screen.recordable.settings.stop_on_disconnect", config.stopOnDisconnect, value -> {
                        config.stopOnDisconnect = value;
                        saveConfigSafely(config);
                    });
            stopOnDisconnectToggle.method_47400(net.minecraft.class_7919.method_47407(
                    class_2561.method_43471("screen.recordable.settings.stop_on_disconnect.tooltip")));
            addLayoutWidget(stopOnDisconnectToggle, y);
            addLayoutWidget(addBooleanToggle(rightWidgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.show_home_button", config.showHomeButton, value -> {
                config.showHomeButton = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            addLayoutWidget(addBooleanToggle(widgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.show_performance_stats", config.showPerformanceStats, value -> {
                config.showPerformanceStats = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            // === Overlay Position & Scale (in General section for discoverability) ===
            addLayoutWidget(class_4185.method_46430(
                    class_2561.method_43470("Overlay Position: " + config.overlayPosition.displayName),
                    button -> {
                        config.overlayPosition = config.overlayPosition.next();
                        saveConfigSafely(config);
                        button.method_25355(class_2561.method_43470("Overlay Position: " + config.overlayPosition.displayName));
                    }
            ).method_46434(widgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT)
                    .method_46436(net.minecraft.class_7919.method_47407(class_2561.method_43470(
                            "Where to place the recording overlay on screen.\n\n"
                                    + "- Top-Left: Classic position\n"
                                    + "- Top-Right: Right side\n"
                                    + "- Bottom-Left: Lower left\n"
                                    + "- Bottom-Right: Lower right\n"
                                    + "- Center-Top: Centered, below boss bars")))
                    .method_46431(), y);
            addLayoutWidget(new OverlayScaleSlider(rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT, config.overlayScale, value -> {
                config.overlayScale = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            this.outputLabelY = y;
            y += 10;
            class_342 outputDirField = new class_342(this.field_22793, widgetLeft, 0, widgetWidth, WIDGET_HEIGHT,
                    class_2561.method_43471("screen.recordable.settings.output_dir"));
            outputDirField.method_1880(256);
            outputDirField.method_1852(config.outputDir == null ? "recordings" : config.outputDir);
            outputDirField.method_1863(value -> {
                config.outputDir = value == null || value.isBlank() ? "recordings" : value.trim();
                saveConfigSafely(config);
            });
            addLayoutWidget(outputDirField, y);
            this.outputPathY = y + WIDGET_HEIGHT + 2;
            y += ROW_SPACING + 12;

            addLayoutWidget(new MaxFileSizeSlider(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT, config.maxFileSizeMB, value -> {
                config.maxFileSizeMB = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING + 2;

            this.autoRecordHeaderY = y;
            y += 12;
            addLayoutWidget(addBooleanToggle(widgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.auto_record.enabled", config.autoRecord, value -> {
                config.autoRecord = value;
                saveConfigSafely(config);
            }), y);
            addLayoutWidget(addCycleButton(rightWidgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.auto_record.start_trigger", RecordableConfig.AUTO_RECORD_TRIGGERS,
                    () -> config.autoRecordTrigger, value -> {
                        config.autoRecordTrigger = value;
                        saveConfigSafely(config);
                    }), y);
            y += ROW_SPACING;

            addLayoutWidget(addCycleButton(widgetLeft, 0, halfWidgetWidth, "screen.recordable.settings.auto_record.stop_trigger", RecordableConfig.AUTO_STOP_TRIGGERS,
                    () -> config.autoStopTrigger, value -> {
                        config.autoStopTrigger = value;
                        saveConfigSafely(config);
                    }), y);
            addLayoutWidget(new AutoDelaySlider(rightWidgetLeft, 0, halfWidgetWidth, WIDGET_HEIGHT, config.autoRecordDelay, value -> {
                config.autoRecordDelay = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING + 2;

            this.appearanceHeaderY = y;
            y += 20;
            addLayoutWidget(new ColorPickerWidget(
                    this.field_22793,
                    widgetLeft,
                    0,
                    widgetWidth,
                    ColorPickerWidget.WIDGET_HEIGHT,
                    class_2561.method_43471("screen.recordable.settings.overlay_color"),
                    config.overlayColor,
                    value -> {
                        config.overlayColor = value;
                        saveConfigSafely(config);
                    }
            ), y);
            y += 24;
            addLayoutWidget(new ColorPickerWidget(
                    this.field_22793,
                    widgetLeft,
                    0,
                    widgetWidth,
                    ColorPickerWidget.WIDGET_HEIGHT,
                    class_2561.method_43471("screen.recordable.settings.menu_accent_color"),
                    config.menuAccentColor,
                    value -> {
                        config.menuAccentColor = value;
                        saveConfigSafely(config);
                    }
            ), y);
            y += 24;

            // Overlay Position & Scale are now in the General section above for easier access
            y += 6;

            // === Advanced Features Section ===
            this.advancedHeaderY = y;
            y += 12;

            // Feature 6: Toast Notification toggle
            addLayoutWidget(addBooleanToggle(widgetLeft, 0, halfWidgetWidth,
                    "screen.recordable.settings.show_toast", config.showPostRecordingToast, value -> {
                        config.showPostRecordingToast = value;
                        saveConfigSafely(config);
                    }), y);

            // Feature 8: Recording Timer toggle
            addLayoutWidget(addBooleanToggle(rightWidgetLeft, 0, halfWidgetWidth,
                    "screen.recordable.settings.show_timer", config.showRecordingTimer, value -> {
                        config.showRecordingTimer = value;
                        saveConfigSafely(config);
                    }), y);
            y += ROW_SPACING;

            // Feature 8: Show estimated file size
            addLayoutWidget(addBooleanToggle(widgetLeft, 0, halfWidgetWidth,
                    "screen.recordable.settings.show_est_size", config.showEstimatedFileSize, value -> {
                        config.showEstimatedFileSize = value;
                        saveConfigSafely(config);
                    }), y);

            // Feature 7: Replay Buffer toggle
            addLayoutWidget(addBooleanToggle(rightWidgetLeft, 0, halfWidgetWidth,
                    "screen.recordable.settings.replay_buffer", config.replayBufferEnabled, value -> {
                        config.replayBufferEnabled = value;
                        saveConfigSafely(config);
                        if (!value) {
                            ReplayBuffer.getInstance().stop();
                        }
                    }), y);
            y += ROW_SPACING;

            // Feature 7: Replay Buffer Duration slider
            addLayoutWidget(new ReplayBufferSlider(widgetLeft, 0, widgetWidth, WIDGET_HEIGHT,
                    config.replayBufferDurationSeconds, value -> {
                config.replayBufferDurationSeconds = value;
                saveConfigSafely(config);
            }), y);
            y += ROW_SPACING;

            // Memory impact warning for replay buffer
            this.replayMemoryWarningY = y;
            y += 14;

            // Feature 5: Disk Space Info
            this.diskSpaceInfoY = y;
            y += 14;

            this.ffmpegStatusY = y;
            y += 18;

            this.contentHeight = y;

            int halfButtonWidth = Math.max(84, (widgetWidth - 6) / 2);
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43471("screen.recordable.settings.open_folder"),
                    button -> openRecordingsFolder()
            ).method_46434(widgetLeft, this.footerY, halfButtonWidth, WIDGET_HEIGHT).method_46431());
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43471("screen.recordable.settings.done"),
                    button -> saveAndClose()
            ).method_46434(widgetLeft + halfButtonWidth + 6, this.footerY, halfButtonWidth, WIDGET_HEIGHT).method_46431());

            updateWidgetLayout();
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.error("Failed to initialize Record-able settings screen.", throwable);
            this.statusMessage = class_2561.method_43470("Failed to open settings. Check logs for details.");
            this.statusIsError = true;
            addFallbackCloseButton();
        }
    }

    private void addLayoutWidget(class_339 widget, int baseY) {
        this.layoutWidgets.add(new LayoutWidget(widget, baseY));
        this.method_37063(widget);
    }

    private void addFallbackCloseButton() {
        int buttonWidth = 150;
        int x = (this.field_22789 - buttonWidth) / 2;
        int y = Math.max(24, this.field_22790 - 34);
        this.panelWidth = Math.max(220, buttonWidth + 40);
        this.panelLeft = (this.field_22789 - this.panelWidth) / 2;
        this.panelTop = Math.max(8, y - 48);
        this.panelBottom = Math.min(this.field_22790 - 6, y + WIDGET_HEIGHT + 12);
        this.panelBodyTop = this.panelTop + 24;
        this.panelBodyBottom = y - 6;
        this.footerY = y;
        this.contentHeight = 0;
        this.videoHeaderY = this.panelTop + 24;
        this.audioHeaderY = this.videoHeaderY;
        this.generalHeaderY = this.videoHeaderY;
        this.autoRecordHeaderY = this.videoHeaderY;
        this.appearanceHeaderY = this.videoHeaderY;
        this.advancedHeaderY = this.videoHeaderY;
        this.bitrateLabelY = this.videoHeaderY + 12;
        this.performanceHintY = this.bitrateLabelY + 12;
        this.outputLabelY = this.performanceHintY + 12;
        this.outputPathY = this.outputLabelY + 12;
        this.diskSpaceInfoY = this.outputPathY + 12;
        this.ffmpegStatusY = this.diskSpaceInfoY + 12;
        this.windowsAudioWarningY = this.ffmpegStatusY + 12;
        this.windowsAudioWarningHeight = 0;
        this.method_37063(class_4185.method_46430(class_2561.method_43471("screen.recordable.settings.done"), button -> saveAndClose())
                .method_46434(x, y, buttonWidth, WIDGET_HEIGHT)
                .method_46431());
    }

    private class_339 addCycleButton(int x, int y, int width, String translationKey, String[] values,
                                           Supplier<String> getter, Consumer<String> setter) {
        return class_4185.method_46430(
                cycleMessage(translationKey, getter.get()),
                button -> {
                    String next = nextValue(values, getter.get());
                    try {
                        setter.accept(next);
                        button.method_25355(cycleMessage(translationKey, next));
                    } catch (Throwable throwable) {
                        RecordableMod.LOGGER.warn("Failed to update setting {} to {}.", translationKey, next, throwable);
                    }
                }
        ).method_46434(x, y, width, WIDGET_HEIGHT).method_46431();
    }

    private class_339 addBooleanToggle(int x, int y, int width, String translationKey, boolean value, Consumer<Boolean> setter) {
        return class_5676.method_32614(value).method_32617(
                x,
                y,
                width,
                WIDGET_HEIGHT,
                class_2561.method_43471(translationKey),
                (button, newValue) -> {
                    try {
                        setter.accept(newValue);
                    } catch (Throwable throwable) {
                        RecordableMod.LOGGER.warn("Failed to update setting {} to {}.", translationKey, newValue, throwable);
                    }
                }
        );
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX < this.panelLeft || mouseX > this.panelLeft + this.panelWidth || mouseY < this.panelBodyTop || mouseY > this.panelBodyBottom) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        int maxScroll = Math.max(0, this.contentHeight - (this.panelBodyBottom - this.panelBodyTop));
        if (maxScroll <= 0) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        int delta = (int) Math.round(verticalAmount * -20.0D);
        if (delta == 0) {
            delta = verticalAmount > 0 ? -20 : 20;
        }
        this.scrollOffset = Math.max(0, Math.min(maxScroll, this.scrollOffset + delta));
        updateWidgetLayout();
        return true;
    }

    @Override
    public boolean method_25404(class_11908 keyInput) {
        int keyCode = keyInput.comp_4795();
        if (keyCode == 264) {
            this.scrollOffset += ROW_SPACING;
            updateWidgetLayout();
            return true;
        }
        if (keyCode == 265) {
            this.scrollOffset -= ROW_SPACING;
            updateWidgetLayout();
            return true;
        }
        return super.method_25404(keyInput);
    }

    private void updateWidgetLayout() {
        int maxScroll = Math.max(0, this.contentHeight - (this.panelBodyBottom - this.panelBodyTop));
        this.scrollOffset = Math.max(0, Math.min(maxScroll, this.scrollOffset));

        for (LayoutWidget item : this.layoutWidgets) {
            int y = this.panelBodyTop + item.baseY - this.scrollOffset;
            class_339 widget = item.widget;
            if (widget instanceof ColorPickerWidget colorPickerWidget) {
                colorPickerWidget.method_48229(widget.method_46426(), y);
            } else {
                widget.method_46419(y);
            }

            boolean visible = y + widget.method_25364() >= this.panelBodyTop && y <= this.panelBodyBottom;
            widget.field_22764 = visible;
            widget.field_22763 = visible;
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);

        int accent = 0xFF000000 | RecordableConfig.get().getMenuAccentColorRgb();
        int left = this.panelLeft - 6;
        int right = this.panelLeft + this.panelWidth + 6;
        context.method_25294(left, this.panelTop - 6, right, this.panelBottom, PANEL_COLOR);
        context.method_25294(left, this.panelTop - 6, right, this.panelTop - 5, accent);
        context.method_25294(left, this.panelBottom - 1, right, this.panelBottom, PANEL_BORDER_COLOR);
        context.method_25294(left, this.panelTop - 6, left + 1, this.panelBottom, PANEL_BORDER_COLOR);
        context.method_25294(right - 1, this.panelTop - 6, right, this.panelBottom, PANEL_BORDER_COLOR);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.panelTop, 0xFFFFFFFF);

        super.method_25394(context, mouseX, mouseY, delta);

        drawHeader(context, "screen.recordable.settings.video", this.videoHeaderY);
        drawHeader(context, "screen.recordable.settings.audio", this.audioHeaderY);
        drawHeader(context, "screen.recordable.settings.general", this.generalHeaderY);
        drawHeader(context, "screen.recordable.settings.auto_record.section", this.autoRecordHeaderY);
        drawHeader(context, "screen.recordable.settings.appearance", this.appearanceHeaderY);
        drawHeader(context, "screen.recordable.settings.advanced", this.advancedHeaderY);

        drawLabel(context, class_2561.method_43471("screen.recordable.settings.bitrate_hint"), this.bitrateLabelY, MUTED_TEXT_COLOR);
        String perfHint = RecordableConfig.get().getPerformanceHint();
        int perfHintColor = perfHint.contains("drop") || perfHint.contains("expensive") ? 0xFFFFCC66 : MUTED_TEXT_COLOR;
        drawWrappedLabel(context, class_2561.method_43470("Performance: " + perfHint), this.performanceHintY, this.panelWidth - 28, perfHintColor);
        drawLabel(context, class_2561.method_43471("screen.recordable.settings.output_dir"), this.outputLabelY, MUTED_TEXT_COLOR);
        drawWrappedLabel(context, class_2561.method_43470(getDisplayOutputPath()), this.outputPathY, this.panelWidth - 28, MUTED_TEXT_COLOR);

        if (this.windowsAudioWarningHeight > 0) {
            class_2561 platformWarning = getPlatformAudioWarningText();
            if (platformWarning != null) {
                int warningColor = 0xFFFFCC66;
                drawWrappedLabel(context, platformWarning, this.windowsAudioWarningY,
                        this.panelWidth - 28, warningColor);
            }
        }

        // Replay buffer memory estimate
        try {
            RecordableConfig replayConfig = RecordableConfig.get();
            if (replayConfig.replayBufferEnabled) {
                // Estimate based on configured resolution (assume 1920x1080 for native/1080p, 1280x720 for 720p)
                int estWidth = "720p".equals(replayConfig.resolution) ? 1280
                        : "480p".equals(replayConfig.resolution) ? 854 : 1920;
                int estHeight = "720p".equals(replayConfig.resolution) ? 720
                        : "480p".equals(replayConfig.resolution) ? 480 : 1080;
                String memEstimate = ReplayBuffer.getMemoryEstimate(estWidth, estHeight,
                        replayConfig.fps, replayConfig.replayBufferDurationSeconds);
                int memColor = PlatformUtils.isMobileDevice() ? 0xFFFF6600 : MUTED_TEXT_COLOR;
                String prefix = PlatformUtils.isMobileDevice() ? "⚠ RAM: " : "RAM: ";
                drawLabel(context, class_2561.method_43470(prefix + memEstimate), this.replayMemoryWarningY, memColor);
            } else {
                drawLabel(context, class_2561.method_43470("Replay Buffer: OFF"), this.replayMemoryWarningY, MUTED_TEXT_COLOR);
            }
        } catch (Exception ignored) {}

        // Feature 5: Disk Space Info
        try {
            String diskInfo = "Disk: " + DiskSpaceGuardian.getFormattedFreeSpace(RecordableConfig.get().getOutputDirectory()) + " free";
            drawLabel(context, class_2561.method_43470(diskInfo), this.diskSpaceInfoY, MUTED_TEXT_COLOR);
        } catch (Exception ignored) {}

        if (this.ffmpegStatus != null) {
            drawWrappedLabel(context, this.ffmpegStatus, this.ffmpegStatusY, this.panelWidth - 28, this.ffmpegStatusIsError ? ERROR_TEXT_COLOR : MUTED_TEXT_COLOR);
        }

        if (this.statusMessage != null) {
            context.method_27534(
                    this.field_22793,
                    this.statusMessage,
                    this.field_22789 / 2,
                    this.panelBottom - 12,
                    this.statusIsError ? ERROR_TEXT_COLOR : MUTED_TEXT_COLOR
            );
        }

        renderScrollbar(context, accent);
    }

    private void drawHeader(class_332 context, String key, int baseY) {
        int y = this.panelBodyTop + baseY - this.scrollOffset;
        if (y < this.panelBodyTop - 12 || y > this.panelBodyBottom + 2) {
            return;
        }
        context.method_27535(this.field_22793, class_2561.method_43471(key), this.panelLeft + 14, y, HEADER_COLOR);
    }

    private void drawLabel(class_332 context, class_2561 text, int baseY, int color) {
        drawLabel(context, text, baseY, color, this.panelLeft + 14);
    }

    private void drawLabel(class_332 context, class_2561 text, int baseY, int color, int x) {
        int y = this.panelBodyTop + baseY - this.scrollOffset;
        if (y < this.panelBodyTop - 12 || y > this.panelBodyBottom + 2) {
            return;
        }
        context.method_27535(this.field_22793, text, x, y, color);
    }

    private void drawWrappedLabel(class_332 context, class_2561 text, int baseY, int wrapWidth, int color) {
        int y = this.panelBodyTop + baseY - this.scrollOffset;
        if (y < this.panelBodyTop - 18 || y > this.panelBodyBottom + 2) {
            return;
        }
        context.method_65179(this.field_22793, text, this.panelLeft + 14, y, wrapWidth, color);
    }

    private void renderScrollbar(class_332 context, int accent) {
        int viewportHeight = this.panelBodyBottom - this.panelBodyTop;
        int maxScroll = Math.max(0, this.contentHeight - viewportHeight);
        if (maxScroll <= 0) {
            return;
        }

        int barLeft = this.panelLeft + this.panelWidth - 4;
        int barRight = barLeft + 2;
        context.method_25294(barLeft, this.panelBodyTop, barRight, this.panelBodyBottom, 0xFF2A2A2A);

        int thumbHeight = Math.max(22, (int) (viewportHeight * (viewportHeight / (double) this.contentHeight)));
        int available = viewportHeight - thumbHeight;
        int thumbTop = this.panelBodyTop + (int) ((this.scrollOffset / (double) maxScroll) * available);
        context.method_25294(barLeft, thumbTop, barRight, thumbTop + thumbHeight, accent);
    }

    @Override
    public void method_25419() {
        saveAndClose();
    }

    private static class_2561 cycleEncoderMessage(RecordableConfig.VideoEncoder encoder) {
        RecordableConfig.VideoEncoder value = encoder == null
                ? RecordableConfig.VideoEncoder.SOFTWARE
                : encoder;
        return class_2561.method_43470("Video Encoder: " + value.displayName);
    }

    private static RecordableConfig.VideoEncoder nextEncoder(List<RecordableConfig.VideoEncoder> values,
                                                             RecordableConfig.VideoEncoder current) {
        if (values == null || values.isEmpty()) {
            return RecordableConfig.VideoEncoder.SOFTWARE;
        }

        int index = values.indexOf(current);
        if (index < 0) {
            return values.get(0);
        }
        return values.get((index + 1) % values.size());
    }

    private static RecordableConfig.AudioEncoder nextAudioEncoder(List<RecordableConfig.AudioEncoder> values,
                                                                  RecordableConfig.AudioEncoder current) {
        if (values == null || values.isEmpty()) {
            return RecordableConfig.AudioEncoder.AAC;
        }

        int index = values.indexOf(current);
        if (index < 0) {
            return values.get(0);
        }
        return values.get((index + 1) % values.size());
    }

    private static class_2561 cycleMessage(String translationKey, String value) {
        String normalized = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        if (translationKey.startsWith("screen.recordable.settings.auto_record.")) {
            class_2561 translatedValue = class_2561.method_43471(translationKey + ".value." + normalized);
            return class_2561.method_43469(translationKey, translatedValue);
        }
        return class_2561.method_43469(translationKey, class_2561.method_43470(displayValue(value)));
    }

    private static String displayValue(String value) {
        if (value == null || value.isBlank()) {
            return "?";
        }
        if (value.length() <= 4) {
            return value.toUpperCase(Locale.ROOT);
        }
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    private static String nextValue(String[] values, String current) {
        if (values == null || values.length == 0) {
            return current;
        }
        for (int index = 0; index < values.length; index++) {
            if (values[index].equalsIgnoreCase(current == null ? "" : current)) {
                return values[(index + 1) % values.length];
            }
        }
        return values[0];
    }

    private static String truncateDeviceName(String name, int maxLen) {
        if (name == null) return "?";
        if (name.length() <= maxLen) return name;
        return name.substring(0, maxLen - 3) + "...";
    }

    private static class_2561 audioDelayPresetMessage(RecordableConfig.AudioDelayPreset preset, int effectiveMs) {
        if (preset == null) preset = RecordableConfig.AudioDelayPreset.AUTO;
        return class_2561.method_43470("Audio Delay: " + preset.displayName + " (" + effectiveMs + "ms)");
    }

    private static class_2561 audioStatusText(boolean detected) {
        if (detected) {
            String method = PlatformUtils.getAudioMethodDescription();
            return class_2561.method_43470("Audio: " + method + " Detected ✓")
                    .method_27694(style -> style.method_36139(0x66FF66));
        }
        return class_2561.method_43470("Audio: Not Available - Video Only")
                .method_27694(style -> style.method_36139(0xFFCC66));
    }

    /**
     * Returns the appropriate audio warning/info text for the current platform,
     * or {@code null} if no platform-specific message is needed.
     */
    private static class_2561 getPlatformAudioWarningText() {
        if (PlatformUtils.isAndroid()) {
            return ANDROID_AUDIO_INFO_TEXT;
        }
        if (PlatformUtils.isWindows()) {
            return WINDOWS_AUDIO_WARNING_TEXT;
        }
        if (PlatformUtils.isLinux()) {
            return LINUX_AUDIO_INFO_TEXT;
        }
        if (PlatformUtils.isMacOS()) {
            return MACOS_AUDIO_INFO_TEXT;
        }
        return null;
    }

    private static void saveConfigSafely(RecordableConfig config) {
        if (config == null) {
            return;
        }
        try {
            config.save();
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to save Record-able config from settings screen.", throwable);
        }
    }

    /**
     * Tests audio capture by probing the detected audio device via FFmpeg.
     */
    private void testAudioCapture(class_4185 button) {
        if (button != null) {
            button.field_22763 = false;
            button.method_25355(class_2561.method_43470("Testing..."));
        }

        Thread testThread = new Thread(() -> {
            try {
                RecordableConfig config = RecordableConfig.get();
                if (config == null) {
                    setTestResult("Config unavailable.", true, button);
                    return;
                }

                FFmpegEncoder.FfmpegStatus ffStatus = FFmpegEncoder.detectFfmpeg();
                if (!ffStatus.found()) {
                    setTestResult("FFmpeg not found. Cannot test audio.", true, button);
                    return;
                }

                AudioCapture.clearCache();
                AudioCapture.AudioDeviceStatus audioStatus = AudioCapture.detectAudioDevice(
                        ffStatus.executable(), config.audioDevice);

                if (!audioStatus.available()) {
                    setTestResult("No audio device detected: " + audioStatus.message(), true, button);
                    return;
                }

                boolean testResult = AudioCapture.testAudioDevice(ffStatus.executable(), audioStatus);
                if (testResult) {
                    setTestResult("\u2705 Audio test passed! Device: " + audioStatus.deviceName(), false, button);
                } else {
                    onTestAudioFailed();
                    setTestResult("\u26A0 Audio device found but probe failed: " + audioStatus.deviceName() + ". Check 'How to Fix Audio'.", true, button);
                }
            } catch (Exception e) {
                RecordableMod.LOGGER.warn("Audio test exception", e);
                setTestResult("Audio test error: " + e.getMessage(), true, button);
            }
        }, "Record-able Audio Test");
        testThread.setDaemon(true);
        testThread.start();
    }

    private void setTestResult(String message, boolean isError, class_4185 button) {
        if (this.field_22787 != null) {
            this.field_22787.execute(() -> {
                this.statusMessage = class_2561.method_43470(message);
                this.statusIsError = isError;
                if (button != null) {
                    button.method_25355(class_2561.method_43471("screen.recordable.settings.test_audio"));
                    button.field_22763 = true;
                }
            });
        }
    }

    private void onTestAudioFailed() {
        if (this.field_22787 == null || this.field_22787.field_1724 == null) {
            return;
        }

        this.field_22787.execute(() -> {
            this.field_22787.field_1724.method_7353(class_2561.method_43470("⚠ Audio test failed. Try these fixes:"), false);
            this.field_22787.field_1724.method_7353(class_2561.method_43470("1) Enable Stereo Mix: Sound settings → Recording → Show Disabled Devices → Enable"), false);
            this.field_22787.field_1724.method_7353(class_2561.method_43470("2) Click Re-scan Audio, then run Test Audio again"), false);
            this.field_22787.field_1724.method_7353(class_2561.method_43470("3) If audio is still unavailable, keep recording in video-only mode"), false);
            this.field_22787.field_1724.method_7353(class_2561.method_43470("Tip: Use the Volume slider to boost quiet audio (up to 200%)."), false);
        });
    }

    private void saveAndClose() {
        saveConfigSafely(RecordableConfig.get());
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    private String getDisplayOutputPath() {
        try {
            return RecordingManager.getInstance().getCurrentOutputDirectory().toString();
        } catch (Throwable throwable) {
            return "(output path unavailable)";
        }
    }

    private void openRecordingsFolder() {
        Path folder;
        try {
            RecordableConfig.get().save();
            folder = RecordingManager.getInstance().getCurrentOutputDirectory();
            Files.createDirectories(folder);
            class_156.method_668().method_60932(folder);
            this.statusMessage = class_2561.method_43471("screen.recordable.settings.opened_folder");
            this.statusIsError = false;
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to open Record-able recordings folder.", throwable);
            this.statusMessage = class_2561.method_43471("screen.recordable.settings.open_folder_failed");
            this.statusIsError = true;
        }
    }

    private record LayoutWidget(class_339 widget, int baseY) {
    }

    private static final class FpsSlider extends class_357 {
        private final IntConsumer setter;

        private FpsSlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalizeFps(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43469("screen.recordable.settings.fps", getCurrentFps()));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentFps());
            method_25346();
        }

        private int getCurrentFps() {
            int index = (int) Math.round(this.field_22753 * (RecordableConfig.FPS_VALUES.length - 1));
            index = Math.max(0, Math.min(RecordableConfig.FPS_VALUES.length - 1, index));
            return RecordableConfig.FPS_VALUES[index];
        }

        private static double normalizeFps(int fps) {
            for (int index = 0; index < RecordableConfig.FPS_VALUES.length; index++) {
                if (RecordableConfig.FPS_VALUES[index] == fps) {
                    return index / (double) (RecordableConfig.FPS_VALUES.length - 1);
                }
            }
            return 0.5D;
        }
    }

    private static final class MaxFileSizeSlider extends class_357 {
        private static final int MAX_MB = 10_240;
        private final IntConsumer setter;

        private MaxFileSizeSlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            int value = getCurrentValue();
            this.method_25355(value <= 0
                    ? class_2561.method_43471("screen.recordable.settings.max_file_size.unlimited")
                    : class_2561.method_43469("screen.recordable.settings.max_file_size", value));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentValue());
            method_25346();
        }

        private int getCurrentValue() {
            int rounded = (int) Math.round(this.field_22753 * (MAX_MB / 100.0D)) * 100;
            return Math.max(0, Math.min(MAX_MB, rounded));
        }

        private static double normalize(int value) {
            int clamped = Math.max(0, Math.min(MAX_MB, value));
            return clamped / (double) MAX_MB;
        }
    }

    private static final class AutoDelaySlider extends class_357 {
        private final IntConsumer setter;

        private AutoDelaySlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43469("screen.recordable.settings.auto_record.delay", getCurrentDelay()));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentDelay());
            method_25346();
        }

        private int getCurrentDelay() {
            return Math.max(0, Math.min(10, (int) Math.round(this.field_22753 * 10.0D)));
        }

        private static double normalize(int value) {
            int clamped = Math.max(0, Math.min(10, value));
            return clamped / 10.0D;
        }
    }

    /** Slider for replay buffer duration (10–300 seconds). */
    private static final class ReplayBufferSlider extends class_357 {
        private static final int MIN_SECONDS = 10;
        private static final int MAX_SECONDS = 300;
        private final IntConsumer setter;

        private ReplayBufferSlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            int seconds = getCurrentSeconds();
            String label = seconds >= 60
                    ? String.format("Replay Buffer: %dm %ds", seconds / 60, seconds % 60)
                    : "Replay Buffer: " + seconds + "s";
            this.method_25355(class_2561.method_43470(label));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentSeconds());
            method_25346();
        }

        private int getCurrentSeconds() {
            int raw = (int) Math.round(this.field_22753 * (MAX_SECONDS - MIN_SECONDS)) + MIN_SECONDS;
            int snapped = Math.round(raw / 5.0F) * 5;
            return Math.max(MIN_SECONDS, Math.min(MAX_SECONDS, snapped));
        }

        private static double normalize(int value) {
            int clamped = Math.max(MIN_SECONDS, Math.min(MAX_SECONDS, value));
            return (clamped - MIN_SECONDS) / (double) (MAX_SECONDS - MIN_SECONDS);
        }
    }

    /** Slider for custom audio delay (0–500ms). */
    private static final class AudioDelaySlider extends class_357 {
        private static final int MAX_MS = 500;
        private final IntConsumer setter;

        private AudioDelaySlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            int ms = getCurrentMs();
            this.method_25355(class_2561.method_43470("Custom Delay: " + ms + " ms"));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentMs());
            method_25346();
        }

        private int getCurrentMs() {
            int raw = (int) Math.round(this.field_22753 * MAX_MS);
            int snapped = Math.round(raw / 5.0F) * 5;
            return Math.max(0, Math.min(MAX_MS, snapped));
        }

        private static double normalize(int value) {
            int clamped = Math.max(0, Math.min(MAX_MS, value));
            return clamped / (double) MAX_MS;
        }
    }

    /** Slider for audio volume boost in dB (0-24 dB range, 1 dB steps). */
    private static final class AudioBoostSlider extends class_357 {
        private static final int MAX_BOOST_DB = 24;
        private final IntConsumer setter;

        private AudioBoostSlider(int x, int y, int width, int height, int currentDb, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentDb));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            int db = getCurrentDb();
            String label = db == 0 ? "Off" : "+" + db + " dB";
            this.method_25355(class_2561.method_43470("Audio Boost: " + label));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentDb());
            method_25346();
        }

        private int getCurrentDb() {
            return Math.max(0, Math.min(MAX_BOOST_DB, (int) Math.round(this.field_22753 * MAX_BOOST_DB)));
        }

        private static double normalize(int value) {
            return Math.max(0, Math.min(MAX_BOOST_DB, value)) / (double) MAX_BOOST_DB;
        }
    }

    private static final class AudioVolumeSlider extends class_357 {
        private static final int MAX_VOLUME = 200;
        private final IntConsumer setter;

        private AudioVolumeSlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            int vol = getCurrentVolume();
            String label = vol == 0 ? "Muted" : vol + "%";
            this.method_25355(class_2561.method_43470("Audio Volume: " + label));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentVolume());
            method_25346();
        }

        private int getCurrentVolume() {
            int raw = (int) Math.round(this.field_22753 * MAX_VOLUME);
            int snapped = Math.round(raw / 5.0F) * 5;
            return Math.max(0, Math.min(MAX_VOLUME, snapped));
        }

        private static double normalize(int value) {
            int clamped = Math.max(0, Math.min(MAX_VOLUME, value));
            return clamped / (double) MAX_VOLUME;
        }
    }

    /** Slider for overlay scale (50%-200%, snapped to 10% steps). */
    private static final class OverlayScaleSlider extends class_357 {
        private static final int MIN_SCALE = 50;
        private static final int MAX_SCALE = 200;
        private final IntConsumer setter;

        private OverlayScaleSlider(int x, int y, int width, int height, int currentValue, IntConsumer setter) {
            super(x, y, width, height, class_2561.method_43473(), normalize(currentValue));
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            int pct = getCurrentScale();
            String label;
            if (pct == 100) {
                label = "100% (Default)";
            } else if (pct < 100) {
                label = pct + "% (Smaller)";
            } else {
                label = pct + "% (Larger)";
            }
            this.method_25355(class_2561.method_43470("Overlay Scale: " + label));
        }

        @Override
        protected void method_25344() {
            this.setter.accept(getCurrentScale());
            method_25346();
        }

        private int getCurrentScale() {
            int raw = (int) Math.round(this.field_22753 * (MAX_SCALE - MIN_SCALE)) + MIN_SCALE;
            // Snap to nearest 10%
            int snapped = Math.round(raw / 10.0F) * 10;
            return Math.max(MIN_SCALE, Math.min(MAX_SCALE, snapped));
        }

        private static double normalize(int value) {
            int clamped = Math.max(MIN_SCALE, Math.min(MAX_SCALE, value));
            return (clamped - MIN_SCALE) / (double) (MAX_SCALE - MIN_SCALE);
        }
    }
}
