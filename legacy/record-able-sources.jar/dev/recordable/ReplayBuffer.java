package dev.recordable;

import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_310;

/**
 * Feature 7: Replay Buffer — Memory-Aware Implementation.
 *
 * <p>Maintains a circular buffer of the last N seconds of frames,
 * allowing the user to save recent gameplay retroactively.</p>
 *
 * <h3>Memory Safety (v2)</h3>
 * <ul>
 *   <li>Enforces a per-platform memory budget (200 MB mobile / 1500 MB desktop)</li>
 *   <li>Downscales frames by 50% on mobile devices to reduce per-frame cost</li>
 *   <li>Tracks live memory usage and drops oldest frames when budget is exceeded</li>
 *   <li>Caps maximum frame count to prevent runaway GC pressure</li>
 *   <li>Checks available JVM heap before starting — refuses if memory is too low</li>
 * </ul>
 */
public final class ReplayBuffer {

    private static final ReplayBuffer INSTANCE = new ReplayBuffer();
    private static final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    /** A timestamped frame in the circular buffer. */
    private record BufferedFrame(byte[] rgbPixels, int width, int height, long timestampMs) {
        long memoryBytes() { return rgbPixels.length; }
    }

    private final ConcurrentLinkedDeque<BufferedFrame> buffer = new ConcurrentLinkedDeque<>();
    private final AtomicBoolean active = new AtomicBoolean(false);
    private final AtomicBoolean saving = new AtomicBoolean(false);
    private final AtomicLong currentMemoryBytes = new AtomicLong(0);

    private volatile int targetFps = 60;
    private volatile int frameWidth;
    private volatile int frameHeight;
    private volatile int storedFrameWidth;   // actual stored resolution (may be downscaled)
    private volatile int storedFrameHeight;
    private volatile long bufferDurationMs;
    private volatile long memoryBudgetBytes;
    private volatile int maxFrameCount;
    private volatile int downscaleFactor = 1;

    private ReplayBuffer() {}

    public static ReplayBuffer getInstance() { return INSTANCE; }

    /**
     * Configures and starts the replay buffer with memory-aware limits.
     *
     * @param width          capture width in pixels
     * @param height         capture height in pixels
     * @param fps            target frames per second
     * @param durationSeconds buffer duration in seconds
     */
    public void start(int width, int height, int fps, int durationSeconds) {
        // Platform-aware memory budget
        long budgetMB = PlatformUtils.getReplayBufferMemoryBudgetMB();
        this.memoryBudgetBytes = budgetMB * 1024L * 1024L;

        // Downscale on mobile
        this.downscaleFactor = PlatformUtils.getReplayBufferDownscaleFactor();
        this.frameWidth = width;
        this.frameHeight = height;
        this.storedFrameWidth = width / downscaleFactor;
        this.storedFrameHeight = height / downscaleFactor;
        this.targetFps = fps;
        this.bufferDurationMs = durationSeconds * 1000L;

        // Calculate per-frame cost and max frame count
        long perFrameBytes = (long) storedFrameWidth * storedFrameHeight * 3;
        int totalFrames = fps * durationSeconds;
        long totalNeeded = perFrameBytes * totalFrames;

        // Cap frame count so it fits within memory budget
        if (perFrameBytes > 0) {
            int maxByBudget = (int) (memoryBudgetBytes / perFrameBytes);
            this.maxFrameCount = Math.min(totalFrames, maxByBudget);
        } else {
            this.maxFrameCount = totalFrames;
        }

        buffer.clear();
        currentMemoryBytes.set(0);
        active.set(true);

        RecordableMod.LOGGER.info("Replay buffer started: {}x{} (stored {}x{}, downscale={}x) @{} FPS, {}s, "
                + "budget={}MB, maxFrames={}, perFrame={}KB, totalNeeded={}MB",
                width, height, storedFrameWidth, storedFrameHeight, downscaleFactor,
                fps, durationSeconds, budgetMB, maxFrameCount,
                perFrameBytes / 1024, totalNeeded / (1024 * 1024));
    }

    /**
     * Stops the replay buffer and releases all buffered frames.
     */
    public void stop() {
        active.set(false);
        buffer.clear();
        currentMemoryBytes.set(0);
        RecordableMod.LOGGER.info("Replay buffer stopped. Memory released.");
    }

    /**
     * Adds a frame to the circular buffer with memory-aware trimming.
     *
     * <p>On mobile, frames are downscaled by {@link #downscaleFactor} before storage.
     * The buffer enforces both time-based and memory-based eviction.</p>
     *
     * @param rgbPixels raw RGB pixel data (full resolution from capture)
     */
    public void addFrame(byte[] rgbPixels) {
        if (!active.get() || rgbPixels == null) return;

        long now = System.currentTimeMillis();

        // Downscale if needed (mobile devices)
        byte[] storedPixels;
        if (downscaleFactor > 1) {
            storedPixels = downscaleRgb(rgbPixels, frameWidth, frameHeight, downscaleFactor);
        } else {
            storedPixels = rgbPixels.clone();
        }

        long frameSize = storedPixels.length;
        buffer.addLast(new BufferedFrame(storedPixels, storedFrameWidth, storedFrameHeight, now));
        currentMemoryBytes.addAndGet(frameSize);

        // Trim by time
        long cutoff = now - bufferDurationMs;
        while (!buffer.isEmpty()) {
            BufferedFrame oldest = buffer.peekFirst();
            if (oldest != null && oldest.timestampMs < cutoff) {
                BufferedFrame removed = buffer.pollFirst();
                if (removed != null) currentMemoryBytes.addAndGet(-removed.memoryBytes());
            } else {
                break;
            }
        }

        // Trim by memory budget
        while (currentMemoryBytes.get() > memoryBudgetBytes && !buffer.isEmpty()) {
            BufferedFrame removed = buffer.pollFirst();
            if (removed != null) currentMemoryBytes.addAndGet(-removed.memoryBytes());
        }

        // Trim by max frame count
        while (buffer.size() > maxFrameCount && !buffer.isEmpty()) {
            BufferedFrame removed = buffer.pollFirst();
            if (removed != null) currentMemoryBytes.addAndGet(-removed.memoryBytes());
        }
    }

    /**
     * Downscales RGB24 pixel data by a given factor using simple area averaging.
     */
    private static byte[] downscaleRgb(byte[] src, int srcWidth, int srcHeight, int factor) {
        int dstWidth = srcWidth / factor;
        int dstHeight = srcHeight / factor;
        byte[] dst = new byte[dstWidth * dstHeight * 3];

        for (int dy = 0; dy < dstHeight; dy++) {
            for (int dx = 0; dx < dstWidth; dx++) {
                int r = 0, g = 0, b = 0;
                int count = 0;
                for (int fy = 0; fy < factor; fy++) {
                    for (int fx = 0; fx < factor; fx++) {
                        int sx = dx * factor + fx;
                        int sy = dy * factor + fy;
                        int srcIdx = (sy * srcWidth + sx) * 3;
                        if (srcIdx + 2 < src.length) {
                            r += src[srcIdx] & 0xFF;
                            g += src[srcIdx + 1] & 0xFF;
                            b += src[srcIdx + 2] & 0xFF;
                            count++;
                        }
                    }
                }
                if (count > 0) {
                    int dstIdx = (dy * dstWidth + dx) * 3;
                    dst[dstIdx] = (byte) (r / count);
                    dst[dstIdx + 1] = (byte) (g / count);
                    dst[dstIdx + 2] = (byte) (b / count);
                }
            }
        }
        return dst;
    }

    /**
     * Saves the current buffer contents to a video file using FFmpeg.
     *
     * @param client the Minecraft client for messaging
     */
    public void saveBuffer(class_310 client) {
        if (!active.get()) {
            RecordableMod.sendClientMessage(client, "§cReplay buffer is not active.", true);
            return;
        }

        if (saving.getAndSet(true)) {
            RecordableMod.sendClientMessage(client, "§eReplay buffer is already being saved...", true);
            return;
        }

        if (buffer.isEmpty()) {
            saving.set(false);
            RecordableMod.sendClientMessage(client, "§eReplay buffer is empty. Play for a few seconds first.", true);
            return;
        }

        // Snapshot the buffer
        BufferedFrame[] frames = buffer.toArray(new BufferedFrame[0]);
        if (frames.length < 2) {
            saving.set(false);
            RecordableMod.sendClientMessage(client, "§eNot enough frames in replay buffer.", true);
            return;
        }

        RecordableMod.sendClientMessage(client, "§eSaving replay buffer (" + frames.length + " frames, "
                + (currentMemoryBytes.get() / (1024 * 1024)) + " MB)...", true);

        Thread saveThread = new Thread(() -> {
            try {
                saveFramesToFile(client, frames);
            } catch (Throwable t) {
                RecordableMod.LOGGER.warn("Failed to save replay buffer.", t);
                RecordableMod.sendClientMessage(client, "§cFailed to save replay buffer: " + t.getMessage(), false);
            } finally {
                saving.set(false);
            }
        }, "Record-able Replay Save");
        saveThread.setDaemon(true);
        saveThread.start();
    }

    private void saveFramesToFile(class_310 client, BufferedFrame[] frames) throws Exception {
        RecordableConfig config = RecordableConfig.get();
        Path outputDir = config.getOutputDirectory();
        Files.createDirectories(outputDir);

        String timestamp = LocalDateTime.now().format(FILE_TIMESTAMP);
        String ext = config.getFormat();
        Path outputFile = outputDir.resolve("replay-" + timestamp + "." + ext);

        FFmpegEncoder.FfmpegStatus ffStatus = FFmpegEncoder.detectFfmpeg();
        if (!ffStatus.found()) {
            RecordableMod.sendClientMessage(client, "§cFFmpeg not found. Cannot save replay.", false);
            return;
        }

        // Use the stored frame dimensions (may be downscaled)
        int outWidth = frames[0].width;
        int outHeight = frames[0].height;

        // Calculate effective FPS from frame timestamps
        long durationMs = frames[frames.length - 1].timestampMs - frames[0].timestampMs;
        double effectiveFps = durationMs > 0 ? (frames.length * 1000.0 / durationMs) : targetFps;
        int fps = Math.max(1, Math.min(120, (int) Math.round(effectiveFps)));

        // Build FFmpeg command for raw video input
        ProcessBuilder pb = new ProcessBuilder(
                ffStatus.executable(),
                "-y",
                "-f", "rawvideo",
                "-pixel_format", "rgb24",
                "-video_size", outWidth + "x" + outHeight,
                "-framerate", String.valueOf(fps),
                "-i", "pipe:0",
                "-c:v", "libx264",
                "-preset", "fast",
                "-crf", "23",
                "-pix_fmt", "yuv420p",
                outputFile.toString()
        );
        pb.redirectErrorStream(true);

        Process process = pb.start();
        try (OutputStream stdin = process.getOutputStream()) {
            for (BufferedFrame frame : frames) {
                stdin.write(frame.rgbPixels);
            }
            stdin.flush();
        }

        int exitCode = process.waitFor();
        if (exitCode == 0 && Files.exists(outputFile)) {
            long fileSize = Files.size(outputFile);
            String msg = "§a✓ Replay saved: " + outputFile.getFileName()
                    + " (" + RecordingManager.formatBytes(fileSize)
                    + ", " + String.format("%.1fs", durationMs / 1000.0) + ")";
            RecordableMod.sendClientMessage(client, msg, false);
            RecordableMod.LOGGER.info("Replay buffer saved: {} ({} frames, {} at {}x{})",
                    outputFile, frames.length, RecordingManager.formatBytes(fileSize), outWidth, outHeight);
        } else {
            RecordableMod.sendClientMessage(client, "§cReplay save failed (exit code " + exitCode + ").", false);
        }
    }

    public boolean isActive() { return active.get(); }
    public boolean isSaving() { return saving.get(); }
    public int getBufferedFrameCount() { return buffer.size(); }
    public long getCurrentMemoryMB() { return currentMemoryBytes.get() / (1024L * 1024L); }
    public long getMemoryBudgetMB() { return memoryBudgetBytes / (1024L * 1024L); }
    public int getMaxFrameCount() { return maxFrameCount; }
    public int getDownscaleFactor() { return downscaleFactor; }

    public int getBufferedSeconds() {
        if (buffer.isEmpty()) return 0;
        BufferedFrame first = buffer.peekFirst();
        BufferedFrame last = buffer.peekLast();
        if (first == null || last == null) return 0;
        return (int) ((last.timestampMs - first.timestampMs) / 1000L);
    }

    /**
     * Checks if there is sufficient free memory to start the replay buffer.
     *
     * @param width  capture width
     * @param height capture height
     * @param fps    target FPS
     * @param durationSeconds buffer duration
     * @return {@code null} if safe to start, or a warning message if memory is too low
     */
    public static String checkMemorySafety(int width, int height, int fps, int durationSeconds) {
        int downscale = PlatformUtils.getReplayBufferDownscaleFactor();
        int sw = width / downscale;
        int sh = height / downscale;
        long perFrame = (long) sw * sh * 3;
        long totalFrames = (long) fps * durationSeconds;
        long totalNeeded = perFrame * totalFrames;
        long budgetBytes = PlatformUtils.getReplayBufferMemoryBudgetMB() * 1024L * 1024L;

        // Check if even the budget itself is viable given current heap
        Runtime rt = Runtime.getRuntime();
        long freeHeap = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory());
        long minSafeHeadroom = 256L * 1024L * 1024L; // 256 MB headroom for Minecraft

        if (freeHeap < budgetBytes + minSafeHeadroom) {
            long freeMB = freeHeap / (1024L * 1024L);
            long budgetMB = budgetBytes / (1024L * 1024L);
            return String.format("§cLow memory! Only %d MB free, need %d MB for buffer + %d MB headroom.",
                    freeMB, budgetMB, minSafeHeadroom / (1024 * 1024));
        }

        return null; // safe
    }

    /**
     * Returns a human-readable estimate of replay buffer memory usage for the settings screen.
     */
    public static String getMemoryEstimate(int width, int height, int fps, int durationSeconds) {
        int downscale = PlatformUtils.getReplayBufferDownscaleFactor();
        int sw = width / downscale;
        int sh = height / downscale;
        long perFrame = (long) sw * sh * 3;
        long totalFrames = (long) fps * durationSeconds;
        long totalMB = (perFrame * totalFrames) / (1024L * 1024L);
        long budgetMB = PlatformUtils.getReplayBufferMemoryBudgetMB();
        long effectiveMB = Math.min(totalMB, budgetMB);

        String suffix = downscale > 1 ? " (mobile: " + sw + "x" + sh + ")" : "";
        return String.format("~%d MB / %d MB budget%s", effectiveMB, budgetMB, suffix);
    }
}