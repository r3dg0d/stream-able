package dev.recordable;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL21;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import net.minecraft.class_310;

/**
 * Reads the final OpenGL backbuffer into raw RGB frames for FFmpeg.
 *
 * <p>Two pixel-buffer objects are used in a ping-pong pattern. Each render tick
 * submits the current {@code glReadPixels} asynchronously and maps the previous
 * PBO, keeping GPU/CPU synchronization pressure low. The first call after start
 * or resize returns {@code null} because the readback is intentionally one frame
 * behind.</p>
 */
public final class ScreenCapture implements AutoCloseable {
    private static final int BYTES_PER_PIXEL = 3;

    private final int outputWidth;
    private final int outputHeight;
    private final int outputByteSize;
    private final int[] pboIds = new int[2];

    private int sourceWidth;
    private int sourceHeight;
    private int sourceByteSize;
    private int pboWriteIndex;
    private boolean hasPendingPboFrame;
    private boolean pboSupported = true;
    private ByteBuffer fallbackReadBuffer;

    public ScreenCapture(int outputWidth, int outputHeight) {
        this.outputWidth = Math.max(2, outputWidth);
        this.outputHeight = Math.max(2, outputHeight);
        this.outputByteSize = this.outputWidth * this.outputHeight * BYTES_PER_PIXEL;
    }

    /**
     * Captures a frame from the default framebuffer/backbuffer.
     *
     * @return RGB top-down pixels at the configured output size, or {@code null}
     * when an async PBO readback is still warming up, or when the GL context
     * is not in a valid state (e.g., at the main menu before world load).
     */
    public synchronized CapturedFrame captureFrame() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null) {
            return null;
        }

        int nativeWidth = client.method_22683().method_4489();
        int nativeHeight = client.method_22683().method_4506();
        if (nativeWidth <= 0 || nativeHeight <= 0) {
            return null;
        }

        try {
            GL11.glGetError(); // clears any stale error
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.debug("GL context not ready for screen capture; skipping frame.", throwable);
            return null;
        }

        try {
            if (!pboSupported) {
                return captureSynchronously(nativeWidth, nativeHeight);
            }

            CapturedFrame readyFrame = hasPendingPboFrame ? mapPendingPboFrame() : null;

            if (pboIds[0] == 0 || nativeWidth != sourceWidth || nativeHeight != sourceHeight) {
                initializePbos(nativeWidth, nativeHeight);
            }

            submitAsyncRead();
            return readyFrame;
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("PBO screen capture failed; falling back to synchronous readback.", throwable);
            pboSupported = false;
            deletePbosSafely();
            try {
                return captureSynchronously(nativeWidth, nativeHeight);
            } catch (Throwable syncThrowable) {
                RecordableMod.LOGGER.warn("Synchronous screen capture also failed; returning null.", syncThrowable);
                return null;
            }
        }
    }

    public int getOutputWidth() {
        return outputWidth;
    }

    public int getOutputHeight() {
        return outputHeight;
    }

    private CapturedFrame captureSynchronously(int nativeWidth, int nativeHeight) {
        try {
            sourceWidth = nativeWidth;
            sourceHeight = nativeHeight;
            sourceByteSize = checkedByteSize(sourceWidth, sourceHeight);
            ensureFallbackReadBuffer();

            int previousReadFramebuffer = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
            int previousPackAlignment = GL11.glGetInteger(GL11.GL_PACK_ALIGNMENT);
            try {
                GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
                GL11.glReadBuffer(GL11.GL_BACK);
                GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
                fallbackReadBuffer.clear();
                GL11.glReadPixels(0, 0, sourceWidth, sourceHeight, GL12.GL_BGR, GL11.GL_UNSIGNED_BYTE, fallbackReadBuffer);
            } finally {
                GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, previousPackAlignment);
                GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, previousReadFramebuffer);
            }

            byte[] rgb = new byte[outputByteSize];
            copyFlipScaleBgrToRgb(fallbackReadBuffer, sourceWidth, sourceHeight, rgb, outputWidth, outputHeight);
            return new CapturedFrame(rgb, outputWidth, outputHeight, System.nanoTime());
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Synchronous screen capture failed.", throwable);
            return null;
        }
    }

    private void initializePbos(int newSourceWidth, int newSourceHeight) {
        deletePbosSafely();
        sourceWidth = newSourceWidth;
        sourceHeight = newSourceHeight;
        sourceByteSize = checkedByteSize(sourceWidth, sourceHeight);
        pboWriteIndex = 0;
        hasPendingPboFrame = false;

        int previousPbo = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        try {
            for (int index = 0; index < pboIds.length; index++) {
                pboIds[index] = GL15.glGenBuffers();
                GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pboIds[index]);
                GL15.glBufferData(GL21.GL_PIXEL_PACK_BUFFER, sourceByteSize, GL15.GL_STREAM_READ);
            }
        } finally {
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, previousPbo);
        }
    }

    private void submitAsyncRead() {
        int previousReadFramebuffer = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int previousPbo = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        int previousPackAlignment = GL11.glGetInteger(GL11.GL_PACK_ALIGNMENT);

        try {
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
            GL11.glReadBuffer(GL11.GL_BACK);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);

            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pboIds[pboWriteIndex]);
            GL15.glBufferData(GL21.GL_PIXEL_PACK_BUFFER, sourceByteSize, GL15.GL_STREAM_READ);
            GL11.glReadPixels(0, 0, sourceWidth, sourceHeight, GL12.GL_BGR, GL11.GL_UNSIGNED_BYTE, 0L);

            pboWriteIndex = (pboWriteIndex + 1) % pboIds.length;
            hasPendingPboFrame = true;
        } finally {
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, previousPackAlignment);
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, previousPbo);
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, previousReadFramebuffer);
        }
    }

    private CapturedFrame mapPendingPboFrame() {
        int readIndex = (pboWriteIndex + 1) % pboIds.length;
        int previousPbo = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        ByteBuffer mapped = null;
        try {
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pboIds[readIndex]);
            mapped = GL15.glMapBuffer(GL21.GL_PIXEL_PACK_BUFFER, GL15.GL_READ_ONLY, sourceByteSize, null);
            if (mapped == null) {
                return null;
            }

            byte[] rgb = new byte[outputByteSize];
            copyFlipScaleBgrToRgb(mapped, sourceWidth, sourceHeight, rgb, outputWidth, outputHeight);
            return new CapturedFrame(rgb, outputWidth, outputHeight, System.nanoTime());
        } finally {
            if (mapped != null) {
                GL15.glUnmapBuffer(GL21.GL_PIXEL_PACK_BUFFER);
            }
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, previousPbo);
        }
    }

    private void ensureFallbackReadBuffer() {
        if (fallbackReadBuffer != null && fallbackReadBuffer.capacity() >= sourceByteSize) {
            return;
        }
        if (fallbackReadBuffer != null) {
            MemoryUtil.memFree(fallbackReadBuffer);
        }
        fallbackReadBuffer = MemoryUtil.memAlloc(sourceByteSize);
    }

    private static int checkedByteSize(int width, int height) {
        long bytes = width * (long) height * BYTES_PER_PIXEL;
        if (bytes > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("Capture buffer is too large: " + width + "x" + height);
        }
        return (int) bytes;
    }

    private static void copyFlipScaleBgrToRgb(ByteBuffer sourceBgrBottomUp, int sourceWidth, int sourceHeight,
                                              byte[] targetRgbTopDown, int targetWidth, int targetHeight) {
        for (int targetY = 0; targetY < targetHeight; targetY++) {
            int sourceYTopDown = (int) ((targetY / (double) targetHeight) * sourceHeight);
            int sourceYBottomUp = sourceHeight - 1 - Math.min(sourceHeight - 1, sourceYTopDown);

            for (int targetX = 0; targetX < targetWidth; targetX++) {
                int sourceX = (int) ((targetX / (double) targetWidth) * sourceWidth);
                sourceX = Math.min(sourceWidth - 1, sourceX);

                int sourceIndex = (sourceYBottomUp * sourceWidth + sourceX) * BYTES_PER_PIXEL;
                int targetIndex = (targetY * targetWidth + targetX) * BYTES_PER_PIXEL;

                byte blue = sourceBgrBottomUp.get(sourceIndex);
                byte green = sourceBgrBottomUp.get(sourceIndex + 1);
                byte red = sourceBgrBottomUp.get(sourceIndex + 2);

                targetRgbTopDown[targetIndex] = red;
                targetRgbTopDown[targetIndex + 1] = green;
                targetRgbTopDown[targetIndex + 2] = blue;
            }
        }
    }

    private void deletePbosSafely() {
        try {
            for (int index = 0; index < pboIds.length; index++) {
                if (pboIds[index] != 0) {
                    GL15.glDeleteBuffers(pboIds[index]);
                    pboIds[index] = 0;
                }
            }
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.debug("Failed to delete screen-capture PBOs.", throwable);
        }
        hasPendingPboFrame = false;
    }

    @Override
    public synchronized void close() {
        deletePbosSafely();
        if (fallbackReadBuffer != null) {
            MemoryUtil.memFree(fallbackReadBuffer);
            fallbackReadBuffer = null;
        }
    }

    public record CapturedFrame(byte[] rgbPixels, int width, int height, long capturedAtNanos) {
    }
}
