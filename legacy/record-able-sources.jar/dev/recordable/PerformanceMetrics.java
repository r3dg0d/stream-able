package dev.recordable;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Feature 4: Performance Overlay metrics using Micrometer.
 * Tracks frame capture rate, encoding latency, buffer health, and dropped frames.
 * Provides real-time stats for the recording overlay.
 */
public final class PerformanceMetrics {

    private static final PerformanceMetrics INSTANCE = new PerformanceMetrics();

    private final MeterRegistry registry;
    private final Counter framesCaptured;
    private final Counter framesDropped;
    private final Counter framesEncoded;
    private final Counter adaptiveDrops;
    private final Timer captureLatency;
    private final Timer encodeLatency;
    private final AtomicLong queueSize = new AtomicLong(0);
    private final AtomicLong queueCapacity = new AtomicLong(240);
    private final AtomicLong currentFps = new AtomicLong(0);
    private final AtomicLong encoderFps = new AtomicLong(0);
    private final AtomicLong memoryUsedMiB = new AtomicLong(0);
    private final AtomicLong fileSizeBytes = new AtomicLong(0);

    // Rolling averages for overlay display
    private volatile double avgCaptureLatencyMs = 0.0;
    private volatile double avgEncodeLatencyMs = 0.0;
    private volatile double bufferHealthPercent = 100.0;

    private PerformanceMetrics() {
        this.registry = new SimpleMeterRegistry();

        this.framesCaptured = Counter.builder("recordable.frames.captured")
                .description("Total frames captured from GPU")
                .register(registry);

        this.framesDropped = Counter.builder("recordable.frames.dropped")
                .description("Total frames dropped (all reasons)")
                .register(registry);

        this.framesEncoded = Counter.builder("recordable.frames.encoded")
                .description("Total frames written to encoder")
                .register(registry);

        this.adaptiveDrops = Counter.builder("recordable.frames.adaptive_drops")
                .description("Frames dropped by adaptive frame dropping")
                .register(registry);

        this.captureLatency = Timer.builder("recordable.capture.latency")
                .description("Frame capture latency")
                .publishPercentileHistogram()
                .register(registry);

        this.encodeLatency = Timer.builder("recordable.encode.latency")
                .description("Frame encoding latency")
                .publishPercentileHistogram()
                .register(registry);

        Gauge.builder("recordable.queue.size", queueSize, AtomicLong::doubleValue)
                .description("Current encoder queue size")
                .register(registry);

        Gauge.builder("recordable.queue.capacity", queueCapacity, AtomicLong::doubleValue)
                .description("Encoder queue capacity")
                .register(registry);
    }

    public static PerformanceMetrics getInstance() {
        return INSTANCE;
    }

    public void recordFrameCapture(long durationNanos) {
        framesCaptured.increment();
        captureLatency.record(Duration.ofNanos(durationNanos));
        avgCaptureLatencyMs = captureLatency.mean(TimeUnit.MILLISECONDS);
    }

    public void recordFrameEncode(long durationNanos) {
        framesEncoded.increment();
        encodeLatency.record(Duration.ofNanos(durationNanos));
        avgEncodeLatencyMs = encodeLatency.mean(TimeUnit.MILLISECONDS);
    }

    public void recordFrameDrop() {
        framesDropped.increment();
    }

    public void recordAdaptiveDrop() {
        adaptiveDrops.increment();
    }

    public void updateQueueStats(int size, int capacity) {
        queueSize.set(size);
        queueCapacity.set(capacity);
        bufferHealthPercent = capacity > 0
                ? Math.max(0.0, 100.0 - (size * 100.0 / capacity))
                : 100.0;
    }

    public void updateFps(long captureFps, long encodeFps) {
        currentFps.set(captureFps);
        encoderFps.set(encodeFps);
    }

    public void updateMemory(long usedMiB) {
        memoryUsedMiB.set(usedMiB);
    }

    public void updateFileSize(long bytes) {
        fileSizeBytes.set(bytes);
    }

    /** Resets all counters for a new recording session. */
    public void reset() {
        // Micrometer counters can't be reset, but they're cumulative.
        // We track deltas via the overlay by caching last values.
        avgCaptureLatencyMs = 0.0;
        avgEncodeLatencyMs = 0.0;
        bufferHealthPercent = 100.0;
        queueSize.set(0);
        fileSizeBytes.set(0);
    }

    // === Getters for overlay display ===

    public double getAvgCaptureLatencyMs() { return avgCaptureLatencyMs; }
    public double getAvgEncodeLatencyMs() { return avgEncodeLatencyMs; }
    public double getBufferHealthPercent() { return bufferHealthPercent; }
    public long getTotalCaptured() { return (long) framesCaptured.count(); }
    public long getTotalDropped() { return (long) framesDropped.count(); }
    public long getTotalEncoded() { return (long) framesEncoded.count(); }
    public long getCaptureFps() { return currentFps.get(); }
    public long getEncoderFps() { return encoderFps.get(); }
    public long getMemoryUsedMiB() { return memoryUsedMiB.get(); }
    public long getQueueSize() { return queueSize.get(); }
    public long getQueueCapacity() { return queueCapacity.get(); }

    public MeterRegistry getRegistry() { return registry; }

    /**
     * Returns a compact performance summary string for the overlay.
     */
    public String getCompactSummary() {
        return String.format("Cap %.1fms | Enc %.1fms | Buf %.0f%%",
                avgCaptureLatencyMs, avgEncodeLatencyMs, bufferHealthPercent);
    }
}
