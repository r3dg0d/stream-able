package dev.recordable;

import dev.recordable.screen.RecordableSettingsScreen;
import dev.recordable.screen.VideoCollectionScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Client entry point for the Record-able full-screen recorder. */
public final class RecordableMod implements ClientModInitializer {
    public static final String MOD_ID = "recordable";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"));

    private static class_304 toggleRecordingKey;
    private static class_304 pauseResumeKey;
    private static class_304 openSettingsKey;
    private static class_304 openVideoCollectionKey;
    private static class_304 saveReplayBufferKey;
    private static AutoRecordManager autoRecordManager;

    @Override
    public void onInitializeClient() {
        RecordableConfig config = RecordableConfig.load();
        if (config.migrateOldConfig()) {
            config.save();
        }

        try {
            FfmpegBundleManager.runDiagnostics();
        } catch (Exception e) {
            LOGGER.warn("[RecordableMod] FFmpeg diagnostics failed: {}", e.getMessage());
        }

        RecordingManager.getInstance().initialize();

        autoRecordManager = new AutoRecordManager();
        autoRecordManager.initialize();

        // Feature 2: Configurable Hotkeys - register with config-specified defaults
        toggleRecordingKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.recordable.toggle_recording",
                class_3675.class_307.field_1668,
                config.hotkeyToggleRecording,
                KEY_CATEGORY
        ));
        pauseResumeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.recordable.pause_resume",
                class_3675.class_307.field_1668,
                config.hotkeyPauseResume,
                KEY_CATEGORY
        ));
        openSettingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.recordable.open_settings",
                class_3675.class_307.field_1668,
                config.hotkeyOpenSettings,
                KEY_CATEGORY
        ));
        openVideoCollectionKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.recordable.open_video_collection",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F11,
                KEY_CATEGORY
        ));
        saveReplayBufferKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.recordable.save_replay_buffer",
                class_3675.class_307.field_1668,
                config.hotkeySaveReplayBuffer,
                KEY_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle recording (with disk space check)
            while (toggleRecordingKey.method_1436()) {
                if (!RecordingManager.isInGameState(client)) {
                    continue;
                }
                if (!RecordingManager.getInstance().isRecording()) {
                    ModCompatibilityChecker.warnPlayerIfConflicts(client);

                    // Feature 5: Disk Space Guardian - check before starting
                    DiskSpaceGuardian.DiskCheckResult diskCheck = DiskSpaceGuardian.check(
                            RecordableConfig.get().getOutputDirectory(), RecordableConfig.get());
                    if (diskCheck.status() == DiskSpaceGuardian.DiskStatus.BLOCKED) {
                        sendClientMessage(client, diskCheck.message(), false);
                        continue;
                    }
                    if (diskCheck.status() == DiskSpaceGuardian.DiskStatus.WARNING) {
                        sendClientMessage(client, diskCheck.message(), false);
                    }
                }
                RecordingManager.getInstance().toggleRecording(client);
            }

            // Feature 1: Pause/Resume hotkey
            while (pauseResumeKey.method_1436()) {
                if (RecordingManager.getInstance().isRecording() || RecordingManager.getInstance().isPaused()) {
                    RecordingManager.getInstance().togglePause(client);
                }
            }

            while (openSettingsKey.method_1436()) {
                if (client != null && !(client.field_1755 instanceof RecordableSettingsScreen)) {
                    client.method_1507(new RecordableSettingsScreen(client.field_1755));
                }
            }

            while (openVideoCollectionKey.method_1436()) {
                if (client != null && !(client.field_1755 instanceof VideoCollectionScreen)) {
                    client.method_1507(new VideoCollectionScreen(client.field_1755));
                }
            }

            // Feature 7: Save Replay Buffer hotkey
            while (saveReplayBufferKey.method_1436()) {
                if (ReplayBuffer.getInstance().isActive()) {
                    ReplayBuffer.getInstance().saveBuffer(client);
                } else {
                    sendClientMessage(client, "§eReplay buffer is not enabled. Enable it in Settings.", true);
                }
            }

            if (autoRecordManager != null) {
                autoRecordManager.onClientTick(client);
            }
            RecordingManager.getInstance().onClientTick(client);

            // Feed frames to replay buffer when not recording
            // (when recording, RecordingManager.onFrame() handles it)
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            if (autoRecordManager != null) {
                autoRecordManager.onClientStopping(client);
            }
            ReplayBuffer.getInstance().stop();
            RecordingManager.getInstance().shutdown();
        });

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                RecordingManager recordingManager = RecordingManager.getInstance();
                if (recordingManager.isActiveOrStopping()) {
                    LOGGER.info("JVM shutdown detected while recording. Finalizing recording before exit.");
                    recordingManager.forceShutdown();
                }
            } catch (Throwable throwable) {
                LOGGER.warn("Failed to finalize recording during JVM shutdown.", throwable);
            }
        }, "Record-able Shutdown Hook"));

        RecordingOverlay.register();

        // Initialize Micrometer metrics
        PerformanceMetrics.getInstance();

        LOGGER.info("Record-able audio sync offset: {}ms (preset: {})", RecordableConfig.get().getEffectiveAudioDelay(), RecordableConfig.get().audioDelayPreset);

        ModCompatibilityChecker.checkAndLog();

        // Log disk space status
        try {
            String freeSpace = DiskSpaceGuardian.getFormattedFreeSpace(config.getOutputDirectory());
            LOGGER.info("Record-able initialized. Recording enabled: {}. Free disk space: {}",
                    config.enabled, freeSpace);
        } catch (Exception e) {
            LOGGER.info("Record-able initialized. Recording enabled: {}", config.enabled);
        }
    }

    public static void sendClientMessage(class_310 client, String message, boolean actionBar) {
        if (message == null || message.isBlank()) {
            return;
        }
        try {
            class_310 targetClient = client == null ? class_310.method_1551() : client;
            if (targetClient != null && !targetClient.method_18854()) {
                targetClient.execute(() -> sendClientMessage(targetClient, message, actionBar));
                return;
            }
            if (targetClient != null && targetClient.field_1724 != null) {
                targetClient.field_1724.method_7353(class_2561.method_43470(message), actionBar);
            }
        } catch (Throwable throwable) {
            LOGGER.warn("Failed to display Record-able client message: {}", message, throwable);
        }
    }
}
