package dev.recordable;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_310;

/** Handles automatic recording start/stop triggers and delayed countdown. */
public final class AutoRecordManager {
    private static final int TICKS_PER_SECOND = 20;

    private final Object lock = new Object();
    private int countdownTicksRemaining = -1;
    private int nextAnnouncementSecond = -1;
    private boolean gameStartHandled;

    /** Deferred notification to display after the player is fully in-game. */
    private volatile String deferredJoinNotification;
    private volatile int deferredJoinTickDelay = -1;

    public void initialize() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            try {
                RecordableConfig config = RecordableConfig.get();
                String pendingSaveNotice = RecordingManager.getInstance().consumePendingJoinNotification();
                if (pendingSaveNotice != null && !pendingSaveNotice.isBlank()) {
                    deferredJoinNotification = pendingSaveNotice;
                    deferredJoinTickDelay = 40; // ~2 seconds after join for player to be fully loaded
                }
                if (config != null && !config.stopOnDisconnect && RecordingManager.getInstance().isPaused()) {
                    RecordingManager.getInstance().resumeRecording(client);
                }
                if (config != null && "world_join".equals(config.autoRecordTrigger)) {
                    scheduleAutoRecording(client, "world join");
                }
            } catch (Throwable throwable) {
                RecordableMod.LOGGER.warn("Failed to process auto-record world join event.", throwable);
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            try {
                cancelScheduledAutoRecord();
                deferredJoinNotification = null;
                deferredJoinTickDelay = -1;

                handleDisconnectBehavior(client);

                RecordableConfig config = RecordableConfig.get();
                if (config != null && "world_leave".equals(config.autoStopTrigger) && !config.stopOnDisconnect) {
                    stopIfRecording(client, "world leave");
                }
            } catch (Throwable throwable) {
                RecordableMod.LOGGER.warn("Failed to process auto-record disconnect event.", throwable);
            }
        });
    }

    public void onClientTick(class_310 client) {
        if (client == null) {
            return;
        }

        if (deferredJoinTickDelay >= 0) {
            deferredJoinTickDelay--;
            if (deferredJoinTickDelay < 0) {
                String notification = deferredJoinNotification;
                deferredJoinNotification = null;
                if (notification != null && !notification.isBlank()) {
                    RecordableMod.sendClientMessage(client, notification, false);
                }
            }
        }

        handleGameStartTrigger(client);

        int countdownSnapshot;
        synchronized (lock) {
            countdownSnapshot = countdownTicksRemaining;
        }

        if (countdownSnapshot < 0) {
            return;
        }

        int nextValue;
        synchronized (lock) {
            if (countdownTicksRemaining < 0) {
                return;
            }

            countdownTicksRemaining--;
            nextValue = countdownTicksRemaining;

            if (nextValue >= 0) {
                int secondsRemaining = (int) Math.ceil(nextValue / (double) TICKS_PER_SECOND);
                if (secondsRemaining > 0 && secondsRemaining != nextAnnouncementSecond) {
                    nextAnnouncementSecond = secondsRemaining;
                    RecordableMod.sendClientMessage(client, "Auto-recording starts in " + secondsRemaining + "...", true);
                }
            }

            if (nextValue >= 0) {
                return;
            }

            countdownTicksRemaining = -1;
            nextAnnouncementSecond = -1;
        }

        if (!client.method_18854()) {
            executeOnClientThread(client, () -> triggerStartNow(client), "auto-record countdown completion");
        } else {
            triggerStartNow(client);
        }
    }

    public void onClientStopping(class_310 client) {
        cancelScheduledAutoRecord();
        try {
            RecordableConfig config = RecordableConfig.get();
            if (config != null && "game_quit".equals(config.autoStopTrigger)) {
                stopIfRecording(client, "game quit");
            }
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to process auto-record game quit stop trigger.", throwable);
        }
    }

    public void scheduleAutoRecording(class_310 client, String reason) {
        RecordableConfig config = RecordableConfig.get();
        if (config == null || !config.enabled || !config.autoRecord || "manual".equals(config.autoRecordTrigger)) {
            return;
        }
        if (RecordingManager.getInstance().isActiveOrStopping()) {
            return;
        }

        int delaySeconds = Math.max(0, config.autoRecordDelay);
        if (delaySeconds <= 0) {
            triggerStartNow(client);
            return;
        }

        synchronized (lock) {
            countdownTicksRemaining = delaySeconds * TICKS_PER_SECOND;
            nextAnnouncementSecond = delaySeconds;
        }

        RecordableMod.sendClientMessage(client, "Auto-recording starts in " + delaySeconds + "...", false);
        RecordableMod.LOGGER.info("Scheduled auto-record start in {} seconds ({})", delaySeconds, reason);
    }

    public void cancelScheduledAutoRecord() {
        synchronized (lock) {
            countdownTicksRemaining = -1;
            nextAnnouncementSecond = -1;
        }
    }

    private void handleGameStartTrigger(class_310 client) {
        if (gameStartHandled) {
            return;
        }

        RecordableConfig config;
        try {
            config = RecordableConfig.get();
        } catch (Throwable throwable) {
            return;
        }

        if (config == null || !config.autoRecord || !"game_start".equals(config.autoRecordTrigger)) {
            return;
        }

        gameStartHandled = true;
        scheduleAutoRecording(client, "game start");
    }

    private void handleDisconnectBehavior(class_310 client) {
        RecordableConfig config = RecordableConfig.get();
        if (config == null) {
            return;
        }

        RecordingManager recordingManager = RecordingManager.getInstance();
        if (recordingManager.isStopping()) {
            return;
        }

        if (recordingManager.isRecording()) {
            if (config.stopOnDisconnect) {
                RecordableMod.LOGGER.info("Auto-stopping recording due to disconnect");
                recordingManager.stopRecordingForDisconnect(client);
            } else {
                recordingManager.pauseRecording(client);
                RecordableMod.LOGGER.info("Auto-pausing recording due to disconnect (stopOnDisconnect=false)");
            }
        }
    }

    private void triggerStartNow(class_310 client) {
        class_310 activeClient = resolveClient(client);
        if (activeClient != null && !activeClient.method_18854()) {
            executeOnClientThread(activeClient, () -> triggerStartNow(activeClient), "auto-record start");
            return;
        }

        RecordableConfig config = RecordableConfig.get();
        if (config == null || !config.enabled || !config.autoRecord) {
            return;
        }

        if (!RecordingManager.getInstance().isActiveOrStopping()) {
            RecordingManager.getInstance().startRecording(activeClient);
            if (RecordingManager.getInstance().isRecording()) {
                RecordableMod.sendClientMessage(activeClient, "Auto-recording started", false);
            }
        }
    }

    private static void stopIfRecording(class_310 client, String reason) {
        class_310 activeClient = resolveClient(client);
        if (activeClient != null && !activeClient.method_18854()) {
            executeOnClientThread(activeClient, () -> stopIfRecording(activeClient, reason), "auto-record stop");
            return;
        }

        RecordingManager recordingManager = RecordingManager.getInstance();
        if (recordingManager.isStopping()) {
            return;
        }

        if (recordingManager.isRecording() || recordingManager.isPaused()) {
            RecordableMod.sendClientMessage(activeClient, "Auto-recording stopped (" + reason + ")", true);
            recordingManager.stopRecording(activeClient, RecordingManager.StopReason.AUTO);
        }
    }

    private static class_310 resolveClient(class_310 client) {
        return client == null ? class_310.method_1551() : client;
    }

    private static void executeOnClientThread(class_310 client, Runnable runnable, String actionDescription) {
        if (client == null || runnable == null) {
            return;
        }
        try {
            client.execute(runnable);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to schedule Record-able {} on the client thread.", actionDescription, throwable);
        }
    }
}
