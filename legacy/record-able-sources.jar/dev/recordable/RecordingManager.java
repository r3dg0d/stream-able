package dev.recordable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_310;

/** Coordinates capture, frame pacing, FFmpeg encoding, state, and shutdown. */
public final class RecordingManager {
    public enum State {
        IDLE,
        STARTING,
        RECORDING,
        PAUSED,
        STOPPING
    }

    private static final RecordingManager INSTANCE = new RecordingManager();
    private static final int MAX_QUEUE_SIZE = 240;
    private static final long BACKLOG_LOG_INTERVAL_NANOS = 2_000_000_000L;
    private static final long PERFORMANCE_SAMPLE_INTERVAL_NANOS = 1_000_000_000L;

    private final Object lock = new Object();
    private final AtomicLong capturedFrames = new AtomicLong();
    private final AtomicLong skippedFrames = new AtomicLong();
    private final AtomicLong failedCaptures = new AtomicLong();
    private final AtomicLong adaptiveDroppedFrames = new AtomicLong();
    private final AtomicLong finalEncoderDroppedFrames = new AtomicLong();

    private volatile State state = State.IDLE;
    private ScreenCapture screenCapture;
    private FFmpegEncoder ffmpegEncoder;
    private FFmpegEncoder pendingStartFfmpegEncoder;
    private Path currentOutputFile;
    private Path lastOutputFile;
    private long startedAtNanos;
    private long lastFrameCaptureNanos;
    private long frameIntervalNanos;
    private int recordingFps = 60;
    private int recordingWidth;
    private int recordingHeight;
    private volatile String pendingJoinNotification;
    private long lastBacklogLogAtNanos;
    private long lastPerformanceSampleAtNanos;
    private long lastCapturedSample;
    private long lastEncoderWrittenSample;
    private volatile double captureFpsEstimate;
    private volatile double encoderFpsEstimate;
    private volatile boolean performanceSuggestionSent;
    private volatile int onFrameNullEncoderLogCount;

    // === Pause/Resume timestamp correction ===
    /** Total nanoseconds spent in paused state (accumulated across multiple pauses). */
    private long totalPausedNanos;
    /** Nano timestamp when the current pause started (0 if not paused). */
    private long pauseStartNanos;

    // === Post-recording toast notification ===
    private volatile String pendingToastMessage;
    private volatile Path pendingToastFilePath;
    private volatile long pendingToastExpiresAtMs;

    // === Recording timer ===
    /** Effective recording duration in millis (excluding paused time). */
    public long getEffectiveRecordingMillis() {
        if (!isActiveOrStopping() || startedAtNanos == 0L) return 0L;
        long now = System.nanoTime();
        long totalElapsed = now - startedAtNanos;
        long paused = totalPausedNanos;
        if (state == State.PAUSED && pauseStartNanos > 0) {
            paused += (now - pauseStartNanos);
        }
        return Math.max(0L, (totalElapsed - paused) / 1_000_000L);
    }

    public enum StopReason {
        MANUAL,
        DISCONNECT,
        SHUTDOWN,
        AUTO,
        FILE_SIZE_LIMIT
    }

    public enum QueueHealth {
        OK,
        SLOW,
        CRITICAL
    }

    private RecordingManager() {
    }

    public static RecordingManager getInstance() {
        return INSTANCE;
    }

    public void initialize() {
        FFmpegEncoder.detectFfmpeg();
    }

    /**
     * Returns {@code true} if the game is in a valid state for recording.
     */
    public static boolean isInGameState(class_310 client) {
        if (client == null) return false;
        return client.field_1687 != null && client.field_1724 != null;
    }

    public void toggleRecording(class_310 client) {
        State snapshot = state;
        if (snapshot == State.IDLE) {
            class_310 mc = resolveClient(client);
            if (!isInGameState(mc)) {
                return;
            }
            startRecording(client);
        } else if (snapshot == State.RECORDING || snapshot == State.PAUSED) {
            stopRecording(client);
        } else if (snapshot == State.STARTING) {
            RecordableMod.sendClientMessage(client, "Record-able is still initializing...", true);
        } else {
            RecordableMod.sendClientMessage(client, "Record-able is already stopping...", true);
        }
    }

    public void startRecording(class_310 client) {
        class_310 activeClient = resolveClient(client);
        if (activeClient != null && !activeClient.method_18854()) {
            executeOnClientThread(activeClient, () -> startRecording(activeClient), "start recording");
            return;
        }

        if (!isInGameState(activeClient)) {
            return;
        }

        RecordableConfig config;
        int targetWidth;
        int targetHeight;
        int targetFps;

        synchronized (lock) {
            if (state != State.IDLE) {
                RecordableMod.sendClientMessage(client, "Record-able is already active.", true);
                return;
            }

            if (!isInGameState(activeClient)) {
                return;
            }

            config = RecordableConfig.get();
            config.sanitize();
            if (!config.enabled) {
                RecordableMod.sendClientMessage(client, "Record-able is disabled in config.", false);
                return;
            }

            FFmpegEncoder.FfmpegStatus ffStatus = FFmpegEncoder.detectFfmpeg();
            if (!ffStatus.found()) {
                String hint = PlatformUtils.getFfmpegInstallHint();
                RecordableMod.sendClientMessage(client,
                        "§cFFmpeg is required but not found. " + hint, false);
                RecordableMod.sendClientMessage(client,
                        "§eOpen Record-able settings and click 'Download FFmpeg' for an automatic install.", false);
                return;
            }

            if (activeClient == null || activeClient.method_22683() == null) {
                RecordableMod.sendClientMessage(client, "Record-able could not access the Minecraft window.", false);
                return;
            }

            int nativeWidth = activeClient.method_22683().method_4489();
            int nativeHeight = activeClient.method_22683().method_4506();
            if (nativeWidth <= 0 || nativeHeight <= 0) {
                RecordableMod.sendClientMessage(client, "Record-able could not determine the framebuffer size.", false);
                return;
            }

            RecordableConfig.CaptureDimensions dimensions = config.resolveCaptureDimensions(nativeWidth, nativeHeight);
            targetWidth = makeEven(Math.max(2, dimensions.width()));
            targetHeight = makeEven(Math.max(2, dimensions.height()));
            targetFps = config.getFps();
            if (targetWidth != dimensions.width() || targetHeight != dimensions.height()) {
                RecordableMod.LOGGER.info("Adjusted recording resolution to even dimensions: {}x{} -> {}x{}",
                        dimensions.width(), dimensions.height(), targetWidth, targetHeight);
            }

            pendingStartFfmpegEncoder = new FFmpegEncoder(config, targetWidth, targetHeight, targetFps, MAX_QUEUE_SIZE);
            state = State.STARTING;
        }

        RecordableMod.LOGGER.info("Starting recording with FFmpeg encoder ({}x{} @ {} FPS).",
                targetWidth, targetHeight, targetFps);
        RecordableMod.sendClientMessage(activeClient, "Record-able initializing (FFmpeg)...", true);

        final int fWidth = targetWidth;
        final int fHeight = targetHeight;
        final int fFps = targetFps;

        CompletableFuture.runAsync(() -> {
            Path output = null;
            Throwable startFailure = null;
            try {
                class_310 clientSnapshot = resolveClient(activeClient);
                if (!isInGameState(clientSnapshot)) {
                    synchronized (lock) {
                        if (state == State.STARTING) {
                            state = State.IDLE;
                            pendingStartFfmpegEncoder = null;
                        }
                    }
                    return;
                }

                output = pendingStartFfmpegEncoder.start();
            } catch (Throwable throwable) {
                startFailure = throwable;
            }

            Path finalizedOutput = output;
            Throwable finalizedFailure = startFailure;
            executeOnClientThread(activeClient,
                    () -> completeStartOnClientThread(activeClient, config, fWidth, fHeight, fFps, finalizedOutput, finalizedFailure),
                    "complete recording start");
        });
    }

    private void completeStartOnClientThread(class_310 client,
                                             RecordableConfig config,
                                             int targetWidth,
                                             int targetHeight,
                                             int targetFps,
                                             Path output,
                                             Throwable startFailure) {
        boolean cancelled;
        synchronized (lock) {
            cancelled = state != State.STARTING;
        }

        if (cancelled) {
            RecordableMod.LOGGER.info("Background start completed after cancellation; stopping encoder instance.");
            stopPendingEncoder();
            return;
        }

        if (startFailure != null || output == null) {
            synchronized (lock) {
                state = State.IDLE;
                pendingStartFfmpegEncoder = null;
            }
            stopPendingEncoder();
            String reason = startFailure == null ? "Unknown startup failure" : startFailure.getMessage();
            RecordableMod.LOGGER.warn("Failed to start Record-able recording (resolution={}x{}, fps={}).",
                    targetWidth, targetHeight, targetFps, startFailure);
            RecordableMod.sendClientMessage(client, "Record-able could not start: " + reason, false);
            return;
        }

        ScreenCapture newCapture = null;
        try {
            newCapture = new ScreenCapture(targetWidth, targetHeight);

            synchronized (lock) {
                if (state != State.STARTING) {
                    throw new IOException("Recording start was cancelled before capture initialization completed.");
                }
                ffmpegEncoder = pendingStartFfmpegEncoder;
                RecordableMod.LOGGER.info("Assigned active FFmpeg encoder: {}", ffmpegEncoder != null ? "OK" : "NULL!");
                pendingStartFfmpegEncoder = null;
                screenCapture = newCapture;
                currentOutputFile = output;
                lastOutputFile = output;
                recordingWidth = targetWidth;
                recordingHeight = targetHeight;
                recordingFps = targetFps;
                capturedFrames.set(0L);
                skippedFrames.set(0L);
                failedCaptures.set(0L);
                adaptiveDroppedFrames.set(0L);
                finalEncoderDroppedFrames.set(0L);
                startedAtNanos = System.nanoTime();
                lastFrameCaptureNanos = 0L;
                totalPausedNanos = 0L;
                pauseStartNanos = 0L;
                frameIntervalNanos = Math.max(1L, 1_000_000_000L / Math.max(1, recordingFps));
                lastBacklogLogAtNanos = 0L;
                lastPerformanceSampleAtNanos = startedAtNanos;
                lastCapturedSample = 0L;
                lastEncoderWrittenSample = 0L;
                captureFpsEstimate = 0.0D;
                encoderFpsEstimate = 0.0D;
                performanceSuggestionSent = false;
                onFrameNullEncoderLogCount = 0;
                state = State.RECORDING;
            }

            // Start replay buffer if enabled, with memory safety check
            if (config.replayBufferEnabled) {
                String memorySafetyWarning = ReplayBuffer.checkMemorySafety(
                        recordingWidth, recordingHeight, recordingFps, config.replayBufferDurationSeconds);
                if (memorySafetyWarning != null) {
                    RecordableMod.LOGGER.warn("Replay buffer disabled due to low memory: {}", memorySafetyWarning);
                    RecordableMod.sendClientMessage(client,
                            "§eReplay buffer skipped: insufficient memory. " + memorySafetyWarning, true);
                } else {
                    ReplayBuffer.getInstance().start(recordingWidth, recordingHeight,
                            recordingFps, config.replayBufferDurationSeconds);
                }
            }

            boolean audioActive = ffmpegEncoder != null && ffmpegEncoder.isAudioEnabled();
            String audioDevStr = ffmpegEncoder != null ? ffmpegEncoder.getAudioDeviceInfo() : "";
            String audioInfo;
            if (audioActive) {
                audioInfo = " + audio [" + audioDevStr + "]";
            } else if (config.captureAudio) {
                audioInfo = " (audio unavailable - recording video only)";
                RecordableMod.sendClientMessage(client,
                        "§eAudio unavailable. Recording video only.", true);
            } else {
                audioInfo = "";
            }

            RecordableMod.sendClientMessage(
                    client,
                    "Record-able recording started: " + output.getFileName()
                            + " (" + recordingWidth + "x" + recordingHeight
                            + " @ " + recordingFps + " FPS" + audioInfo + ")",
                    false
            );
            RecordableMod.LOGGER.info("Recording started: file={} resolution={}x{} fps={} audioEnabled={} audioDevice={}",
                    output, recordingWidth, recordingHeight, recordingFps, audioActive, audioDevStr);
        } catch (Throwable throwable) {
            synchronized (lock) {
                state = State.IDLE;
                pendingStartFfmpegEncoder = null;
                ffmpegEncoder = null;
                screenCapture = null;
            }
            if (newCapture != null) {
                try {
                    newCapture.close();
                } catch (Throwable closeThrowable) {
                    RecordableMod.LOGGER.debug("Failed to close capture after start failure.", closeThrowable);
                }
            }
            stopPendingEncoder();
            RecordableMod.LOGGER.warn("Failed to finalize Record-able start on client thread.", throwable);
            RecordableMod.sendClientMessage(client, "Record-able could not start: " + throwable.getMessage(), false);
        }
    }

    private void stopPendingEncoder() {
        try {
            if (pendingStartFfmpegEncoder != null) {
                pendingStartFfmpegEncoder.stop();
            }
        } catch (Throwable t) {
            RecordableMod.LOGGER.debug("Encoder cleanup after failed/cancelled start.", t);
        }
    }

    public void pauseRecording(class_310 client) {
        class_310 activeClient = resolveClient(client);
        if (activeClient != null && !activeClient.method_18854()) {
            executeOnClientThread(activeClient, () -> pauseRecording(activeClient), "pause recording");
            return;
        }

        synchronized (lock) {
            if (state != State.RECORDING) {
                return;
            }
            state = State.PAUSED;
            pauseStartNanos = System.nanoTime();
            lastFrameCaptureNanos = 0L;
        }
        RecordableMod.LOGGER.info("Recording paused. Effective duration so far: {}",
                formatDuration(getEffectiveRecordingMillis()));
        RecordableMod.sendClientMessage(activeClient, "§e⏸ Record-able paused.", true);
    }

    public void resumeRecording(class_310 client) {
        class_310 activeClient = resolveClient(client);
        if (activeClient != null && !activeClient.method_18854()) {
            executeOnClientThread(activeClient, () -> resumeRecording(activeClient), "resume recording");
            return;
        }

        synchronized (lock) {
            if (state != State.PAUSED) {
                return;
            }
            // Accumulate pause duration
            if (pauseStartNanos > 0) {
                totalPausedNanos += (System.nanoTime() - pauseStartNanos);
                pauseStartNanos = 0;
            }
            state = State.RECORDING;
            lastFrameCaptureNanos = 0L;
        }
        RecordableMod.LOGGER.info("Recording resumed. Total paused time: {}ms",
                totalPausedNanos / 1_000_000L);
        RecordableMod.sendClientMessage(activeClient, "§a▶ Record-able resumed.", true);
    }

    /** Toggle between paused and recording states. */
    public void togglePause(class_310 client) {
        State snapshot = state;
        if (snapshot == State.RECORDING) {
            pauseRecording(client);
        } else if (snapshot == State.PAUSED) {
            resumeRecording(client);
        }
    }

    public void stopRecording(class_310 client) {
        stopRecording(client, StopReason.MANUAL);
    }

    public void stopRecordingForDisconnect(class_310 client) {
        stopRecording(client, StopReason.DISCONNECT);
    }

    public void stopRecording(class_310 client, StopReason stopReason) {
        StopReason reason = stopReason == null ? StopReason.MANUAL : stopReason;
        class_310 activeClient = resolveClient(client);
        if (reason != StopReason.DISCONNECT && reason != StopReason.SHUTDOWN) {
            if (activeClient != null && !activeClient.method_18854()) {
                executeOnClientThread(activeClient, () -> stopRecording(activeClient, reason), "stop recording");
                return;
            }
        }

        FFmpegEncoder ffmpegToStop = null;
        ScreenCapture captureToClose;
        Path output;
        boolean cancelledDuringStart = false;
        synchronized (lock) {
            if (state == State.IDLE) {
                if (reason != StopReason.DISCONNECT && reason != StopReason.SHUTDOWN) {
                    RecordableMod.sendClientMessage(activeClient, "Record-able is not recording.", true);
                }
                return;
            }
            if (state == State.STOPPING) {
                if (reason != StopReason.DISCONNECT && reason != StopReason.SHUTDOWN) {
                    RecordableMod.sendClientMessage(activeClient, "Record-able is already stopping...", true);
                }
                return;
            }
            if (state == State.STARTING) {
                cancelledDuringStart = true;
                state = State.IDLE;
                ffmpegToStop = pendingStartFfmpegEncoder;
                pendingStartFfmpegEncoder = null;
                captureToClose = null;
                output = currentOutputFile;
                lastFrameCaptureNanos = 0L;
                frameIntervalNanos = 0L;
            } else {
                state = State.STOPPING;
                ffmpegToStop = ffmpegEncoder;
                captureToClose = screenCapture;
                output = currentOutputFile;
                ffmpegEncoder = null;
                screenCapture = null;
                lastFrameCaptureNanos = 0L;
                frameIntervalNanos = 0L;
            }
        }

        if (cancelledDuringStart) {
            RecordableMod.LOGGER.info("Recording start cancelled before activation.");
            final FFmpegEncoder ffmpegCancel = ffmpegToStop;
            Thread cancelThread = new Thread(() -> {
                try {
                    if (ffmpegCancel != null) ffmpegCancel.stop();
                } catch (Throwable throwable) {
                    RecordableMod.LOGGER.warn("Failed to stop encoder after start cancellation.", throwable);
                }
            }, "Record-able Start Cancel Stopper");
            cancelThread.setDaemon(true);
            cancelThread.start();
            if (reason != StopReason.DISCONNECT && reason != StopReason.SHUTDOWN) {
                RecordableMod.sendClientMessage(activeClient, "Record-able initialization cancelled.", true);
            }
            return;
        }

        RecordableMod.LOGGER.info(
                "Recording stop requested: reason={} output={} capturedFrames={} droppedFrames={} failedCaptures={}",
                reason, output, capturedFrames.get(), skippedFrames.get(), failedCaptures.get());

        closeCaptureSafely(activeClient, captureToClose, reason);

        final FFmpegEncoder ffmpegFinal = ffmpegToStop;
        Thread stopper = new Thread(() -> finishStop(activeClient, ffmpegFinal, output, reason), "Record-able Stopper");
        stopper.setDaemon(true);
        stopper.start();

        if (reason != StopReason.DISCONNECT && reason != StopReason.SHUTDOWN) {
            RecordableMod.sendClientMessage(activeClient, "Record-able stopping and finalizing video...", true);
        }
    }

    public void onFrame() {
        // Feed replay buffer even when not recording (if active)
        // Note: Actual frame capture for replay buffer is done inside the recording flow
        // to avoid double-capturing. When not recording, we'd need ScreenCapture active,
        // which isn't the case. Replay buffer only captures during recording sessions.

        if (state != State.RECORDING) {
            return;
        }

        FFmpegEncoder activeFfmpeg;
        ScreenCapture activeCapture;
        synchronized (lock) {
            if (state != State.RECORDING || screenCapture == null) {
                return;
            }
            if (ffmpegEncoder == null) {
                long captured = capturedFrames.get();
                if (captured == 0 && onFrameNullEncoderLogCount < 3) {
                    onFrameNullEncoderLogCount++;
                    RecordableMod.LOGGER.error("onFrame: encoder is null while RECORDING! state={} screenCapture={}",
                            state, screenCapture != null);
                }
                return;
            }
            activeFfmpeg = ffmpegEncoder;
            activeCapture = screenCapture;
        }

        long now = System.nanoTime();
        if (!shouldCaptureFrame(now)) {
            return;
        }

        try {
            ScreenCapture.CapturedFrame frame = activeCapture.captureFrame();
            if (frame == null) {
                return;
            }

            // Use pause-corrected timestamp (subtract total paused time)
            long nowNs = System.nanoTime();
            long frameTimestampMs = startedAtNanos > 0L
                    ? (nowNs - startedAtNanos - totalPausedNanos) / 1_000_000L
                    : -1L;
            boolean queued = activeFfmpeg.writeFrame(frame.rgbPixels(), frameTimestampMs) == FFmpegEncoder.EnqueueResult.QUEUED;

            // Feed replay buffer with captured frame data
            if (ReplayBuffer.getInstance().isActive()) {
                ReplayBuffer.getInstance().addFrame(frame.rgbPixels());
            }

            if (queued) {
                long totalCaptured = capturedFrames.incrementAndGet();
                long logInterval = Math.max(1L, (long) recordingFps * 10L);
                if (totalCaptured % logInterval == 0L) {
                    RecordableMod.LOGGER.info(
                            "Frames captured: {} (encoderWritten={} encoderDropped={} queue={}/{} | adaptiveDropped={})",
                            totalCaptured,
                            activeFfmpeg.getWrittenFrames(),
                            activeFfmpeg.getDroppedFrames(),
                            activeFfmpeg.getQueueSize(),
                            activeFfmpeg.getQueueCapacity(),
                            adaptiveDroppedFrames.get());
                }
            } else {
                skippedFrames.incrementAndGet();
                logBacklogIfNeeded(now);
            }
        } catch (Throwable throwable) {
            failedCaptures.incrementAndGet();
            RecordableMod.LOGGER.warn("Record-able failed to capture a frame.", throwable);
        }
    }

    public void onClientTick(class_310 client) {
        if (state != State.RECORDING) {
            return;
        }

        RecordableConfig config = RecordableConfig.get();
        if (config.maxFileSizeMB > 0) {
            long maxBytes = config.maxFileSizeMB * 1024L * 1024L;
            long currentBytes = getCurrentFileSizeBytes();
            if (currentBytes >= maxBytes && currentBytes > 0L) {
                RecordableMod.LOGGER.info("File size limit reached: {} >= {} MB. Stopping recording.",
                        formatBytes(currentBytes), config.maxFileSizeMB);
                RecordableMod.sendClientMessage(client,
                        "§eRecord-able auto-stopped: file size limit reached (" + config.maxFileSizeMB + " MB). "
                        + "Increase the limit in settings or set to 0 for unlimited.", false);
                stopRecording(client, StopReason.FILE_SIZE_LIMIT);
                return;
            }
        }

        samplePerformanceMetrics();

        if (!performanceSuggestionSent && getDroppedFrames() >= 100L) {
            performanceSuggestionSent = true;
            RecordableMod.LOGGER.warn("Performance issue detected - droppedFrames={} queue={}/{}.",
                    getDroppedFrames(), getQueueSize(), getQueueCapacity());
            RecordableMod.sendClientMessage(client,
                    "§eRecord-able is dropping frames. Try 720p/30fps or Quality=Performance for smoother recording.",
                    true);
        }
    }

    public void shutdown() {
        try {
            class_310 activeClient = resolveClient(null);
            if (activeClient != null && !activeClient.method_18854()) {
                try {
                    activeClient.method_19537(this::shutdown);
                    return;
                } catch (Throwable throwable) {
                    RecordableMod.LOGGER.warn("Failed to marshal shutdown onto client thread.", throwable);
                }
            }
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Could not resolve client during shutdown.", throwable);
        }
        doShutdown();
    }

    public void forceShutdown() {
        doShutdown();
    }

    private void doShutdown() {
        FFmpegEncoder ffmpegToStop;
        ScreenCapture captureToClose;
        synchronized (lock) {
            if (state == State.IDLE) {
                return;
            }
            state = State.STOPPING;
            ffmpegToStop = ffmpegEncoder != null ? ffmpegEncoder : pendingStartFfmpegEncoder;
            captureToClose = screenCapture;
            ffmpegEncoder = null;
            pendingStartFfmpegEncoder = null;
            screenCapture = null;
            lastFrameCaptureNanos = 0L;
            frameIntervalNanos = 0L;
        }

        if (captureToClose != null) {
            try {
                captureToClose.close();
            } catch (Throwable throwable) {
                RecordableMod.LOGGER.warn("Failed to close screen capture during shutdown.", throwable);
            }
        }
        if (ffmpegToStop != null) {
            try {
                Path finalized = ffmpegToStop.stop();
                if (finalized != null) {
                    outputFileFromStop(finalized);
                }
                finalEncoderDroppedFrames.addAndGet(ffmpegToStop.getDroppedFrames());
            } catch (Throwable throwable) {
                RecordableMod.LOGGER.warn("Failed to stop FFmpeg encoder during shutdown.", throwable);
            }
        }

        synchronized (lock) {
            state = State.IDLE;
            startedAtNanos = 0L;
            lastFrameCaptureNanos = 0L;
            frameIntervalNanos = 0L;
            captureFpsEstimate = 0.0D;
            encoderFpsEstimate = 0.0D;
            performanceSuggestionSent = false;
        }
    }

    private void finishStop(class_310 client,
                            FFmpegEncoder ffmpegToStop,
                            Path output,
                            StopReason reason) {
        Path finalizedOutput = output;
        long encoderWritten = 0L;
        if (ffmpegToStop != null) {
            Path encoderOutput = ffmpegToStop.stop();
            if (encoderOutput != null) {
                finalizedOutput = encoderOutput;
            }
            finalEncoderDroppedFrames.addAndGet(ffmpegToStop.getDroppedFrames());
            encoderWritten = ffmpegToStop.getWrittenFrames();
        }

        long fileSize = safeFileSize(finalizedOutput);
        long durationMillis;
        synchronized (lock) {
            durationMillis = startedAtNanos > 0L ? Math.max(0L, (System.nanoTime() - startedAtNanos) / 1_000_000L) : 0L;
            startedAtNanos = 0L;
            state = State.IDLE;
            pendingStartFfmpegEncoder = null;
            currentOutputFile = finalizedOutput;
            lastOutputFile = finalizedOutput;
            lastFrameCaptureNanos = 0L;
            frameIntervalNanos = 0L;
            captureFpsEstimate = 0.0D;
            encoderFpsEstimate = 0.0D;
            performanceSuggestionSent = false;
        }

        if (reason == StopReason.DISCONNECT) {
            pendingJoinNotification = "Previous recording was saved: "
                    + (finalizedOutput == null ? "recording" : finalizedOutput.getFileName());
            RecordableMod.LOGGER.info("Recording saved (disconnected): {} ({}).", finalizedOutput, formatBytes(fileSize));
            return;
        }

        if (reason != StopReason.SHUTDOWN) {
            Path messageOutput = finalizedOutput;
            String savedMsg = "Record-able saved " + (messageOutput == null ? "recording" : messageOutput.getFileName()) + " (" + formatBytes(fileSize) + ")";
            runOnClient(client, () -> RecordableMod.sendClientMessage(client, savedMsg, false));

            // Feature 6: Post-Recording Toast Notification
            if (RecordableConfig.get().showPostRecordingToast) {
                pendingToastMessage = "§a✓ Recording saved: §f" + (messageOutput == null ? "recording" : messageOutput.getFileName())
                        + " §7(" + formatBytes(fileSize) + ", " + formatDuration(durationMillis) + ")";
                pendingToastFilePath = messageOutput != null ? messageOutput.getParent() : null;
                pendingToastExpiresAtMs = System.currentTimeMillis() + 8000; // 8-second toast
            }
        }
        RecordableMod.LOGGER.info("Recording stopped: reason={} duration={} framesCaptured={} dropped={} encoderWritten={} file={} ({})",
                reason, formatDuration(durationMillis), capturedFrames.get(), getDroppedFrames(),
                encoderWritten, finalizedOutput, formatBytes(fileSize));
    }

    private void logBacklogIfNeeded(long nowNanos) {
        if (nowNanos - lastBacklogLogAtNanos < BACKLOG_LOG_INTERVAL_NANOS) {
            return;
        }
        lastBacklogLogAtNanos = nowNanos;
        int qSize = getQueueSize();
        int qCapacity = getQueueCapacity();
        double queueRatio = qCapacity <= 0 ? 0.0D : qSize / (double) qCapacity;
        RecordableMod.LOGGER.warn(
                "Encoder falling behind - dropping frames. Queue: {}/{} ({}%) | dropped={} (adaptive={})",
                qSize, qCapacity, Math.round(queueRatio * 100.0D),
                getDroppedFrames(), adaptiveDroppedFrames.get());
    }

    private void samplePerformanceMetrics() {
        FFmpegEncoder ff = ffmpegEncoder;
        if (ff == null) {
            return;
        }

        long now = System.nanoTime();
        if (lastPerformanceSampleAtNanos == 0L) {
            lastPerformanceSampleAtNanos = now;
            lastCapturedSample = capturedFrames.get();
            lastEncoderWrittenSample = ff.getWrittenFrames();
            return;
        }

        long elapsed = now - lastPerformanceSampleAtNanos;
        if (elapsed < PERFORMANCE_SAMPLE_INTERVAL_NANOS) {
            return;
        }

        long capturedNow = capturedFrames.get();
        long writtenNow = ff.getWrittenFrames();
        double elapsedSeconds = Math.max(0.001D, elapsed / 1_000_000_000.0D);

        captureFpsEstimate = Math.max(0.0D, (capturedNow - lastCapturedSample) / elapsedSeconds);
        encoderFpsEstimate = Math.max(0.0D, (writtenNow - lastEncoderWrittenSample) / elapsedSeconds);

        lastCapturedSample = capturedNow;
        lastEncoderWrittenSample = writtenNow;
        lastPerformanceSampleAtNanos = now;
    }

    private boolean shouldCaptureFrame(long nowNanos) {
        long interval = frameIntervalNanos > 0L
                ? frameIntervalNanos
                : Math.max(1L, 1_000_000_000L / Math.max(1, recordingFps));

        if (lastFrameCaptureNanos > 0L && nowNanos - lastFrameCaptureNanos < interval) {
            return false;
        }

        double queueRatio = getActiveQueueUsageRatio();
        if (queueRatio >= 0.90) {
            long total = capturedFrames.get() + skippedFrames.get();
            if (total % 4 != 0) {
                adaptiveDroppedFrames.incrementAndGet();
                return false;
            }
        } else if (queueRatio >= 0.70) {
            long total = capturedFrames.get() + skippedFrames.get();
            if (total % 2 != 0) {
                adaptiveDroppedFrames.incrementAndGet();
                return false;
            }
        }

        lastFrameCaptureNanos = nowNanos;
        return true;
    }

    private static class_310 resolveClient(class_310 client) {
        return client == null ? class_310.method_1551() : client;
    }

    private static void executeOnClientThread(class_310 client, Runnable runnable, String actionDescription) {
        if (client == null || runnable == null) {
            return;
        }
        try {
            client.execute(runnable);
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to schedule Record-able {} on client thread.", actionDescription, throwable);
        }
    }

    private static void runOnClient(class_310 client, Runnable runnable) {
        if (runnable == null) return;
        try {
            class_310 activeClient = resolveClient(client);
            if (activeClient != null && !activeClient.method_18854()) {
                activeClient.execute(runnable);
            } else {
                runnable.run();
            }
        } catch (Throwable throwable) {
            runnable.run();
        }
    }

    private void closeCaptureSafely(class_310 client, ScreenCapture capture, StopReason reason) {
        if (capture == null) return;

        Runnable closeTask = () -> {
            try {
                capture.close();
            } catch (Throwable throwable) {
                RecordableMod.LOGGER.warn("Failed to close screen capture (reason={}).", reason, throwable);
            }
        };

        class_310 activeClient = resolveClient(client);
        if (activeClient != null && !activeClient.method_18854()) {
            try {
                activeClient.execute(closeTask);
                return;
            } catch (Throwable throwable) {
                RecordableMod.LOGGER.warn("Failed to schedule screen-capture close; closing on current thread.", throwable);
            }
        }
        closeTask.run();
    }

    public State getState() { return state; }
    public boolean isRecording() { return state == State.RECORDING; }
    public boolean isStopping() { return state == State.STOPPING || state == State.STARTING; }
    public boolean isPaused() { return state == State.PAUSED; }

    public boolean isActiveOrStopping() {
        return state == State.STARTING || state == State.RECORDING || state == State.PAUSED || state == State.STOPPING;
    }

    public String consumePendingJoinNotification() {
        String notification = pendingJoinNotification;
        pendingJoinNotification = null;
        return notification;
    }

    public long getElapsedMillis() {
        if (!isActiveOrStopping() || startedAtNanos == 0L) return 0L;
        return Math.max(0L, (System.nanoTime() - startedAtNanos) / 1_000_000L);
    }

    public long getCapturedFrames() { return capturedFrames.get(); }

    public long getDroppedFrames() {
        FFmpegEncoder ff = ffmpegEncoder;
        long encoderDrops = ff != null ? ff.getDroppedFrames() : finalEncoderDroppedFrames.get();
        return skippedFrames.get() + failedCaptures.get() + encoderDrops;
    }

    public long getAdaptiveDroppedFrames() { return adaptiveDroppedFrames.get(); }

    public QueueHealth getQueueHealth() {
        double ratio = getActiveQueueUsageRatio();
        if (ratio >= 0.90D) return QueueHealth.CRITICAL;
        if (ratio >= 0.50D) return QueueHealth.SLOW;
        return QueueHealth.OK;
    }

    public double getCaptureFpsEstimate() { return captureFpsEstimate; }

    public double getEncoderFpsEstimate() {
        FFmpegEncoder ff = ffmpegEncoder;
        double realtime = ff != null ? ff.getEstimatedEncoderFps() : 0.0D;
        return Math.max(encoderFpsEstimate, realtime);
    }

    public long getUsedMemoryMiB() {
        Runtime runtime = Runtime.getRuntime();
        long usedBytes = Math.max(0L, runtime.totalMemory() - runtime.freeMemory());
        return usedBytes / (1024L * 1024L);
    }

    public int getRecordingFps() { return recordingFps; }
    public int getRecordingWidth() { return recordingWidth; }
    public int getRecordingHeight() { return recordingHeight; }

    public int getQueueSize() {
        FFmpegEncoder ff = ffmpegEncoder;
        return ff != null ? ff.getQueueSize() : 0;
    }

    public int getQueueCapacity() {
        FFmpegEncoder ff = ffmpegEncoder;
        return ff != null ? ff.getQueueCapacity() : MAX_QUEUE_SIZE;
    }

    public long getCurrentFileSizeBytes() {
        FFmpegEncoder ff = ffmpegEncoder;
        long size = ff != null ? ff.getOutputFileSizeBytes() : 0L;
        if (size > 0L) return size;
        return safeFileSize(currentOutputFile == null ? lastOutputFile : currentOutputFile);
    }

    public EncoderType getActiveEncoderType() { return EncoderType.FFMPEG; }
    public Path getCurrentOutputFile() { return currentOutputFile == null ? lastOutputFile : currentOutputFile; }
    public Path getCurrentOutputDirectory() { return RecordableConfig.get().getOutputDirectory(); }

    // === Toast notification getters ===
    public String getPendingToastMessage() {
        if (pendingToastMessage != null && System.currentTimeMillis() > pendingToastExpiresAtMs) {
            pendingToastMessage = null;
            pendingToastFilePath = null;
        }
        return pendingToastMessage;
    }

    public Path getPendingToastFilePath() { return pendingToastFilePath; }

    public void dismissToast() {
        pendingToastMessage = null;
        pendingToastFilePath = null;
    }

    /** Estimate file size based on bitrate and effective recording time. */
    public String getEstimatedFileSize() {
        long effectiveMs = getEffectiveRecordingMillis();
        long currentSize = getCurrentFileSizeBytes();
        if (currentSize > 0 && effectiveMs > 2000) {
            // Extrapolate: current size is our best indicator
            return formatBytes(currentSize);
        }
        return "calculating...";
    }

    private double getActiveQueueUsageRatio() {
        FFmpegEncoder ff = ffmpegEncoder;
        return ff != null ? ff.getQueueUsageRatio() : 0.0D;
    }

    public static String formatDuration(long elapsedMillis) {
        long seconds = elapsedMillis / 1_000L;
        long hours = seconds / 3_600L;
        long minutes = (seconds % 3_600L) / 60L;
        long remainingSeconds = seconds % 60L;
        if (hours > 0L) return String.format("%d:%02d:%02d", hours, minutes, remainingSeconds);
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    public static String formatBytes(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        double kib = bytes / 1024.0D;
        if (kib < 1024.0D) return String.format("%.1f KiB", kib);
        double mib = kib / 1024.0D;
        if (mib < 1024.0D) return String.format("%.1f MiB", mib);
        return String.format("%.2f GiB", mib / 1024.0D);
    }

    private void outputFileFromStop(Path finalized) {
        synchronized (lock) {
            currentOutputFile = finalized;
            lastOutputFile = finalized;
        }
    }

    private static int makeEven(int value) { return value % 2 == 0 ? value : value - 1; }

    private static long safeFileSize(Path path) {
        if (path == null) return 0L;
        try { return Files.exists(path) ? Files.size(path) : 0L; }
        catch (IOException exception) { return 0L; }
    }
}
