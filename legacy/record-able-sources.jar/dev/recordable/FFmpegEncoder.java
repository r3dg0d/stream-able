package dev.recordable;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.Collectors;
import net.minecraft.class_310;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Asynchronous FFmpeg raw-video encoder.
 *
 * <p>The render thread only enqueues frame bytes. A writer thread drains the
 * bounded queue into FFmpeg's stdin, so short encoder stalls do not freeze the
 * game. If the queue fills, the current frame is dropped.</p>
 */
public final class FFmpegEncoder {
    public enum EnqueueResult {
        QUEUED,
        REJECTED
    }

    private static final int DEFAULT_QUEUE_CAPACITY = 120;
    private static final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
    private static volatile FfmpegStatus cachedStatus;
    private static volatile long cachedStatusAtMs;

    private final RecordableConfig config;
    private final int width;
    private final int height;
    private final int fps;
    private final int frameByteSize;
    private final int queueCapacity;
    private final ArrayBlockingQueue<FramePacket> queue;
    private final AtomicBoolean acceptingFrames = new AtomicBoolean(false);
    private final AtomicLong droppedFrames = new AtomicLong();
    private final AtomicLong writtenFrames = new AtomicLong();
    private final AtomicLong writerStartedAtNanos = new AtomicLong();

    private Process process;
    private OutputStream ffmpegStdin;
    private Thread writerThread;
    private Thread stderrThread;
    private Path outputFile;
    private String commandLine = "";
    private volatile String lastError = "";
    private volatile boolean audioEnabled = false;
    private volatile String audioDeviceInfo = "";
    private volatile long recordingStartNanos = 0L;

    private volatile long parsedSizeBytes = 0L;
    private volatile long parsedFrameCount = 0L;
    private volatile double parsedFps = 0.0;
    private volatile double parsedBitrate = 0.0;
    private volatile String parsedSpeed = "";
    /** Nano timestamp when audio recording stream was actually connected. */
    private volatile long audioRecordingStartNanos = 0L;
    /** Whether loopback audio connection was deferred until video is ready. */
    private volatile boolean deferredLoopbackConnection = false;

    private String ffmpegExecutable = "ffmpeg";
    private OpenALAudioCapture openAlCapture;
    private Thread audioWriterThread;
    private Path tempAudioFile;
    private volatile boolean audioWriterRunning;
    private Process ffmpegAudioProcess;
    private Thread ffmpegAudioStderrThread;
    private java.io.BufferedOutputStream loopbackAudioStream;
    private java.io.FileOutputStream loopbackFileStream;
    private volatile AudioCapture.AudioDeviceStatus detectedAudioStatus;

    public FFmpegEncoder(RecordableConfig config, int width, int height, int fps) {
        this(config, width, height, fps, DEFAULT_QUEUE_CAPACITY);
    }

    public FFmpegEncoder(RecordableConfig config, int width, int height, int fps, int queueCapacity) {
        this.config = config;
        this.width = width;
        this.height = height;
        this.fps = fps;
        this.frameByteSize = Math.max(1, width * height * 3);
        this.queueCapacity = Math.max(30, queueCapacity);
        this.queue = new ArrayBlockingQueue<>(this.queueCapacity);
    }

    public Path start() throws IOException {
        if (!PlatformUtils.isRecordingSupported()) {
            throw new IOException("Recording is not supported on " + PlatformUtils.detectPlatform().displayName()
                    + ". " + PlatformUtils.getFfmpegInstallHint());
        }

        FfmpegStatus status = detectFfmpeg();
        if (!status.found()) {
            String hint = PlatformUtils.getFfmpegInstallHint();
            RecordableMod.LOGGER.error("FFmpeg not found on {}. {}", PlatformUtils.detectPlatform().displayName(), hint);
            throw new IOException(status.error().isBlank()
                    ? "FFmpeg was not found. " + hint
                    : status.error() + " - " + hint);
        }

        ffmpegExecutable = status.executable();

        Path outputDirectory = config.getOutputDirectory();
        Files.createDirectories(outputDirectory);
        outputFile = outputDirectory.resolve("recordable-" + FILE_TIMESTAMP.format(LocalDateTime.now()) + "." + config.getFormat());

        audioEnabled = false;
        audioDeviceInfo = "";
        tempAudioFile = null;
        detectedAudioStatus = null;

        startFfmpegAudioCapture(outputDirectory);

        List<String> command = buildCommand(ffmpegExecutable, outputFile);
        commandLine = joinCommand(command);
        RecordableMod.LOGGER.info("=== FFmpeg Encoder Configuration ===");
        RecordableMod.LOGGER.info("Resolution: {}x{} | FPS: {} | Format: {} | Frame size: {} bytes",
                width, height, fps, config.getFormat(), frameByteSize);
        RecordableMod.LOGGER.info("Queue capacity: {} | Output: {}", queueCapacity, outputFile);
        RecordableMod.LOGGER.info("Complete FFmpeg command:");
        RecordableMod.LOGGER.info("{}", commandLine);
        RecordableMod.LOGGER.info("FFmpeg arguments breakdown:");
        for (int i = 0; i < command.size(); i++) {
            RecordableMod.LOGGER.info("  [{}] = {}", i, command.get(i));
        }

        ProcessBuilder processBuilder = new ProcessBuilder(command);
        processBuilder.directory(outputDirectory.toFile());
        processBuilder.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        try {
            class_310 client = class_310.method_1551();
            if (!RecordingManager.isInGameState(client)) {
                throw new IOException("Blocked FFmpeg start because client is not in-game.");
            }

            process = processBuilder.start();
            int pipeBuffer = Math.max(frameByteSize + 65536, 8 * 1024 * 1024);
            ffmpegStdin = new BufferedOutputStream(process.getOutputStream(), pipeBuffer);

            Thread.sleep(150);

            if (!process.isAlive()) {
                int exitCode = process.exitValue();
                stopAudioCapture();
                throw new IOException("FFmpeg exited immediately with code " + exitCode
                        + ". Command: " + commandLine
                        + (lastError.isEmpty() ? "" : ". Last error: " + lastError));
            }

            acceptingFrames.set(true);

            recordingStartNanos = System.nanoTime();
            writerStartedAtNanos.set(recordingStartNanos);

            // CRITICAL FIX: Connect loopback audio stream NOW, after video is ready.
            // This ensures audio and video start capturing at the same instant,
            // eliminating the 150-300ms audio lead that caused persistent desync.
            connectDeferredLoopbackAudio();

            writerThread = new Thread(this::writerLoop, "Record-able FFmpeg Writer");
            writerThread.setDaemon(true);
            writerThread.setPriority(Math.min(Thread.MAX_PRIORITY - 1, Thread.NORM_PRIORITY + 1));
            writerThread.start();

            stderrThread = new Thread(() -> stderrLoop(process.getErrorStream()), "Record-able FFmpeg Log");
            stderrThread.setDaemon(true);
            stderrThread.start();

            RecordableMod.LOGGER.info("FFmpeg process started successfully (pid={}). Waiting for frames...",
                    process.pid());
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            stopAudioCapture();
            throw new IOException("Interrupted while waiting for FFmpeg to initialize.", exception);
        } catch (IOException exception) {
            stopAudioCapture();
            throw exception;
        }

        return outputFile;
    }

    public EnqueueResult writeFrame(ByteBuffer frameData) {
        if (frameData == null) {
            return EnqueueResult.REJECTED;
        }
        ByteBuffer duplicate = frameData.slice();
        byte[] copy = new byte[duplicate.remaining()];
        duplicate.get(copy);
        return writeFrame(copy, -1L);
    }

    public EnqueueResult writeFrame(byte[] frameData) {
        return writeFrame(frameData, -1L);
    }

    /**
     * Enqueues a frame with a wall-clock timestamp (ms since recording started).
     *
     * <p>When the queue is full, the frame is dropped but the timestamp gap is
     * remembered. The writer loop uses timestamps to duplicate the most recent
     * frame and fill gaps, keeping video duration in sync with real elapsed time.</p>
     */
    public EnqueueResult writeFrame(byte[] frameData, long frameTimestampMs) {
        if (!acceptingFrames.get() || frameData == null || frameData.length != frameByteSize) {
            if (frameData != null && frameData.length != frameByteSize) {
                RecordableMod.LOGGER.warn("Frame size mismatch: expected {} bytes, got {} bytes. Frame rejected.",
                        frameByteSize, frameData.length);
            }
            return EnqueueResult.REJECTED;
        }

        long ts = frameTimestampMs;
        if (ts < 0 && recordingStartNanos > 0L) {
            ts = (System.nanoTime() - recordingStartNanos) / 1_000_000L;
        }

        FramePacket packet = new FramePacket(frameData, ts);
        if (queue.offer(packet)) {
            long totalWritten = writtenFrames.get();
            if (totalWritten == 0 && queue.size() == 1) {
                RecordableMod.LOGGER.info("First frame enqueued! Size: {} bytes, expected: {} bytes. FFmpeg alive: {}",
                        frameData.length, frameByteSize, process != null && process.isAlive());
            }
            return EnqueueResult.QUEUED;
        }

        droppedFrames.incrementAndGet();
        return EnqueueResult.REJECTED;
    }

    public Path stop() {
        acceptingFrames.set(false);

        if (writerThread != null) {
            try {
                writerThread.join(15_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
        }

        closeStdinQuietly();

        if (process != null) {
            try {
                if (!process.waitFor(10, TimeUnit.SECONDS)) {
                    RecordableMod.LOGGER.warn("FFmpeg did not exit after stdin closed; destroying process.");
                    process.destroy();
                    if (!process.waitFor(3, TimeUnit.SECONDS)) {
                        process.destroyForcibly();
                    }
                }
                int exitCode = process.exitValue();
                if (exitCode != 0) {
                    RecordableMod.LOGGER.warn("FFmpeg exited with code {}. Last message: {}", exitCode, lastError);
                }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                process.destroyForcibly();
            } finally {
                closeProcessStreamsQuietly();
            }
        }

        if (stderrThread != null) {
            try {
                stderrThread.join(1_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
        }

        stopAudioCapture();

        if (outputFile == null) {
            deleteTempAudioFileQuietly();
            return null;
        }

        try {
            if (!Files.exists(outputFile) || Files.size(outputFile) <= 0L) {
                RecordableMod.LOGGER.warn("FFmpeg output file was not finalized correctly: {}", outputFile);
            }
        } catch (IOException exception) {
            RecordableMod.LOGGER.warn("Failed to verify FFmpeg output file: {}", outputFile, exception);
        }

        tryMuxCapturedAudio();
        deleteTempAudioFileQuietly();
        return outputFile;
    }

    public int getQueueSize() {
        return queue.size();
    }

    public int getQueueCapacity() {
        return queueCapacity;
    }

    public double getQueueUsageRatio() {
        return queueCapacity <= 0 ? 0.0D : queue.size() / (double) queueCapacity;
    }

    public boolean isBacklogged() {
        return getQueueUsageRatio() >= 0.90D;
    }

    public long getDroppedFrames() {
        return droppedFrames.get();
    }

    public long getWrittenFrames() {
        return writtenFrames.get();
    }

    public double getEstimatedEncoderFps() {
        long started = writerStartedAtNanos.get();
        if (started <= 0L) {
            return 0.0D;
        }
        double elapsedSeconds = Math.max(0.001D, (System.nanoTime() - started) / 1_000_000_000.0D);
        return writtenFrames.get() / elapsedSeconds;
    }

    public Path getOutputFile() {
        return outputFile;
    }

    public String getCommandLine() {
        return commandLine;
    }

    /**
     * Returns the current output file size in bytes.
     *
     * <p>Inspired by OBS Studio's {@code total_bytes} tracking: we first check the
     * real-time size parsed from FFmpeg's stderr progress output (which is always
     * up-to-date even when the OS file system buffers haven't flushed). Falls back
     * to filesystem size if no progress has been parsed yet.</p>
     */
    public long getOutputFileSizeBytes() {
        long parsed = parsedSizeBytes;
        if (parsed > 0L) {
            return parsed;
        }
        if (outputFile == null) {
            return 0L;
        }
        try {
            return Files.exists(outputFile) ? Files.size(outputFile) : 0L;
        } catch (IOException exception) {
            return 0L;
        }
    }

    /** Returns real-time encoding FPS as reported by FFmpeg's progress output. */
    public double getParsedFps() {
        return parsedFps;
    }

    /** Returns real-time encoding bitrate (kbits/s) as reported by FFmpeg. */
    public double getParsedBitrate() {
        return parsedBitrate;
    }

    /** Returns FFmpeg's speed factor (e.g., "1.2x"). */
    public String getParsedSpeed() {
        return parsedSpeed;
    }

    private List<String> buildCommand(String executable, Path output) {
        ArrayList<String> args = new ArrayList<>();
        args.add(executable);
        args.add("-hide_banner");
        args.add("-loglevel");
        args.add("info");
        args.add("-stats");  // Ensure progress output to stderr (for real-time size tracking)
        args.add("-y");

        args.add("-f");
        args.add("rawvideo");
        args.add("-pix_fmt");
        args.add("rgb24");
        args.add("-video_size");
        args.add(width + "x" + height);
        args.add("-framerate");
        args.add(Integer.toString(fps));
        args.add("-i");
        args.add("pipe:0");

        args.add("-vsync");
        args.add("cfr");
        args.add("-r");
        args.add(Integer.toString(fps));

        RecordableConfig.VideoEncoder activeEncoder = resolveVideoEncoder();
        addVideoCodecArgs(args, activeEncoder);

        args.add("-an");

        if (config.maxFileSizeMB > 0) {
            args.add("-fs");
            args.add(Long.toString(config.maxFileSizeMB * 1024L * 1024L));
        }

        args.add(output.toAbsolutePath().toString());
        return args;
    }

    /**
     * Starts audio capture for the recording session.
     *
     * <p><b>Priority order:</b></p>
     * <ol>
     *   <li><b>OpenAL Loopback</b> (best): Intercepts Minecraft's audio engine directly
     *       via ALC_SOFT_loopback. Full-volume, zero-noise game audio.</li>
     *   <li><b>FFmpeg system capture</b> (fallback): DirectShow/PulseAudio loopback.</li>
     *   <li><b>OpenAL alcCapture</b> (last resort): Usually captures microphone.</li>
     * </ol>
     */
    private void startFfmpegAudioCapture(Path outputDirectory) {
        if (!config.captureAudio) {
            audioEnabled = false;
            audioDeviceInfo = "";
            return;
        }

        try {
            if (startLoopbackAudioCapture(outputDirectory)) {
                return;
            }

            RecordableMod.LOGGER.info("OpenAL loopback unavailable; trying system audio capture...");
            if (startFfmpegSystemAudioCapture(outputDirectory)) {
                return;
            }

            RecordableMod.LOGGER.info("System audio unavailable; trying OpenAL capture as last resort...");
            if (startOpenALAudioCapture(outputDirectory)) {
                return;
            }

            RecordableMod.LOGGER.warn("No audio capture method available. Recording video only.");
            audioEnabled = false;
            audioDeviceInfo = "No audio device found. Enable Stereo Mix or install a virtual audio device.";
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Audio initialization failed unexpectedly; continuing in video-only mode.", throwable);
            stopAudioCapture();
            audioEnabled = false;
            audioDeviceInfo = "Audio init failed; recording video only.";
        }
    }

    /**
     * PRIMARY audio capture: uses the OpenAL loopback device to capture
     * Minecraft's mixed audio output directly at full digital quality.
     *
     * <p>The loopback device is set up by {@link dev.recordable.mixin.SoundEngineMixin}
     * when the game starts. This method simply connects the loopback's PCM output
     * to a WAV file for recording.</p>
     *
     * @return true if loopback capture was activated successfully
     */
    private boolean startLoopbackAudioCapture(Path outputDirectory) {
        try {
            OpenALLoopbackCapture loopback = OpenALLoopbackCapture.getInstance();
            if (!loopback.isActive()) {
                RecordableMod.LOGGER.info("OpenAL loopback not active, skipping loopback capture.");
                return false;
            }

            tempAudioFile = outputDirectory.resolve("recordable-audio-" + FILE_TIMESTAMP.format(LocalDateTime.now()) + ".wav");

            java.io.FileOutputStream fos = new java.io.FileOutputStream(tempAudioFile.toFile());
            java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(fos, 131072);

            writeWavHeader(bos, OpenALLoopbackCapture.SAMPLE_RATE, OpenALLoopbackCapture.CHANNELS,
                    OpenALLoopbackCapture.BITS_PER_SAMPLE, 0);

            loopbackAudioStream = bos;
            loopbackFileStream = fos;

            // CRITICAL FIX: Do NOT connect the recording stream yet!
            // The stream will be connected in connectDeferredLoopbackAudio()
            // AFTER the video FFmpeg process is started and recordingStartNanos is set.
            // This prevents 150-300ms of audio from being captured before video starts.
            deferredLoopbackConnection = true;

            audioEnabled = true;
            audioDeviceInfo = "OpenAL Loopback (" + OpenALLoopbackCapture.SAMPLE_RATE + "Hz Stereo)";
            RecordableMod.LOGGER.info("OpenAL loopback audio capture PREPARED (deferred connection): {} -> {}", audioDeviceInfo, tempAudioFile);
            return true;
        } catch (Throwable t) {
            RecordableMod.LOGGER.warn("Failed to start loopback audio capture.", t);
            return false;
        }
    }

    /**
     * Starts OpenAL-based audio capture. Captures Minecraft's game audio directly
     * through LWJGL's OpenAL capture APIs and writes PCM data to a WAV file.
     *
     * @return true if OpenAL capture started successfully
     */
    private boolean startOpenALAudioCapture(Path outputDirectory) {
        try {
            int sampleRate = config.audioSampleRate > 0 ? config.audioSampleRate : 48000;
            int channels = config.audioChannelCount == 1 ? 1 : 2;

            openAlCapture = new OpenALAudioCapture(sampleRate, channels);
            if (!openAlCapture.start()) {
                RecordableMod.LOGGER.warn("OpenAL capture device could not be opened.");
                openAlCapture = null;
                return false;
            }

            tempAudioFile = outputDirectory.resolve("recordable-audio-" + FILE_TIMESTAMP.format(LocalDateTime.now()) + ".wav");

            audioWriterRunning = true;
            audioWriterThread = new Thread(() -> openAlAudioWriterLoop(sampleRate, channels), "Record-able OpenAL Audio Writer");
            audioWriterThread.setDaemon(true);
            audioWriterThread.start();

            audioEnabled = true;
            audioDeviceInfo = "OpenAL Game Audio (" + sampleRate + "Hz " + (channels == 2 ? "Stereo" : "Mono") + ")";
            RecordableMod.LOGGER.info("OpenAL audio capture started: {} -> {}", audioDeviceInfo, tempAudioFile);
            return true;
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Failed to start OpenAL audio capture.", throwable);
            if (openAlCapture != null) {
                try { openAlCapture.stop(); } catch (Throwable ignored) {}
                openAlCapture = null;
            }
            return false;
        }
    }

    /**
     * Background loop that reads audio frames from OpenAL and writes them to a WAV file.
     * The WAV header is written first with placeholder sizes, then updated at the end.
     */
    private void openAlAudioWriterLoop(int sampleRate, int channels) {
        int bitsPerSample = 16;
        long totalDataBytes = 0;

        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(tempAudioFile.toFile());
             java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(fos, 65536)) {

            writeWavHeader(bos, sampleRate, channels, bitsPerSample, 0);

            while (audioWriterRunning || (openAlCapture != null && openAlCapture.getQueueSize() > 0)) {
                byte[] audioFrame = null;
                if (openAlCapture != null) {
                    try {
                        audioFrame = openAlCapture.getNextAudioFrame(50);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }

                if (audioFrame != null && audioFrame.length > 0) {
                    bos.write(audioFrame);
                    totalDataBytes += audioFrame.length;
                }
            }

            bos.flush();

            try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(tempAudioFile.toFile(), "rw")) {
                updateWavHeaderSize(raf, totalDataBytes);
            }

            RecordableMod.LOGGER.info("OpenAL audio writer finished: {} bytes written to {}", totalDataBytes, tempAudioFile);
        } catch (IOException e) {
            RecordableMod.LOGGER.warn("Error writing OpenAL audio to WAV file.", e);
        }
    }

    /**
     * Writes a standard PCM WAV header.
     */
    private static void writeWavHeader(java.io.OutputStream out, int sampleRate, int channels, int bitsPerSample, long dataSize) throws IOException {
        int byteRate = sampleRate * channels * (bitsPerSample / 8);
        int blockAlign = channels * (bitsPerSample / 8);
        long chunkSize = 36 + dataSize;

        out.write("RIFF".getBytes(StandardCharsets.US_ASCII));
        writeLittleEndianInt(out, (int) chunkSize);
        out.write("WAVE".getBytes(StandardCharsets.US_ASCII));

        out.write("fmt ".getBytes(StandardCharsets.US_ASCII));
        writeLittleEndianInt(out, 16); // Sub-chunk size
        writeLittleEndianShort(out, (short) 1); // PCM format
        writeLittleEndianShort(out, (short) channels);
        writeLittleEndianInt(out, sampleRate);
        writeLittleEndianInt(out, byteRate);
        writeLittleEndianShort(out, (short) blockAlign);
        writeLittleEndianShort(out, (short) bitsPerSample);

        out.write("data".getBytes(StandardCharsets.US_ASCII));
        writeLittleEndianInt(out, (int) dataSize);
    }

    private static void writeLittleEndianInt(java.io.OutputStream out, int value) throws IOException {
        out.write(value & 0xFF);
        out.write((value >> 8) & 0xFF);
        out.write((value >> 16) & 0xFF);
        out.write((value >> 24) & 0xFF);
    }

    private static void writeLittleEndianShort(java.io.OutputStream out, short value) throws IOException {
        out.write(value & 0xFF);
        out.write((value >> 8) & 0xFF);
    }

    /**
     * Updates the WAV header with the actual data size after recording is complete.
     */
    private static void updateWavHeaderSize(java.io.RandomAccessFile raf, long dataSize) throws IOException {
        raf.seek(4);
        int chunkSize = (int) (36 + dataSize);
        raf.write(chunkSize & 0xFF);
        raf.write((chunkSize >> 8) & 0xFF);
        raf.write((chunkSize >> 16) & 0xFF);
        raf.write((chunkSize >> 24) & 0xFF);

        raf.seek(40);
        int dataSizeInt = (int) dataSize;
        raf.write(dataSizeInt & 0xFF);
        raf.write((dataSizeInt >> 8) & 0xFF);
        raf.write((dataSizeInt >> 16) & 0xFF);
        raf.write((dataSizeInt >> 24) & 0xFF);
    }

    /**
     * PRIMARY audio capture method (OBS-inspired approach).
     *
     * <p>Uses FFmpeg to capture system audio via DirectShow (Windows), PulseAudio (Linux),
     * or AVFoundation (macOS). This is the same fundamental approach OBS Studio uses:
     * capturing desktop/game audio through OS-level loopback devices like Stereo Mix,
     * PulseAudio monitor sources, or BlackHole.</p>
     *
     * @return true if system audio capture started successfully
     */
    private boolean startFfmpegSystemAudioCapture(Path outputDirectory) {
        try {
            AudioCapture.AudioDeviceStatus status = AudioCapture.detectAudioDevice(ffmpegExecutable, normalizeConfiguredAudioDevice(config.audioDevice));
            detectedAudioStatus = status;

            if (!status.available()) {
                RecordableMod.LOGGER.info("No system audio device available: {}.", status.message());
                audioDeviceInfo = status.message();
                return false;
            }

            tempAudioFile = outputDirectory.resolve("recordable-audio-" + FILE_TIMESTAMP.format(LocalDateTime.now()) + ".wav");

            List<String> cmd = new ArrayList<>();
            cmd.add(ffmpegExecutable);
            cmd.add("-hide_banner");
            cmd.add("-loglevel");
            cmd.add("warning");
            cmd.add("-y");
            cmd.addAll(status.ffmpegArgs());
            cmd.add("-af");
            cmd.add("volume=20.0,highpass=f=80,afftdn=nf=-25,dynaudnorm=f=150:g=15");
            cmd.add("-c:a");
            cmd.add("pcm_s16le");
            cmd.add("-ar");
            cmd.add(Integer.toString(config.audioSampleRate));
            cmd.add("-ac");
            cmd.add(Integer.toString(config.audioChannelCount));
            cmd.add(tempAudioFile.toAbsolutePath().toString());

            RecordableMod.LOGGER.info("Starting FFmpeg system audio capture (primary): {}", joinCommand(cmd));
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.directory(outputDirectory.toFile());

            class_310 client = class_310.method_1551();
            if (!RecordingManager.isInGameState(client)) {
                throw new IOException("Blocked FFmpeg audio start because client is not in-game.");
            }

            Process audioCaptureProcess = pb.start();
            this.ffmpegAudioProcess = audioCaptureProcess;

            Thread audioStderrThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(audioCaptureProcess.getErrorStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        RecordableMod.LOGGER.info("Audio FFmpeg: {}", line);
                    }
                } catch (IOException ignored) {}
            }, "Record-able Audio FFmpeg Log");
            audioStderrThread.setDaemon(true);
            audioStderrThread.start();
            this.ffmpegAudioStderrThread = audioStderrThread;

            audioEnabled = true;
            audioDeviceInfo = status.deviceName() + " (" + status.platform() + ")";
            RecordableMod.LOGGER.info("FFmpeg system audio capture started: device='{}' tempFile={}", status.deviceName(), tempAudioFile);
            return true;
        } catch (Exception exception) {
            RecordableMod.LOGGER.warn("Unable to start system audio capture.", exception);
            stopAudioCapture();
            audioEnabled = false;
            audioDeviceInfo = "Failed: " + exception.getMessage();
            return false;
        }
    }

    /**
     * Connects the deferred loopback audio recording stream.
     * Called after the video FFmpeg process is started and recordingStartNanos is set,
     * so that audio and video begin capturing at the same instant.
     */
    private void connectDeferredLoopbackAudio() {
        if (!deferredLoopbackConnection || loopbackAudioStream == null) {
            return;
        }
        try {
            OpenALLoopbackCapture loopback = OpenALLoopbackCapture.getInstance();
            if (loopback.isActive()) {
                audioRecordingStartNanos = System.nanoTime();
                loopback.setRecordingStream(loopbackAudioStream);
                deferredLoopbackConnection = false;
                long gapMs = (audioRecordingStartNanos - recordingStartNanos) / 1_000_000L;
                RecordableMod.LOGGER.info("Loopback audio stream connected ({}ms after video start). Audio and video are now synchronized.", gapMs);
            } else {
                RecordableMod.LOGGER.warn("Loopback became inactive before audio stream could be connected.");
                deferredLoopbackConnection = false;
            }
        } catch (Throwable t) {
            RecordableMod.LOGGER.warn("Failed to connect deferred loopback audio stream.", t);
            deferredLoopbackConnection = false;
        }
    }

    /**
     * Stops all audio capture (loopback, OpenAL, and/or FFmpeg).
     */
    private void stopAudioCapture() {
        try {
            OpenALLoopbackCapture loopback = OpenALLoopbackCapture.getInstance();
            loopback.setRecordingStream(null);
        } catch (Throwable ignored) {}

        if (loopbackAudioStream != null) {
            try {
                loopbackAudioStream.flush();
                loopbackAudioStream.close();
            } catch (Throwable ignored) {}
            loopbackAudioStream = null;
        }
        if (loopbackFileStream != null) {
            try {
                long fileSize = Files.size(tempAudioFile);
                long dataSize = fileSize - 44; // WAV header is 44 bytes
                if (dataSize > 0) {
                    try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(tempAudioFile.toFile(), "rw")) {
                        updateWavHeaderSize(raf, dataSize);
                    }
                }
                loopbackFileStream.close();
            } catch (Throwable ignored) {}
            loopbackFileStream = null;
        }

        audioWriterRunning = false;
        if (openAlCapture != null) {
            try {
                openAlCapture.stop();
            } catch (Throwable ignored) {}
            openAlCapture = null;
        }

        if (audioWriterThread != null) {
            try {
                audioWriterThread.join(5_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
            audioWriterThread = null;
        }

        if (ffmpegAudioProcess != null) {
            try {
                OutputStream audioStdin = ffmpegAudioProcess.getOutputStream();
                if (audioStdin != null) {
                    try {
                        audioStdin.write('q');
                        audioStdin.flush();
                        audioStdin.close();
                    } catch (IOException ignored) {}
                }

                if (!ffmpegAudioProcess.waitFor(8, TimeUnit.SECONDS)) {
                    RecordableMod.LOGGER.warn("Audio capture FFmpeg did not exit after 'q'; destroying.");
                    ffmpegAudioProcess.destroy();
                    if (!ffmpegAudioProcess.waitFor(3, TimeUnit.SECONDS)) {
                        ffmpegAudioProcess.destroyForcibly();
                    }
                }

                int exitCode = ffmpegAudioProcess.exitValue();
                if (exitCode != 0 && exitCode != 255) {
                    RecordableMod.LOGGER.warn("Audio capture FFmpeg exited with code {}", exitCode);
                }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                ffmpegAudioProcess.destroyForcibly();
            } finally {
                ffmpegAudioProcess = null;
            }
        }

        if (ffmpegAudioStderrThread != null) {
            try {
                ffmpegAudioStderrThread.join(2_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
            ffmpegAudioStderrThread = null;
        }
    }

    /**
     * Muxes the captured audio WAV file with the video-only MP4 file into the final output.
     * After muxing, probes audio levels to warn the user if the audio appears silent.
     */
    private void tryMuxCapturedAudio() {
        if (!audioEnabled || tempAudioFile == null || outputFile == null) {
            return;
        }

        try {
            if (!Files.exists(tempAudioFile) || Files.size(tempAudioFile) <= 44L) {
                RecordableMod.LOGGER.warn("Audio capture produced no data (size={}). Keeping video-only output.",
                        Files.exists(tempAudioFile) ? Files.size(tempAudioFile) : 0);
                return;
            }

            long wavSize = Files.size(tempAudioFile);
            RecordableMod.LOGGER.info("Audio WAV file: {} ({} bytes)", tempAudioFile.getFileName(), wavSize);

            String outputName = outputFile.getFileName().toString();
            int dotIndex = outputName.lastIndexOf('.');
            String baseName = dotIndex > 0 ? outputName.substring(0, dotIndex) : outputName;
            String ext = dotIndex > 0 ? outputName.substring(dotIndex) : ".mp4";
            Path muxedOutput = outputFile.resolveSibling(baseName + "-muxed" + ext);
            List<String> muxCommand = new ArrayList<>();
            muxCommand.add(ffmpegExecutable);
            muxCommand.add("-nostdin");
            muxCommand.add("-hide_banner");
            muxCommand.add("-loglevel");
            muxCommand.add("info");
            muxCommand.add("-y");
            muxCommand.add("-i");
            muxCommand.add(outputFile.toAbsolutePath().toString());
            // FIX: Compute the actual audio-video start time gap from deferred connection.
            // The audio stream was connected slightly after recordingStartNanos.
            // A positive itsoffset on the audio input DELAYS the audio stream.
            // A negative itsoffset on the audio input ADVANCES the audio stream.
            int userOffsetMs = RecordableConfig.get().getEffectiveAudioDelay();
            long startGapMs = 0;
            if (audioRecordingStartNanos > 0 && recordingStartNanos > 0) {
                startGapMs = (audioRecordingStartNanos - recordingStartNanos) / 1_000_000L;
                RecordableMod.LOGGER.info("Audio-video start gap: {}ms (audio started after video)", startGapMs);
            }
            // Compensate: if audio started late, we need to shift it earlier (negative offset)
            // The user offset is intended to add extra delay if needed
            int totalOffsetMs = userOffsetMs - (int) startGapMs;
            double offsetSec = totalOffsetMs / 1000.0;
            RecordableMod.LOGGER.info("Audio itsoffset: {}ms (user={}ms, startGap={}ms)", totalOffsetMs, userOffsetMs, startGapMs);
            muxCommand.add("-itsoffset");
            muxCommand.add(String.format(java.util.Locale.ROOT, "%.3f", offsetSec));
            muxCommand.add("-i");
            muxCommand.add(tempAudioFile.toAbsolutePath().toString());
            muxCommand.add("-map");
            muxCommand.add("0:v:0");
            muxCommand.add("-map");
            muxCommand.add("1:a:0");
            muxCommand.add("-c:v");
            muxCommand.add("copy");
            addAudioCodecArgs(muxCommand);

            StringBuilder audioFilter = new StringBuilder();
            if (config.audioVolume != 100 && config.audioVolume >= 0 && config.audioVolume <= 200) {
                double volumeFactor = config.audioVolume / 100.0;
                audioFilter.append("volume=").append(String.format(Locale.ROOT, "%.2f", volumeFactor));
                RecordableMod.LOGGER.info("Applying user audio volume: {}x ({}%)", volumeFactor, config.audioVolume);
            }

            if (config.audioVolumeBoostDb > 0 && config.audioVolumeBoostDb <= 24) {
                if (!audioFilter.isEmpty()) {
                    audioFilter.append(",");
                }
                audioFilter.append("volume=").append(config.audioVolumeBoostDb).append("dB");
                RecordableMod.LOGGER.info("Applying audio boost: +{} dB", config.audioVolumeBoostDb);
            }

            // FIX: Removed first_pts=0 which forcefully reset audio start position
            // and could mask timing issues. Use async=1000 (sample tolerance) only
            // for non-loopback audio. Loopback audio is already clean PCM.
            if (deferredLoopbackConnection || audioRecordingStartNanos > 0) {
                // Loopback audio: already clean, just apply volume if needed
                if (!audioFilter.isEmpty()) {
                    muxCommand.add("-af");
                    muxCommand.add(audioFilter.toString());
                }
            } else {
                // Non-loopback (system capture): use gentle async resampling
                if (!audioFilter.isEmpty()) {
                    audioFilter.append(",");
                }
                audioFilter.append("aresample=async=1000");
                muxCommand.add("-af");
                muxCommand.add(audioFilter.toString());
            }
            muxCommand.add("-shortest");
            muxCommand.add(muxedOutput.toAbsolutePath().toString());

            RecordableMod.LOGGER.info("Muxing audio: {}", joinCommand(muxCommand));
            Process muxProcess = new ProcessBuilder(muxCommand).redirectErrorStream(true).start();
            String muxOutput;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(muxProcess.getInputStream(), StandardCharsets.UTF_8))) {
                muxOutput = reader.lines().collect(Collectors.joining("\n"));
            }

            if (!muxProcess.waitFor(30, TimeUnit.SECONDS)) {
                muxProcess.destroyForcibly();
                RecordableMod.LOGGER.warn("Audio mux timed out. Keeping original video-only file.");
                return;
            }

            if (muxProcess.exitValue() != 0) {
                RecordableMod.LOGGER.warn("Audio mux failed with exit code {}: {}", muxProcess.exitValue(), muxOutput);
                return;
            }

            try {
                Files.move(muxedOutput, outputFile,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(muxedOutput, outputFile, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            RecordableMod.LOGGER.info("Audio mux completed successfully: {}", outputFile);

            probeAudioLevel();
        } catch (Exception exception) {
            RecordableMod.LOGGER.warn("Failed to mux audio into output.", exception);
        }
    }

    /**
     * Runs a quick FFmpeg volumedetect on the final output to check if audio is essentially silent.
     * Logs a diagnostic warning if mean volume is below -80 dB.
     */
    private void probeAudioLevel() {
        if (outputFile == null) return;
        try {
            List<String> cmd = List.of(
                    ffmpegExecutable, "-nostdin", "-hide_banner",
                    "-i", outputFile.toAbsolutePath().toString(),
                    "-map", "0:a:0", "-af", "volumedetect",
                    "-vn", "-f", "null", "-"
            );
            Process probe = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            String output;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(probe.getInputStream(), StandardCharsets.UTF_8))) {
                output = reader.lines().collect(Collectors.joining("\n"));
            }
            if (probe.waitFor(10, TimeUnit.SECONDS)) {
                for (String line : output.split("\n")) {
                    if (line.contains("mean_volume")) {
                        RecordableMod.LOGGER.info("Audio level check: {}", line.trim());
                        try {
                            String[] parts = line.split("mean_volume:\\s*");
                            if (parts.length > 1) {
                                double meanDb = Double.parseDouble(parts[1].trim().split("\\s+")[0]);
                                if (meanDb < -70.0) {
                                    RecordableMod.LOGGER.warn(
                                            "⚠ Audio appears silent or near-silent (mean={} dB). " +
                                            "Check Stereo Mix volume in Windows Sound Settings > Recording > Properties > Levels. " +
                                            "Set Stereo Mix level to 100%.", meanDb);
                                }
                            }
                        } catch (NumberFormatException ignored) {}
                    }
                    if (line.contains("max_volume")) {
                        RecordableMod.LOGGER.info("Audio level check: {}", line.trim());
                    }
                }
            } else {
                probe.destroyForcibly();
            }
        } catch (Exception e) {
            RecordableMod.LOGGER.debug("Audio level probe failed (non-critical).", e);
        }
    }

    private void deleteTempAudioFileQuietly() {
        if (tempAudioFile == null) {
            return;
        }
        try {
            Files.deleteIfExists(tempAudioFile);
        } catch (IOException ignored) {
        }
        tempAudioFile = null;
    }

    /** Returns the last detected audio device status, or null if not yet probed. */
    public AudioCapture.AudioDeviceStatus getDetectedAudioStatus() {
        return detectedAudioStatus;
    }

    private static String normalizeConfiguredAudioDevice(String configuredDevice) {
        if (configuredDevice == null) {
            return "auto";
        }
        String normalized = configuredDevice.trim();
        if (normalized.isEmpty() || "openal".equalsIgnoreCase(normalized)) {
            return "auto";
        }
        return normalized;
    }

    private RecordableConfig.VideoEncoder resolveVideoEncoder() {
        RecordableConfig.VideoEncoder requested = config.encoder == null
                ? RecordableConfig.VideoEncoder.SOFTWARE
                : config.encoder;

        if (requested == RecordableConfig.VideoEncoder.SOFTWARE) {
            return requested;
        }

        List<RecordableConfig.VideoEncoder> available = detectAvailableEncoders();
        if (available.contains(requested)) {
            return requested;
        }

        RecordableMod.LOGGER.warn("Requested encoder {} is not available in this FFmpeg build. Falling back to software x264.",
                requested.displayName);
        return RecordableConfig.VideoEncoder.SOFTWARE;
    }

    public static List<RecordableConfig.VideoEncoder> detectAvailableEncoders() {
        List<RecordableConfig.VideoEncoder> available = new ArrayList<>();
        available.add(RecordableConfig.VideoEncoder.SOFTWARE);

        if (testEncoder("h264_nvenc")) {
            available.add(RecordableConfig.VideoEncoder.NVIDIA);
        }
        if (testEncoder("h264_amf")) {
            available.add(RecordableConfig.VideoEncoder.AMD);
        }
        if (testEncoder("h264_qsv")) {
            available.add(RecordableConfig.VideoEncoder.INTEL);
        }

        return available;
    }

    public static List<RecordableConfig.AudioEncoder> detectAvailableAudioEncoders() {
        List<RecordableConfig.AudioEncoder> available = new ArrayList<>();
        for (RecordableConfig.AudioEncoder encoder : RecordableConfig.AudioEncoder.values()) {
            if (testAudioEncoder(encoder.ffmpegCodec)) {
                available.add(encoder);
            }
        }
        if (available.isEmpty()) {
            available.add(RecordableConfig.AudioEncoder.AAC);
        }
        return available;
    }

    private static boolean testAudioEncoder(String codec) {
        return testEncoder(codec);
    }

    private static boolean testEncoder(String codec) {
        FfmpegStatus status = detectFfmpeg();
        if (!status.found()) {
            return false;
        }

        Set<String> encoders = new HashSet<>();
        Process process = null;
        try {
            process = new ProcessBuilder(status.executable(), "-hide_banner", "-encoders")
                    .redirectErrorStream(true)
                    .start();

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String lowered = line.toLowerCase(Locale.ROOT).trim();
                    if (lowered.isEmpty()) {
                        continue;
                    }

                    String[] parts = lowered.split("\\s+");
                    if (parts.length >= 2 && parts[0].length() == 6) {
                        encoders.add(parts[1]);
                    }
                }
            }

            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return false;
            }
            return encoders.contains(codec.toLowerCase(Locale.ROOT));
        } catch (Exception exception) {
            RecordableMod.LOGGER.debug("Failed to probe encoder {}", codec, exception);
            return false;
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
    }

    private void addVideoCodecArgs(List<String> args, RecordableConfig.VideoEncoder selectedEncoder) {
        String format = config.getFormat();
        String bitrate = config.resolveBitrate(width, height);
        {
                RecordableConfig.VideoEncoder encoderToUse = selectedEncoder == null
                        ? RecordableConfig.VideoEncoder.SOFTWARE
                        : selectedEncoder;
                args.add("-c:v");
                args.add(encoderToUse.ffmpegCodec);

                switch (encoderToUse) {
                    case NVIDIA -> {
                        args.add("-preset");
                        args.add("p1");
                        args.add("-tune");
                        args.add("ull");
                        args.add("-rc");
                        args.add("vbr");
                        args.add("-cq");
                        args.add(Integer.toString(config.getX264Crf()));
                        args.add("-b:v");
                        args.add(bitrate);
                    }
                    case AMD -> {
                        args.add("-quality");
                        args.add("speed");
                        args.add("-rc");
                        args.add("vbr_latency");
                        args.add("-qp_i");
                        args.add(Integer.toString(config.getX264Crf()));
                        args.add("-qp_p");
                        args.add(Integer.toString(config.getX264Crf()));
                        args.add("-b:v");
                        args.add(bitrate);
                    }
                    case INTEL -> {
                        args.add("-preset");
                        args.add("veryfast");
                        args.add("-global_quality");
                        args.add(Integer.toString(config.getX264Crf()));
                        args.add("-b:v");
                        args.add(bitrate);
                    }
                    case SOFTWARE -> {
                        args.add("-preset");
                        args.add(config.getX264Preset());
                        args.add("-tune");
                        args.add("zerolatency");
                        args.add("-crf");
                        args.add(Integer.toString(config.getX264Crf()));
                        args.add("-b:v");
                        args.add(bitrate);
                    }
                }

                args.add("-pix_fmt");
                args.add("yuv420p");
                args.add("-movflags");
                args.add("+faststart");
        }
    }

    /**
     * Adds audio codec arguments based on selected encoder and container support.
     * Must be called only when audio input has been added to the command.
     */
    private void addAudioCodecArgs(List<String> args) {
        config.validateAudioEncoderCompatibility();
        RecordableConfig.AudioEncoder selected = config.audioEncoder == null
                ? RecordableConfig.AudioEncoder.AAC
                : config.audioEncoder;

        args.add("-c:a");
        args.add(selected.ffmpegCodec);

        args.add("-ar");
        args.add(Integer.toString(config.audioSampleRate));

        args.add("-ac");
        args.add(Integer.toString(config.audioChannelCount));

        if (!selected.isLossless()) {
            args.add("-b:a");
            args.add(config.audioBitrateKbps + "k");
        }

        switch (selected) {
            case OPUS -> {
                args.add("-compression_level");
                args.add("10");
            }
            case MP3 -> {
                args.add("-q:a");
                args.add("2");
            }
            case FLAC -> {
                args.add("-compression_level");
                args.add("8");
            }
            default -> {
            }
        }
    }

    /** Returns whether audio was successfully added to the FFmpeg command. */
    public boolean isAudioEnabled() {
        return audioEnabled;
    }

    /** Returns the name of the audio device being used, or empty if none. */
    public String getAudioDeviceInfo() {
        return audioDeviceInfo;
    }

    /**
     * Writer loop that drains the frame queue into FFmpeg's stdin pipe.
     *
     * <p><b>Frame duplication for correct timing:</b> Each frame carries a wall-clock
     * timestamp (ms since recording started). The writer tracks how many frames FFmpeg
     * has received and how many <em>should</em> have been received based on the timestamp.
     * When dropped frames cause a gap, the current frame data is written multiple times
     * to fill the gap. This keeps the recorded video duration in sync with real time,
     * preventing the "speed-shifting" artefact that occurs when frames are simply lost.</p>
     *
     * <p>Cap: at most 10 duplicate frames per packet to avoid runaway bursts if
     * a single packet has a very large timestamp gap (e.g. game freeze or pause).</p>
     */
    private void writerLoop() {
        int flushCounter = 0;
        long framesWrittenSinceLog = 0L;
        long duplicatedSinceLog = 0L;
        long totalDuplicated = 0L;
        long logWindowStarted = System.nanoTime();
        // FIX: Use microsecond precision to avoid integer division drift.
        // At 60 FPS, 1000/60 = 16 (integer) but actual interval is 16.667ms.
        // Over 60 frames this causes ~40ms/min drift. Using microseconds fixes it.
        final long frameIntervalUs = Math.max(1L, 1_000_000L / Math.max(1, fps));
        final int MAX_DUP_PER_PACKET = 10;

        try {
            while (acceptingFrames.get() || !queue.isEmpty()) {
                if (process != null && !process.isAlive()) {
                    int exitCode = process.exitValue();
                    RecordableMod.LOGGER.error(
                            "FFmpeg process died unexpectedly (exit code {}). Stopping writer. Last FFmpeg error: {}",
                            exitCode, lastError);
                    acceptingFrames.set(false);
                    break;
                }

                FramePacket packet = queue.poll(100L, TimeUnit.MILLISECONDS);
                if (packet == null) {
                    continue;
                }

                long currentWritten = writtenFrames.get();
                long ts = packet.timestampMs();
                int framesToWrite = 1;

                if (ts > 0) {
                    // FIX: Use microsecond math to prevent accumulating drift
                    long tsUs = ts * 1000L;
                    long expectedFrameIndex = tsUs / frameIntervalUs;
                    long gap = expectedFrameIndex - currentWritten;
                    if (gap > 1) {
                        int duplicates = (int) Math.min(gap - 1, MAX_DUP_PER_PACKET);
                        framesToWrite += duplicates;
                        totalDuplicated += duplicates;
                        duplicatedSinceLog += duplicates;
                    }
                }

                for (int i = 0; i < framesToWrite; i++) {
                    ffmpegStdin.write(packet.data());
                    writtenFrames.incrementAndGet();
                    framesWrittenSinceLog++;
                    flushCounter++;
                }

                long now = System.nanoTime();
                if (now - logWindowStarted >= 1_000_000_000L) {
                    RecordableMod.LOGGER.info("Encoder: {} fps | Queue: {}/{} | Written: {} | Dup: {} (total {})",
                            framesWrittenSinceLog,
                            queue.size(),
                            queueCapacity,
                            writtenFrames.get(),
                            duplicatedSinceLog,
                            totalDuplicated);
                    framesWrittenSinceLog = 0L;
                    duplicatedSinceLog = 0L;
                    logWindowStarted = now;
                }

                if (flushCounter >= 2) {
                    ffmpegStdin.flush();
                    flushCounter = 0;
                }
            }
            ffmpegStdin.flush();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        } catch (IOException exception) {
            lastError = exception.getMessage() == null ? exception.toString() : exception.getMessage();
            boolean processDead = process != null && !process.isAlive();
            if (processDead) {
                RecordableMod.LOGGER.error(
                        "Write to FFmpeg stdin failed because the process exited (code {}). Last FFmpeg message: {}",
                        process.exitValue(), lastError);
            } else {
                RecordableMod.LOGGER.warn("Failed while writing raw video to FFmpeg.", exception);
            }
            acceptingFrames.set(false);
        } finally {
            closeStdinQuietly();
            RecordableMod.LOGGER.info("Writer loop finished. Total frames written: {} (duplicated: {})",
                    writtenFrames.get(), totalDuplicated);
        }
    }

    /**
     * Reads FFmpeg stderr, parsing progress lines for real-time stats.
     *
     * <p>FFmpeg outputs progress lines like:
     * {@code frame= 1234 fps= 60 q=23.0 size=   12345KiB time=00:00:20.56 bitrate=4914.2kbits/s speed=1.02x}
     * These use {@code \r} (carriage return) to overwrite the same line. We handle both
     * {@code \r} and {@code \n} as line terminators to capture each progress update.</p>
     *
     * <p>This is inspired by OBS Studio's approach of tracking {@code total_bytes} in
     * real-time from the encoding pipeline.</p>
     */
    private void stderrLoop(InputStream errorStream) {
        try (BufferedInputStream inputStream = new BufferedInputStream(errorStream)) {
            StringBuilder currentLine = new StringBuilder();
            int value;
            while ((value = inputStream.read()) != -1) {
                if (value == '\n' || value == '\r') {
                    String line = currentLine.toString();
                    if (!line.isBlank()) {
                        parseAndLogFfmpegLine(line);
                    }
                    currentLine.setLength(0);
                } else {
                    currentLine.append((char) value);
                }
            }
            if (!currentLine.isEmpty()) {
                parseAndLogFfmpegLine(currentLine.toString());
            }
        } catch (IOException exception) {
            if (acceptingFrames.get()) {
                RecordableMod.LOGGER.debug("FFmpeg stderr reader ended.", exception);
            }
        }
    }

    private static final java.util.regex.Pattern SIZE_PATTERN = java.util.regex.Pattern.compile("size=\\s*(\\d+)\\s*([kKmMgG]i?[bB]?)");
    private static final java.util.regex.Pattern FRAME_PATTERN = java.util.regex.Pattern.compile("frame=\\s*(\\d+)");
    private static final java.util.regex.Pattern FPS_PATTERN = java.util.regex.Pattern.compile("fps=\\s*([\\d.]+)");
    private static final java.util.regex.Pattern BITRATE_PATTERN = java.util.regex.Pattern.compile("bitrate=\\s*([\\d.]+)\\s*([kKmMgG]?)bits/s");
    private static final java.util.regex.Pattern SPEED_PATTERN = java.util.regex.Pattern.compile("speed=\\s*([\\d.]+x)");

    /**
     * Parses an FFmpeg stderr line, extracting progress stats if it's a progress line,
     * or logging it as a warning/error otherwise.
     */
    private void parseAndLogFfmpegLine(String line) {
        if (line == null || line.isBlank()) {
            return;
        }

        boolean isProgressLine = line.contains("frame=") && line.contains("size=");

        if (isProgressLine) {
            java.util.regex.Matcher sizeMatcher = SIZE_PATTERN.matcher(line);
            if (sizeMatcher.find()) {
                try {
                    long sizeValue = Long.parseLong(sizeMatcher.group(1));
                    String unit = sizeMatcher.group(2).toLowerCase(Locale.ROOT);
                    if (unit.startsWith("k")) {
                        parsedSizeBytes = sizeValue * 1024L;
                    } else if (unit.startsWith("m")) {
                        parsedSizeBytes = sizeValue * 1024L * 1024L;
                    } else if (unit.startsWith("g")) {
                        parsedSizeBytes = sizeValue * 1024L * 1024L * 1024L;
                    } else {
                        parsedSizeBytes = sizeValue;
                    }
                } catch (NumberFormatException ignored) {}
            }

            java.util.regex.Matcher frameMatcher = FRAME_PATTERN.matcher(line);
            if (frameMatcher.find()) {
                try {
                    parsedFrameCount = Long.parseLong(frameMatcher.group(1));
                } catch (NumberFormatException ignored) {}
            }

            java.util.regex.Matcher fpsMatcher = FPS_PATTERN.matcher(line);
            if (fpsMatcher.find()) {
                try {
                    parsedFps = Double.parseDouble(fpsMatcher.group(1));
                } catch (NumberFormatException ignored) {}
            }

            java.util.regex.Matcher bitrateMatcher = BITRATE_PATTERN.matcher(line);
            if (bitrateMatcher.find()) {
                try {
                    double br = Double.parseDouble(bitrateMatcher.group(1));
                    String brUnit = bitrateMatcher.group(2).toLowerCase(Locale.ROOT);
                    if (brUnit.startsWith("m")) {
                        parsedBitrate = br * 1000.0;
                    } else {
                        parsedBitrate = br; // kbits/s
                    }
                } catch (NumberFormatException ignored) {}
            }

            java.util.regex.Matcher speedMatcher = SPEED_PATTERN.matcher(line);
            if (speedMatcher.find()) {
                parsedSpeed = speedMatcher.group(1);
            }

            if (parsedFrameCount > 0 && parsedFrameCount % 300 == 0) {
                RecordableMod.LOGGER.info("FFmpeg progress: frame={} size={} fps={} bitrate={}kbits/s speed={}",
                        parsedFrameCount,
                        RecordingManager.formatBytes(parsedSizeBytes),
                        String.format(Locale.ROOT, "%.1f", parsedFps),
                        String.format(Locale.ROOT, "%.1f", parsedBitrate),
                        parsedSpeed);
            }
        } else {
            lastError = line;
            RecordableMod.LOGGER.warn("FFmpeg: {}", line);
        }
    }

    private void closeStdinQuietly() {
        if (ffmpegStdin != null) {
            try {
                ffmpegStdin.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void closeProcessStreamsQuietly() {
        if (process == null) {
            return;
        }
        try {
            process.getInputStream().close();
        } catch (IOException ignored) {
        }
        try {
            process.getErrorStream().close();
        } catch (IOException ignored) {
        }
    }

    /**
     * Detects FFmpeg using a priority-based fallback chain:
     * <ol>
     *   <li>User-configured path ({@code RECORDABLE_FFMPEG_PATH} env var)</li>
     *   <li>Bundled FFmpeg (managed by {@link FfmpegBundleManager})</li>
     *   <li>System {@code PATH}</li>
     * </ol>
     *
     * @return status describing which FFmpeg was found (or not)
     */
    public static FfmpegStatus detectFfmpeg() {
        long now = System.currentTimeMillis();
        FfmpegStatus cached = cachedStatus;
        if (cached != null && now - cachedStatusAtMs < 5_000L) {
            return cached;
        }

        String configured = System.getenv("RECORDABLE_FFMPEG_PATH");
        if (configured != null && !configured.isBlank()) {
            FfmpegStatus userStatus = probeFfmpeg(configured.trim());
            if (userStatus.found()) {
                RecordableMod.LOGGER.info("[FFmpeg] Using user-configured FFmpeg: {}", userStatus.executable());
                cachedStatus = userStatus;
                cachedStatusAtMs = now;
                return userStatus;
            }
            RecordableMod.LOGGER.warn("[FFmpeg] User-configured path '{}' not working: {}. Trying bundled/system.",
                    configured.trim(), userStatus.error());
        }

        RecordableConfig config = null;
        try {
            config = RecordableConfig.get();
        } catch (Exception e) {
        }
        boolean useBundled = config == null || config.useBundledFfmpeg;

        if (useBundled) {
            String bundledPath = FfmpegBundleManager.getBundledFfmpegPath();
            if (bundledPath != null) {
                FfmpegStatus bundledStatus = probeFfmpeg(bundledPath);
                if (bundledStatus.found()) {
                    RecordableMod.LOGGER.info("[FFmpeg] Using bundled FFmpeg: {}", bundledStatus.executable());
                    cachedStatus = bundledStatus;
                    cachedStatusAtMs = now;
                    return bundledStatus;
                }
                RecordableMod.LOGGER.warn("[FFmpeg] Bundled FFmpeg at '{}' not working: {}. Trying system PATH.",
                        bundledPath, bundledStatus.error());
            }
        }

        FfmpegStatus systemStatus = probeFfmpeg("ffmpeg");
        if (systemStatus.found()) {
            RecordableMod.LOGGER.info("[FFmpeg] Using system PATH FFmpeg: {}", systemStatus.version());
        } else {
            RecordableMod.LOGGER.warn("[FFmpeg] No FFmpeg found via any method (user config, bundled, system PATH).");
        }
        cachedStatus = systemStatus;
        cachedStatusAtMs = now;
        return systemStatus;
    }

    private static FfmpegStatus probeFfmpeg(String executable) {
        try {
            Process process = new ProcessBuilder(executable, "-version")
                    .redirectErrorStream(true)
                    .start();
            boolean exited = process.waitFor(3, TimeUnit.SECONDS);
            if (!exited) {
                process.destroyForcibly();
                return FfmpegStatus.notFound(executable, "Timed out while probing FFmpeg.");
            }

            String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            String firstLine = output.lines().findFirst().orElse("ffmpeg version unknown");
            if (process.exitValue() == 0) {
                return new FfmpegStatus(true, executable, firstLine, "");
            }
            return FfmpegStatus.notFound(executable, firstLine.isBlank() ? "FFmpeg probe failed." : firstLine);
        } catch (Exception exception) {
            String message = exception.getMessage() == null ? exception.toString() : exception.getMessage();
            return FfmpegStatus.notFound(executable, "FFmpeg not found: " + message);
        }
    }

    private static String joinCommand(List<String> command) {
        StringJoiner joiner = new StringJoiner(" ");
        for (String part : command) {
            if (part.indexOf(' ') >= 0) {
                joiner.add('"' + part.replace("\"", "\\\"") + '"');
            } else {
                joiner.add(part);
            }
        }
        return joiner.toString();
    }

    private record FramePacket(byte[] data, long timestampMs) {
    }

    public record FfmpegStatus(boolean found, String executable, String version, String error) {
        private static FfmpegStatus notFound(String executable, String error) {
            return new FfmpegStatus(false, executable, "", error == null ? "" : error);
        }

        public String displayText() {
            return found ? "Found: " + version : "Not found: " + error;
        }
    }
}
