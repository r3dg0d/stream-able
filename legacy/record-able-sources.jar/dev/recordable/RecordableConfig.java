package dev.recordable;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Persistent JSON configuration for Record-able.
 *
 * <p>The file is stored at {@code config/recordable.json}. Public fields keep
 * the JSON concise and user-editable, while helper methods sanitize values and
 * translate friendly options into encoder/capture settings.</p>
 */
public final class RecordableConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FILE_NAME = "recordable.json";
    private static final Pattern HEX_COLOR_PATTERN = Pattern.compile("^#[0-9a-fA-F]{6}$");

    public static final String[] FORMATS = {"mp4", "mkv"};
    public static final int[] FPS_VALUES = {30, 60, 120};
    public static final String[] RESOLUTIONS = {"native", "1080p", "720p", "480p"};
    public static final String[] QUALITIES = {"high", "balanced", "performance"};
    public static final String[] AUTO_RECORD_TRIGGERS = {"world_join", "game_start", "manual"};
    public static final String[] AUTO_STOP_TRIGGERS = {"world_leave", "game_quit", "never"};
    public static final String[] AUDIO_CHANNELS = {"auto", "mono", "stereo"};
    public static final int[] AUDIO_SAMPLE_RATES = {44100, 48000};

    public enum VideoEncoder {
        SOFTWARE("Software (x264)", "libx264"),
        NVIDIA("NVIDIA NVENC", "h264_nvenc"),
        AMD("AMD AMF", "h264_amf"),
        INTEL("Intel QuickSync", "h264_qsv");

        public final String displayName;
        public final String ffmpegCodec;

        VideoEncoder(String displayName, String ffmpegCodec) {
            this.displayName = displayName;
            this.ffmpegCodec = ffmpegCodec;
        }
    }

    /**
     * Presets for audio sync delay compensation.
     * With deferred audio start and dynamic gap measurement, the default (Auto)
     * is now 0ms because FFmpeg already handles AAC priming internally.
     * Manual presets remain for edge cases (unusual audio drivers, hardware quirks).
     */
    public enum AudioDelayPreset {
        AUTO("Auto", -1),
        NONE("None", 0),
        DESKTOP("Desktop", 46),
        ANDROID("Android", 60),
        CUSTOM("Custom", -2);

        public final String displayName;
        /** Sentinel: -1 = auto-detect by platform, -2 = use custom value from config. */
        public final int defaultMs;

        AudioDelayPreset(String displayName, int defaultMs) {
            this.displayName = displayName;
            this.defaultMs = defaultMs;
        }

        /** Cycle to the next preset in order. */
        public AudioDelayPreset next() {
            AudioDelayPreset[] values = values();
            return values[(this.ordinal() + 1) % values.length];
        }
    }

    /**
     * Preset positions for the recording overlay on the HUD.
     * Each position anchors the overlay panel to a corner or center of the screen,
     * with safe margins to avoid vanilla HUD elements.
     */
    public enum OverlayPosition {
        TOP_LEFT("Top-Left"),
        TOP_RIGHT("Top-Right"),
        BOTTOM_LEFT("Bottom-Left"),
        BOTTOM_RIGHT("Bottom-Right"),
        CENTER_TOP("Center-Top");

        public final String displayName;

        OverlayPosition(String displayName) {
            this.displayName = displayName;
        }

        /** Cycle to the next position preset. */
        public OverlayPosition next() {
            OverlayPosition[] values = values();
            return values[(this.ordinal() + 1) % values.length];
        }
    }

    public enum AudioEncoder {
        AAC("AAC", "aac", new String[]{"mp4", "mkv", "avi", "webm"}, 192),
        OPUS("Opus", "libopus", new String[]{"webm", "mkv"}, 128),
        MP3("MP3", "libmp3lame", new String[]{"mp4", "mkv", "avi", "webm"}, 192),
        FLAC("FLAC (Lossless)", "flac", new String[]{"mkv", "avi", "mp4", "webm"}, 0);

        public final String displayName;
        public final String ffmpegCodec;
        public final String[] supportedContainers;
        public final int defaultBitrateKbps;

        AudioEncoder(String displayName, String ffmpegCodec, String[] supportedContainers, int defaultBitrateKbps) {
            this.displayName = displayName;
            this.ffmpegCodec = ffmpegCodec;
            this.supportedContainers = supportedContainers;
            this.defaultBitrateKbps = defaultBitrateKbps;
        }

        public boolean supportsContainer(String container) {
            if (container == null || container.isBlank()) {
                return false;
            }
            String normalized = container.trim().toLowerCase(Locale.ROOT);
            for (String supported : supportedContainers) {
                if (supported.equalsIgnoreCase(normalized)) {
                    return true;
                }
            }
            return false;
        }

        public boolean isLossless() {
            return defaultBitrateKbps <= 0;
        }
    }

    private static RecordableConfig instance;
    private static Path configPath;

    public String format = "mp4";
    public int fps = 60;
    public String resolution = "native";
    public String quality = "balanced";
    /** Use "auto" for calculated bitrate, or values such as "8M" / "4500k". */
    public String bitrate = "auto";
    public VideoEncoder encoder = VideoEncoder.SOFTWARE;

    public boolean captureAudio = true;
    public String audioSource = "game";
    /** Audio device identifier: "auto" for auto-detect, or an explicit device name (e.g. "Stereo Mix", "WASAPI:Speakers"). */
    public String audioDevice = "auto";
    public AudioEncoder audioEncoder = AudioEncoder.AAC;
    /** Audio bitrate in kbps (used for lossy encoders). */
    public int audioBitrateKbps = 192;
    /** Audio sample rate in Hz. */
    public int audioSampleRate = 48000;
    /** Audio channels: 1=mono, 2=stereo. */
    public int audioChannelCount = 2;
    /** Audio volume percentage. 100 = normal, 0 = mute, 200 = 2x boost. */
    public int audioVolume = 100;
    /** Audio volume boost in dB applied during muxing (0-24 dB, default 0). Stacks with audioVolume. */
    public int audioVolumeBoostDb = 0;

    public String audioBitrate = "192k";
    public String audioChannels = "auto";

    /** Legacy field kept for config migration. Always treated as true. */
    public boolean useFFmpegIfAvailable = true;

    /**
     * Whether to use a bundled FFmpeg binary if one is available
     * (from a companion bundle mod or embedded resource).
     * When true, the mod checks .minecraft/recordable/ffmpeg/bin/ before
     * falling back to system PATH. Default: true.
     */
    public boolean useBundledFfmpeg = true;
    /**
     * Auto-detected path to the bundled FFmpeg binary.
     * This is populated at runtime and saved for informational purposes.
     * Users should not normally edit this. Set to empty string if not detected.
     */
    public String bundledFfmpegPath = "";

    public boolean enabled = true;
    public String outputDir = "recordings";
    public boolean showOverlay = true;
    public boolean showHomeButton = true;
    public boolean stopOnDisconnect = true;
    public boolean showPerformanceStats = false;
    /** 0 means unlimited. */
    public int maxFileSizeMB = 0;

    public String overlayColor = "#FF0000";
    public String menuAccentColor = "#FF0000";

    /**
     * Overlay position on the HUD. Default: TOP_LEFT (classic position).
     */
    public OverlayPosition overlayPosition = OverlayPosition.TOP_LEFT;

    /**
     * Overlay scale as a percentage (50-200). 100 = default size.
     * Affects text rendering and panel dimensions.
     */
    public int overlayScale = 100;

    /**
     * Audio delay preset selection. Controls how the audio sync offset is determined.
     * AUTO = detect based on platform, NONE = 0ms, DESKTOP = 46ms, ANDROID = 60ms,
     * CUSTOM = use audioSyncOffsetMs value directly.
     */
    public AudioDelayPreset audioDelayPreset = AudioDelayPreset.AUTO;

    /**
     * Audio sync offset in milliseconds applied during muxing via FFmpeg's -itsoffset.
     * Compensates for AAC encoder priming delay + capture pipeline latency.
     * Only used when audioDelayPreset is CUSTOM. Default: 46.
     */
    public int audioSyncOffsetMs = 46;

    /**
     * Returns the effective audio delay in milliseconds based on the current preset.
     * AUTO now returns 0ms since deferred audio start + dynamic gap measurement
     * handle synchronization, and FFmpeg handles AAC priming internally.
     * Manual presets (Desktop/Android/Custom) remain for edge-case fine-tuning.
     */
    public int getEffectiveAudioDelay() {
        if (audioDelayPreset == null) {
            audioDelayPreset = AudioDelayPreset.AUTO;
        }
        return switch (audioDelayPreset) {
            case AUTO -> 0;
            case NONE -> 0;
            case DESKTOP -> 46;
            case ANDROID -> 60;
            case CUSTOM -> Math.max(0, Math.min(500, audioSyncOffsetMs));
        };
    }

    public boolean autoRecord = false;
    public String autoRecordTrigger = "world_join";
    public String autoStopTrigger = "world_leave";
    /** Seconds. */
    public int autoRecordDelay = 3;

    // === Feature 2: Configurable Hotkeys ===
    /** GLFW key code for toggle recording. Default: F9 (290). */
    public int hotkeyToggleRecording = 290;
    /** GLFW key code for pause/resume. Default: P (80). */
    public int hotkeyPauseResume = 80;
    /** GLFW key code for open settings. Default: F10 (291). */
    public int hotkeyOpenSettings = 291;
    /** GLFW key code for save replay buffer. Default: F8 (289). */
    public int hotkeySaveReplayBuffer = 289;

    // === Feature 3: Recording Profiles ===
    public static final String[] PROFILES = {"custom", "high_quality", "performance", "streaming", "quick_clip"};
    public String activeProfile = "custom";

    // === Feature 5: Disk Space Guardian ===
    /** Warn when disk usage exceeds this percentage (0-100). */
    public int diskSpaceWarnPercent = 90;
    /** Block recording when disk usage exceeds this percentage (0-100). */
    public int diskSpaceBlockPercent = 95;
    /** Minimum free space in MB before warning. */
    public int diskSpaceMinFreeMB = 500;

    // === Feature 7: Replay Buffer ===
    /** Whether the replay buffer is enabled. */
    public boolean replayBufferEnabled = false;
    /** Duration of the replay buffer in seconds. */
    public int replayBufferDurationSeconds = 30;

    // === Feature 8: Recording Timer Display ===
    /** Show the recording timer on the overlay. */
    public boolean showRecordingTimer = true;
    /** Show estimated file size on the overlay. */
    public boolean showEstimatedFileSize = true;

    // === Feature 6: Toast Notification ===
    /** Show a toast notification when recording finishes. */
    public boolean showPostRecordingToast = true;

    private RecordableConfig() {
    }

    public static synchronized RecordableConfig get() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static synchronized RecordableConfig load() {
        configPath = FabricLoader.getInstance().getConfigDir().resolve(CONFIG_FILE_NAME);

        if (Files.exists(configPath)) {
            try (Reader reader = Files.newBufferedReader(configPath, StandardCharsets.UTF_8)) {
                RecordableConfig loaded = GSON.fromJson(reader, RecordableConfig.class);
                instance = loaded == null ? new RecordableConfig() : loaded;
                instance.migrateOldConfig();
                instance.sanitize();
                instance.save();
                return instance;
            } catch (Exception exception) {
                RecordableMod.LOGGER.warn("Failed to load Record-able config at {}. Recreating defaults.", configPath, exception);
            }
        }

        instance = new RecordableConfig();
        instance.sanitize();
        instance.save();
        return instance;
    }

    public synchronized void save() {
        sanitize();

        try {
            Files.createDirectories(getConfigPath().getParent());
            try (Writer writer = Files.newBufferedWriter(
                    getConfigPath(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE
            )) {
                GSON.toJson(this, writer);
            }
        } catch (IOException exception) {
            RecordableMod.LOGGER.warn("Failed to save Record-able config at {}.", getConfigPath(), exception);
        }
    }

    public static Path getConfigPath() {
        if (configPath == null) {
            configPath = FabricLoader.getInstance().getConfigDir().resolve(CONFIG_FILE_NAME);
        }
        return configPath;
    }

    public String getFormat() {
        if (format == null || format.isBlank()) return "mp4";
        String normalized = format.trim().toLowerCase(Locale.ROOT);
        for (String valid : FORMATS) {
            if (valid.equals(normalized)) return normalized;
        }
        return "mp4";
    }

    public int getFps() {
        return fps;
    }

    public String getResolution() {
        return resolution;
    }

    public String getQuality() {
        return quality;
    }

    public boolean isAutoBitrate() {
        return bitrate == null || bitrate.isBlank() || "auto".equalsIgnoreCase(bitrate.trim());
    }

    public String resolveBitrate(int width, int height) {
        if (!isAutoBitrate()) {
            String userBitrate = bitrate.trim();
            long bitrateInKbps = parseBitrateToKbps(userBitrate);
            if (bitrateInKbps > 0 && bitrateInKbps < 500) {
                RecordableMod.LOGGER.warn("WARNING: Configured bitrate '{}' ({} kbps) is very low for {}x{} video. " +
                        "This will produce poor quality. Recommended: at least 2M for 720p, 5M for 1080p. " +
                        "Set to 'auto' for optimal quality.", userBitrate, bitrateInKbps, width, height);
            }
            return userBitrate;
        }

        double qualityFactor = switch (quality) {
            case "high" -> 0.120D;
            case "performance" -> 0.050D;
            default -> 0.080D;
        };
        double megabits = width * (double) height * Math.max(1, fps) * qualityFactor / 1_000_000.0D;
        int rounded = (int) Math.round(Math.max(2.0D, Math.min(80.0D, megabits)));
        return rounded + "M";
    }

    /**
     * Parses a bitrate string (e.g., "12k", "5M", "8000k") to approximate kbps.
     * Returns -1 if unparseable.
     */
    private static long parseBitrateToKbps(String bitrateStr) {
        if (bitrateStr == null || bitrateStr.isBlank()) return -1;
        String lower = bitrateStr.trim().toLowerCase(Locale.ROOT);
        try {
            if (lower.endsWith("m")) {
                return (long) (Double.parseDouble(lower.substring(0, lower.length() - 1)) * 1000);
            } else if (lower.endsWith("k")) {
                return (long) Double.parseDouble(lower.substring(0, lower.length() - 1));
            } else {
                return Long.parseLong(lower) / 1000;
            }
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public int getX264Crf() {
        return switch (quality) {
            case "high" -> 18;
            case "performance" -> 28;
            default -> 23;
        };
    }

    public String getX264Preset() {
        return switch (quality) {
            case "high" -> "slow";
            case "performance" -> "ultrafast";
            default -> "medium";
        };
    }

    public int getVp9Crf() {
        return switch (quality) {
            case "high" -> 30;
            case "performance" -> 40;
            default -> 35;
        };
    }

    public int getMjpegQuality() {
        return switch (quality) {
            case "high" -> 2;
            case "performance" -> 8;
            default -> 5;
        };
    }

    public Path getOutputDirectory() {
        try {
            Path configured = Paths.get(outputDir == null || outputDir.isBlank() ? "recordings" : outputDir.trim());
            if (configured.isAbsolute()) {
                return configured.normalize();
            }
            return FabricLoader.getInstance().getGameDir().resolve(configured).normalize();
        } catch (InvalidPathException exception) {
            return FabricLoader.getInstance().getGameDir().resolve("recordings").normalize();
        }
    }

    public int getOverlayColorRgb() {
        return parseHexColor(overlayColor, 0xFF0000);
    }

    public int getMenuAccentColorRgb() {
        return parseHexColor(menuAccentColor, 0xFF0000);
    }

    public CaptureDimensions resolveCaptureDimensions(int nativeWidth, int nativeHeight) {
        int safeNativeWidth = Math.max(2, nativeWidth);
        int safeNativeHeight = Math.max(2, nativeHeight);
        int maxHeight = switch (resolution) {
            case "1080p" -> 1080;
            case "720p" -> 720;
            case "480p" -> 480;
            default -> safeNativeHeight;
        };

        if ("native".equals(resolution) || safeNativeHeight <= maxHeight) {
            return new CaptureDimensions(makeEven(safeNativeWidth), makeEven(safeNativeHeight));
        }

        double scale = maxHeight / (double) safeNativeHeight;
        int targetWidth = makeEven((int) Math.round(safeNativeWidth * scale));
        int targetHeight = makeEven((int) Math.round(safeNativeHeight * scale));
        return new CaptureDimensions(Math.max(2, targetWidth), Math.max(2, targetHeight));
    }

    public String getPerformanceHint() {
        boolean heavyResolution = "native".equals(resolution) || "1080p".equals(resolution);
        if (fps >= 120) {
            return "120 FPS recording is expensive. Prefer 60 FPS unless you need slow-motion footage.";
        }
        if (heavyResolution && fps >= 60 && "high".equals(quality)) {
            return "High quality 1080p/native at 60 FPS may drop frames on slower CPUs. Use Performance quality or lower FPS/resolution.";
        }
        if (heavyResolution && fps >= 60) {
            return "If queue warnings appear, switch to 720p or 30 FPS for smoother recording.";
        }
        return "Current settings are expected to record smoothly on most systems.";
    }

    /**
     * Migrates legacy audio device values from older releases.
     *
     * @return true if migration changed config values
     */
    public boolean migrateOldConfig() {
        if (audioDevice != null && "openal".equalsIgnoreCase(audioDevice.trim())) {
            RecordableMod.LOGGER.info("Migrating legacy audioDevice='openal' to 'auto'.");
            audioDevice = "auto";
            return true;
        }
        return false;
    }

    public void sanitize() {
        if (format != null && (format.contains("recordable-") || format.contains(".wav") || format.length() > 10)) {
            RecordableMod.LOGGER.warn("Config format field was corrupted: '{}'. Resetting to 'mp4'.", format);
            format = "mp4";
        }
        format = sanitizeString(format, FORMATS, "mp4");
        resolution = sanitizeString(resolution, RESOLUTIONS, "native");
        quality = sanitizeString(quality, QUALITIES, "balanced");
        if (encoder == null) {
            encoder = VideoEncoder.SOFTWARE;
        }
        autoRecordTrigger = sanitizeString(autoRecordTrigger, AUTO_RECORD_TRIGGERS, "world_join");
        autoStopTrigger = sanitizeString(autoStopTrigger, AUTO_STOP_TRIGGERS, "world_leave");

        if (Arrays.stream(FPS_VALUES).noneMatch(value -> value == fps)) {
            fps = 60;
        }

        if (bitrate == null || bitrate.isBlank()) {
            bitrate = "auto";
        } else {
            String trimmed = bitrate.trim();
            bitrate = "auto".equalsIgnoreCase(trimmed) ? "auto" : trimmed;
            if (!"auto".equalsIgnoreCase(bitrate) && !bitrate.matches("(?i)^[1-9][0-9]*(?:[km])?$")) {
                bitrate = "auto";
            }
        }

        audioSource = "game";
        if (audioDevice == null || audioDevice.isBlank()) {
            audioDevice = "auto";
        } else {
            audioDevice = audioDevice.trim();
            if ("openal".equalsIgnoreCase(audioDevice)) {
                audioDevice = "auto";
            }
        }

        if (audioEncoder == null) {
            audioEncoder = AudioEncoder.AAC;
        }

        if (audioBitrate != null && !audioBitrate.isBlank()) {
            String trimmedAudio = audioBitrate.trim().toLowerCase(Locale.ROOT);
            if (trimmedAudio.matches("^[1-9][0-9]*k$")) {
                try {
                    audioBitrateKbps = Integer.parseInt(trimmedAudio.substring(0, trimmedAudio.length() - 1));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        audioBitrateKbps = Math.max(32, Math.min(512, audioBitrateKbps));

        audioChannelCount = (audioChannelCount == 1) ? 1 : 2;
        audioChannels = sanitizeString(audioChannels, AUDIO_CHANNELS, "auto");
        if ("mono".equals(audioChannels)) {
            audioChannelCount = 1;
        } else if ("stereo".equals(audioChannels)) {
            audioChannelCount = 2;
        }

        if (Arrays.stream(AUDIO_SAMPLE_RATES).noneMatch(value -> value == audioSampleRate)) {
            audioSampleRate = 48000;
        }

        audioVolume = Math.max(0, Math.min(200, audioVolume));
        audioVolumeBoostDb = Math.max(0, Math.min(24, audioVolumeBoostDb));

        validateAudioEncoderCompatibility();

        audioBitrate = audioBitrateKbps + "k";
        audioChannels = audioChannelCount == 1 ? "mono" : "stereo";

        if (outputDir == null || outputDir.isBlank()) {
            outputDir = "recordings";
        } else {
            outputDir = outputDir.trim();
        }

        try {
            String detected = FfmpegBundleManager.getBundledFfmpegPath();
            bundledFfmpegPath = detected != null ? detected : "";
        } catch (Exception e) {
            bundledFfmpegPath = "";
        }

        overlayColor = sanitizeHexColor(overlayColor, "#FF0000");
        menuAccentColor = sanitizeHexColor(menuAccentColor, "#FF0000");
        if (overlayPosition == null) {
            overlayPosition = OverlayPosition.TOP_LEFT;
        }
        overlayScale = Math.max(50, Math.min(200, overlayScale));
        maxFileSizeMB = Math.max(0, maxFileSizeMB);
        autoRecordDelay = Math.max(0, Math.min(10, autoRecordDelay));

        // Sanitize audio delay preset
        if (audioDelayPreset == null) {
            audioDelayPreset = AudioDelayPreset.AUTO;
        }
        audioSyncOffsetMs = Math.max(0, Math.min(500, audioSyncOffsetMs));

        // Sanitize new feature fields
        activeProfile = sanitizeString(activeProfile, PROFILES, "custom");
        diskSpaceWarnPercent = Math.max(50, Math.min(99, diskSpaceWarnPercent));
        diskSpaceBlockPercent = Math.max(diskSpaceWarnPercent + 1, Math.min(100, diskSpaceBlockPercent));
        diskSpaceMinFreeMB = Math.max(100, Math.min(10000, diskSpaceMinFreeMB));
        replayBufferDurationSeconds = Math.max(10, Math.min(300, replayBufferDurationSeconds));
    }

    /**
     * Applies a named recording profile, overwriting video/quality settings.
     * Does not change profile to "custom" — call this when user selects a preset.
     */
    public void applyProfile(String profileName) {
        switch (profileName) {
            case "high_quality" -> {
                resolution = "1080p";
                fps = 60;
                quality = "high";
                bitrate = "auto";
                encoder = VideoEncoder.SOFTWARE;
                captureAudio = true;
                audioEncoder = AudioEncoder.AAC;
                audioBitrateKbps = 256;
            }
            case "performance" -> {
                resolution = "720p";
                fps = 30;
                quality = "performance";
                bitrate = "auto";
                encoder = VideoEncoder.SOFTWARE;
                captureAudio = true;
                audioEncoder = AudioEncoder.AAC;
                audioBitrateKbps = 128;
            }
            case "streaming" -> {
                resolution = "1080p";
                fps = 60;
                quality = "balanced";
                bitrate = "6M";
                encoder = VideoEncoder.SOFTWARE;
                captureAudio = true;
                audioEncoder = AudioEncoder.AAC;
                audioBitrateKbps = 192;
            }
            case "quick_clip" -> {
                resolution = "720p";
                fps = 60;
                quality = "balanced";
                bitrate = "auto";
                maxFileSizeMB = 100;
                captureAudio = true;
                audioEncoder = AudioEncoder.AAC;
                audioBitrateKbps = 128;
            }
            default -> {
                // "custom" — do nothing, user settings preserved
            }
        }
        activeProfile = profileName;
        sanitize();
    }

    /**
     * Returns a human-readable name for the given profile key.
     */
    public static String getProfileDisplayName(String profile) {
        return switch (profile) {
            case "high_quality" -> "High Quality";
            case "performance" -> "Performance";
            case "streaming" -> "Streaming";
            case "quick_clip" -> "Quick Clip";
            default -> "Custom";
        };
    }

    public void validateAudioEncoderCompatibility() {
        if (audioEncoder == null) {
            audioEncoder = AudioEncoder.AAC;
        }

        String container = getContainerFromFormat();
        if (!audioEncoder.supportsContainer(container)) {
            RecordableMod.LOGGER.warn("Audio encoder {} is not supported in {} container. Falling back to AAC.",
                    audioEncoder.displayName,
                    container);
            audioEncoder = AudioEncoder.AAC;
        }

        if (!audioEncoder.isLossless() && audioBitrateKbps <= 0) {
            audioBitrateKbps = Math.max(96, audioEncoder.defaultBitrateKbps);
        }
    }

    public String getContainerFromFormat() {
        return switch (getFormat()) {
            case "webm" -> "webm";
            case "avi" -> "avi";
            default -> "mp4";
        };
    }

    private static String sanitizeString(String value, String[] allowed, String fallback) {
        if (value != null) {
            String normalized = value.trim().toLowerCase(Locale.ROOT);
            for (String candidate : allowed) {
                if (candidate.equals(normalized)) {
                    return normalized;
                }
            }
        }
        return fallback;
    }

    private static String sanitizeHexColor(String value, String fallback) {
        if (value == null) {
            return fallback;
        }
        String normalized = value.trim();
        if (!normalized.startsWith("#")) {
            normalized = "#" + normalized;
        }
        if (!HEX_COLOR_PATTERN.matcher(normalized).matches()) {
            return fallback;
        }
        return normalized.toUpperCase(Locale.ROOT);
    }

    private static int parseHexColor(String value, int fallback) {
        String normalized = sanitizeHexColor(value, String.format(Locale.ROOT, "#%06X", fallback));
        try {
            return Integer.parseInt(normalized.substring(1), 16);
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    /**
     * Resolves which encoder backend to use. FFmpeg is the only supported encoder.
     */
    public EncoderType resolveEncoderType() {
        return EncoderType.FFMPEG;
    }

    private static int makeEven(int value) {
        return value % 2 == 0 ? value : value - 1;
    }

    public record CaptureDimensions(int width, int height) {
    }
}
