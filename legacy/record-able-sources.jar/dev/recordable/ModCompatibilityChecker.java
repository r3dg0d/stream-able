package dev.recordable;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Detects mods that are known to conflict with Record-able's audio/video
 * capture hooks at startup and when a recording begins.
 *
 * <p>Conflicts are logged as warnings and, optionally, surfaced as in-game
 * chat messages so the user can take action before recording artefacts occur.</p>
 */
public final class ModCompatibilityChecker {

    /**
     * Registry of known conflicting mod IDs → human-readable reason.
     * Add new entries here as conflicts are discovered.
     */
    private static final Map<String, String> KNOWN_CONFLICTS;

    static {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("flashback",
                "Flashback (replay mod) hooks into the same rendering/audio pipeline and may cause " +
                "duplicate frame capture, audio desync, or crashes.");
        m.put("replaymod",
                "ReplayMod intercepts client packets and rendering, which can interfere with " +
                "Record-able's screen capture and audio recording.");
        m.put("replay-mod",
                "Replay Mod (alternate ID) may conflict with Record-able's capture hooks.");
        KNOWN_CONFLICTS = Collections.unmodifiableMap(m);
    }

    /** Cached list of detected conflicts (populated once at startup). */
    private static List<String> detectedConflicts;

    private ModCompatibilityChecker() {
    }

    /**
     * Scans the loaded mod list for known conflicts and logs warnings.
     * Call once during {@link RecordableMod#onInitializeClient()}.
     *
     * @return an unmodifiable list of human-readable conflict descriptions
     */
    public static List<String> checkAndLog() {
        List<String> conflicts = new ArrayList<>();
        FabricLoader loader = FabricLoader.getInstance();

        for (Map.Entry<String, String> entry : KNOWN_CONFLICTS.entrySet()) {
            if (loader.isModLoaded(entry.getKey())) {
                String msg = "[Record-able] Mod conflict detected: '" + entry.getKey() + "' - " + entry.getValue();
                RecordableMod.LOGGER.warn(msg);
                conflicts.add(msg);
            }
        }

        if (conflicts.isEmpty()) {
            RecordableMod.LOGGER.info("[Record-able] No known mod conflicts detected.");
        } else {
            RecordableMod.LOGGER.warn("[Record-able] {} conflicting mod(s) detected. " +
                    "Recording may be unstable - see warnings above.", conflicts.size());
        }

        detectedConflicts = Collections.unmodifiableList(conflicts);
        return detectedConflicts;
    }

    /**
     * Returns {@code true} if at least one conflicting mod was detected at startup.
     */
    public static boolean hasConflicts() {
        return detectedConflicts != null && !detectedConflicts.isEmpty();
    }

    /**
     * Returns the cached list of conflict descriptions (empty if none).
     */
    public static List<String> getDetectedConflicts() {
        return detectedConflicts != null ? detectedConflicts : Collections.emptyList();
    }

    /**
     * Displays an in-game warning to the player when a recording is about to start
     * and conflicts exist. Call this from {@link RecordingManager} or the toggle-key handler.
     *
     * @param client the active {@link class_310} instance
     */
    public static void warnPlayerIfConflicts(class_310 client) {
        if (!hasConflicts() || client == null || client.field_1724 == null) {
            return;
        }

        client.field_1724.method_7353(
                class_2561.method_43470("§e[Record-able] §cWarning: conflicting mod(s) detected!"),
                false);
        for (String conflict : detectedConflicts) {
            String brief = conflict.replace("[Record-able] Mod conflict detected: ", "");
            client.field_1724.method_7353(
                    class_2561.method_43470("§7  • " + brief),
                    false);
        }
        client.field_1724.method_7353(
                class_2561.method_43470("§eRecording may have A/V sync issues or instability. " +
                        "Consider disabling the conflicting mod(s)."),
                false);
    }
}
