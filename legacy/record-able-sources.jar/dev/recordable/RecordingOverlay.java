package dev.recordable;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
/**
 * HUD overlay showing recording status, timer, performance stats,
 * toast notifications, and replay buffer indicator.
 */
public final class RecordingOverlay {
    private static boolean registered;
    /** Blinking tick counter for paused state indicator. */
    private static int blinkTick;

    private RecordingOverlay() {
    }

    public static void register() {
        if (registered) {
            return;
        }
        registered = true;
        HudRenderCallback.EVENT.register(RecordingOverlay::render);
    }

    private static void render(class_332 context, class_9779 tickCounter) {
        RecordableConfig config = RecordableConfig.get();
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1772 == null) {
            return;
        }

        RecordingManager manager = RecordingManager.getInstance();

        // === Toast Notification (shown even when not recording) ===
        renderToastNotification(context, client, manager);

        // === Replay Buffer Indicator (shown when buffer is active but not recording) ===
        if (!manager.isActiveOrStopping() && ReplayBuffer.getInstance().isActive()) {
            renderReplayBufferIndicator(context, client);
        }

        if (!config.showOverlay || !manager.isActiveOrStopping()) {
            return;
        }

        int accentRgb = config.getOverlayColorRgb();
        int accentArgb = 0xFF000000 | accentRgb;
        int accentSoftArgb = 0xAA000000 | accentRgb;

        class_327 textRenderer = client.field_1772;
        blinkTick++;

        // === Feature 8: Recording Timer ===
        String effectiveTime = RecordingManager.formatDuration(manager.getEffectiveRecordingMillis());
        String totalTime = RecordingManager.formatDuration(manager.getElapsedMillis());
        boolean isPaused = manager.getState() == RecordingManager.State.PAUSED;
        boolean showBlink = isPaused && (blinkTick / 15) % 2 == 0;

        String firstLine;
        if (manager.getState() == RecordingManager.State.STOPPING) {
            firstLine = "REC stopping...";
        } else if (isPaused) {
            firstLine = showBlink ? "⏸ PAUSED " + effectiveTime : "  PAUSED " + effectiveTime;
        } else {
            firstLine = "● REC " + effectiveTime;
        }

        // === Feature 8: File size and FPS info ===
        long fileSizeBytes = manager.getCurrentFileSizeBytes();
        String fileSizeStr;
        if (config.showEstimatedFileSize && fileSizeBytes > 0) {
            fileSizeStr = RecordingManager.formatBytes(fileSizeBytes);
        } else if (fileSizeBytes > 0) {
            fileSizeStr = RecordingManager.formatBytes(fileSizeBytes);
        } else {
            fileSizeStr = "starting...";
        }

        String secondLine = manager.getRecordingFps() + " FPS  " + fileSizeStr
                + "  drop " + manager.getDroppedFrames();

        RecordingManager.QueueHealth queueHealth = manager.getQueueHealth();
        String queueState = switch (queueHealth) {
            case CRITICAL -> "DROPPING";
            case SLOW -> "SLOW";
            default -> "OK";
        };
        String thirdLine = manager.getRecordingWidth() + "x" + manager.getRecordingHeight()
                + "  Queue: " + manager.getQueueSize() + "/" + manager.getQueueCapacity()
                + " (" + queueState + ")";

        // === Feature 4: Enhanced Performance Stats with Micrometer ===
        PerformanceMetrics metrics = PerformanceMetrics.getInstance();
        metrics.updateQueueStats(manager.getQueueSize(), manager.getQueueCapacity());
        metrics.updateMemory(manager.getUsedMemoryMiB());
        metrics.updateFps(Math.round(manager.getCaptureFpsEstimate()),
                Math.round(manager.getEncoderFpsEstimate()));
        metrics.updateFileSize(fileSizeBytes);

        String fourthLine = "Cap " + Math.round(manager.getCaptureFpsEstimate())
                + " | Enc " + Math.round(manager.getEncoderFpsEstimate())
                + " | Mem " + manager.getUsedMemoryMiB() + " MiB"
                + " | AdDrop " + manager.getAdaptiveDroppedFrames();

        String fifthLine = metrics.getCompactSummary()
                + " | Buf " + String.format("%.0f%%", metrics.getBufferHealthPercent());

        int queueColor = switch (queueHealth) {
            case CRITICAL -> 0xFFFF7070;
            case SLOW -> 0xFFFFD166;
            default -> 0xFF9BE28F;
        };

        int fileSizeColor = fileSizeBytes > 0L ? 0xFFFFFFFF : 0xFFAAAAAA;
        int pausedColor = isPaused ? 0xFFFFD166 : 0xFFFFFFFF;

        boolean showPerfStats = config.showPerformanceStats;
        boolean showTimer = config.showRecordingTimer;

        // ── Overlay scale ──
        float scale = Math.max(0.5F, Math.min(2.0F, config.overlayScale / 100.0F));
        RecordableConfig.OverlayPosition position = config.overlayPosition != null
                ? config.overlayPosition : RecordableConfig.OverlayPosition.TOP_LEFT;

        // Apply scale via matrix push (all drawing inside will be scaled)
        context.method_51448().pushMatrix();
        context.method_51448().scale(scale, scale);

        // Work in scaled coordinate space
        int scaledW = (int) (client.method_22683().method_4486() / scale);
        int scaledH = (int) (client.method_22683().method_4502() / scale);

        // ── Overlay positioning ──
        // Safe margins to avoid vanilla HUD elements:
        //   • Boss bars:      top-center
        //   • Tab list:       top-center
        //   • Status effects: top-right
        //   • Scoreboard:     right side (width ~80-120px)
        //   • Chat:           bottom-left (height ~100px)
        //   • Action bar:     bottom-center
        //   • Subtitles:      bottom-right
        //   • Hotbar:         bottom-center (~22px + hearts/armor)
        int margin = 10;

        // Calculate panel dimensions first (needed for right/bottom anchoring)
        int lineCount = 3; // firstLine + secondLine + thirdLine always
        if (showPerfStats) lineCount += 2;
        if (ReplayBuffer.getInstance().isActive()) lineCount++;

        int maxTextWidth = Math.max(textRenderer.method_1727(firstLine),
                Math.max(textRenderer.method_1727(secondLine),
                        Math.max(textRenderer.method_1727("Size: " + fileSizeStr),
                                textRenderer.method_1727(thirdLine))));
        if (showPerfStats) {
            maxTextWidth = Math.max(maxTextWidth, Math.max(
                    textRenderer.method_1727(fourthLine),
                    textRenderer.method_1727(fifthLine)));
        }
        int panelWidth = maxTextWidth + 22;
        int panelHeight = 12 + (lineCount * 11);

        // Determine x, y based on position preset
        int x, y;
        switch (position) {
            case TOP_RIGHT -> {
                // Keep clear of status effects (potions) which render top-right
                // and scoreboard which renders right side
                int scoreboardSafeMargin = 130; // scoreboard typically ~120px wide
                x = scaledW - panelWidth - margin - scoreboardSafeMargin;
                y = margin;
            }
            case BOTTOM_LEFT -> {
                // Keep clear of chat area (usually bottom ~100px on left side)
                int chatSafeMargin = 50;
                x = margin;
                y = scaledH - panelHeight - margin - chatSafeMargin;
            }
            case BOTTOM_RIGHT -> {
                // Keep clear of subtitles (bottom-right) and hotbar
                int scoreboardSafeMargin = 130;
                int hotbarSafeMargin = 50;
                x = scaledW - panelWidth - margin - scoreboardSafeMargin;
                y = scaledH - panelHeight - margin - hotbarSafeMargin;
            }
            case CENTER_TOP -> {
                // Keep clear of boss bars (top-center, typically 50-70px tall)
                int bossBarSafeMargin = 70;
                x = (scaledW - panelWidth) / 2;
                y = margin + bossBarSafeMargin;
            }
            default -> { // TOP_LEFT
                x = margin;
                y = margin;
            }
        }

        // Clamp panel so it never overflows the scaled screen bounds
        x = Math.max(margin, Math.min(x, scaledW - panelWidth - margin));
        y = Math.max(margin, Math.min(y, scaledH - panelHeight - margin));
        if (x + panelWidth + margin > scaledW) {
            panelWidth = scaledW - x - margin;
        }
        if (y + panelHeight + margin > scaledH) {
            panelHeight = scaledH - y - margin;
        }

        // Background panel
        context.method_25294(x - 3, y - 3, x + panelWidth, y + panelHeight, 0x99000000);
        context.method_25294(x - 3, y - 3, x + panelWidth, y - 2, accentSoftArgb);

        // Recording indicator dot
        if (!isPaused) {
            context.method_25294(x, y + 3, x + 8, y + 11, accentArgb);
        }

        int lineY = y;
        context.method_27535(textRenderer, class_2561.method_43470(firstLine), x + (isPaused ? 0 : 13), lineY, pausedColor);
        lineY += 12;

        context.method_27535(textRenderer, class_2561.method_43470(secondLine), x, lineY, 0xFFE0E0E0);
        lineY += 11;

        context.method_27535(textRenderer, class_2561.method_43470("Size: " + fileSizeStr), x, lineY, fileSizeColor);
        lineY += 11;

        context.method_27535(textRenderer, class_2561.method_43470(thirdLine), x, lineY, queueColor);
        lineY += 11;

        if (showPerfStats) {
            context.method_27535(textRenderer, class_2561.method_43470(fourthLine), x, lineY, 0xFFCFCFCF);
            lineY += 11;
            context.method_27535(textRenderer, class_2561.method_43470(fifthLine), x, lineY, 0xFFB0B0B0);
            lineY += 11;
        }

        // Replay buffer indicator in overlay
        if (ReplayBuffer.getInstance().isActive()) {
            ReplayBuffer rb = ReplayBuffer.getInstance();
            String rbLine = "⟳ Replay: " + rb.getBufferedSeconds() + "s buffered ("
                    + rb.getBufferedFrameCount() + " frames)";
            context.method_27535(textRenderer, class_2561.method_43470(rbLine), x, lineY, 0xFF88CCFF);
        }

        // Pop the scale matrix
        context.method_51448().popMatrix();
    }

    /**
     * Renders the post-recording toast notification at the bottom of the screen.
     */
    private static void renderToastNotification(class_332 context, class_310 client,
                                                 RecordingManager manager) {
        String toastMsg = manager.getPendingToastMessage();
        if (toastMsg == null) return;

        class_327 textRenderer = client.field_1772;
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int toastWidth = textRenderer.method_1727(toastMsg) + 30;
        int toastHeight = 24;
        int toastX = (screenWidth - toastWidth) / 2;
        int toastY = screenHeight - toastHeight - 40;

        // Background
        context.method_25294(toastX, toastY, toastX + toastWidth, toastY + toastHeight, 0xDD1A1A1A);
        context.method_25294(toastX, toastY, toastX + toastWidth, toastY + 1, 0xFF44AA44);

        // Text
        context.method_27535(textRenderer, class_2561.method_43470(toastMsg), toastX + 8, toastY + 7, 0xFFFFFFFF);
    }

    /**
     * Renders a small indicator when the replay buffer is active but not recording.
     */
    private static void renderReplayBufferIndicator(class_332 context, class_310 client) {
        RecordableConfig config = RecordableConfig.get();
        if (!config.showOverlay) return;

        float scale = Math.max(0.5F, Math.min(2.0F, config.overlayScale / 100.0F));
        context.method_51448().pushMatrix();
        context.method_51448().scale(scale, scale);

        class_327 textRenderer = client.field_1772;
        ReplayBuffer rb = ReplayBuffer.getInstance();
        String text = "⟳ Replay Buffer: " + rb.getBufferedSeconds() + "s";
        int scaledW = (int) (client.method_22683().method_4486() / scale);
        int scaledH = (int) (client.method_22683().method_4502() / scale);

        RecordableConfig.OverlayPosition position = config.overlayPosition != null
                ? config.overlayPosition : RecordableConfig.OverlayPosition.TOP_LEFT;
        int textWidth = textRenderer.method_1727(text) + 12;

        int x, y;
        switch (position) {
            case TOP_RIGHT -> { x = scaledW - textWidth - 10 - 130; y = 10; }
            case BOTTOM_LEFT -> { x = 10; y = scaledH - 23 - 50; }
            case BOTTOM_RIGHT -> { x = scaledW - textWidth - 10 - 130; y = scaledH - 23 - 50; }
            case CENTER_TOP -> { x = (scaledW - textWidth) / 2; y = 80; }
            default -> { x = 10; y = 10; }
        }
        x = Math.max(5, Math.min(x, scaledW - textWidth - 5));
        y = Math.max(5, Math.min(y, scaledH - 18));

        context.method_25294(x - 3, y - 3, x + textWidth, y + 13, 0x88000000);
        context.method_27535(textRenderer, class_2561.method_43470(text), x, y, 0xFF88CCFF);

        context.method_51448().popMatrix();
    }

}
