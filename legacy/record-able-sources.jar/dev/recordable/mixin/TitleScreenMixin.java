package dev.recordable.mixin;

import dev.recordable.RecordableConfig;
import dev.recordable.screen.HomeButtonWidget;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(net.minecraft.class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void recordable$addHomeButton(CallbackInfo ci) {
        RecordableConfig config;
        try {
            config = RecordableConfig.get();
        } catch (Throwable ignored) {
            return;
        }
        if (config == null || !config.showHomeButton) {
            return;
        }

        try {
            this.method_37063(HomeButtonWidget.create((class_442) (Object) this));
        } catch (Throwable ignored) {
        }
    }
}
