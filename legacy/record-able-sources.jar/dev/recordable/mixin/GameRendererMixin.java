package dev.recordable.mixin;

import dev.recordable.RecordableMod;
import dev.recordable.RecordingManager;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Captures the fully rendered frame after world, entities, particles, GUI, and overlays. */
@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/render/RenderTickCounter;Z)V", at = @At("TAIL"))
    private void recordable$captureCompleteFrame(class_9779 tickCounter, boolean tick, CallbackInfo callbackInfo) {
        try {
            RecordingManager.getInstance().onFrame();
        } catch (Throwable throwable) {
            RecordableMod.LOGGER.warn("Record-able capture hook failed; skipping this frame.", throwable);
        }
    }
}
